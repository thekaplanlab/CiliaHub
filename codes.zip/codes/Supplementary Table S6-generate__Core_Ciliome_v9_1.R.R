# ==============================================================================
# Script Name: generate_Table_S4_Core_Ciliome_v9_1.R
# Description: Dynamically filters and exports the 245 Core Ciliome genes 
#              for CiliaHub Release v9.1.
# Date: 2026-09-21
# ==============================================================================

library(readxl)
library(dplyr)
library(stringr)
library(writexl)

# 1. Load Master Dataset
input_path <- "C:/Users/lenovo/Desktop/table3_1.xlsx"
df <- read_excel(input_path, col_types = "text")

# 2. Dynamic Filtering for Core Ciliome (N = 245)
table_s4_core <- df %>%
  mutate(
    evidence_tier_clean = str_trim(as.character(evidence_tier)),
    localization_refs_clean = str_trim(as.character(localization_refs)),
    evidence_type_clean = str_trim(as.character(evidence_type))
  ) %>%
  filter(
    grepl("Gold Standard", evidence_tier_clean, ignore.case = TRUE) &
      !grepl("Associated", evidence_tier_clean, ignore.case = TRUE) &
      (
        evidence_type_clean %in% c("curated_screen_2026_05", "curated_2026", "curated_2026_addition", "literature", "direct_human_cilia") |
          (!is.na(localization_refs_clean) & localization_refs_clean != "" & localization_refs_clean != "NA" & localization_refs_clean != "N/A")
      )
  ) %>%
  dplyr::select(-evidence_tier_clean, -localization_refs_clean, -evidence_type_clean)

# 3. Report Results
cat("\n=========================================================\n")
cat(" FINAL CORE CILIOME GENE COUNT (v9.1):", nrow(table_s4_core), "\n")
cat("=========================================================\n\n")

# 4. Export Supplementary Table S4
output_path <- "C:/Users/lenovo/Desktop/Supplementary_Table_S4_Core_Ciliome_v9_2.xlsx"
write_xlsx(table_s4_core, path = output_path)

cat("[SUCCESS] Supplementary Table S4 exported to:\n", output_path, "\n")