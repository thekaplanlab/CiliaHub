# ==============================================================================
# CiliaHub Figure 1 (R Version - Pure Native ggplot2)
# Updated to CiliaHub Release v9.1 Metrics:
# Exactly 2,786 genes (2,179 Gold-Standard + 607 Cilia-Associated)
# Outputs: PNG (300 dpi) and Vector PDF
# ==============================================================================

required_packages <- c("ggplot2", "patchwork", "scales")
for (pkg in required_packages) {
  if (!requireNamespace(pkg, quietly = TRUE)) install.packages(pkg)
}

library(ggplot2)
library(patchwork)
library(scales)

# ------------------------------------------------------------------------------
# 1. Color Palette Definition
# ------------------------------------------------------------------------------
NAVY      <- "#1f3a5f"
BLUE      <- "#2f6db0"
TEAL      <- "#1f9e89"
GOLD      <- "#c8901f"
GREY      <- "#5b6470"
LIGHTGREY <- "#b8c0cb"
LIGHT     <- "#eef2f7"
INK       <- "#0f172a"

# ------------------------------------------------------------------------------
# 2. Panel A Construction (Schema Architecture)
# ------------------------------------------------------------------------------
build_panel_a <- function() {
  
  # Main Column Boxes Data
  boxes_df <- data.frame(
    x1 = c(2, 2, 33, 70, 70, 70, 70, 70),
    x2 = c(24, 24, 67, 98, 98, 98, 98, 98),
    y1 = c(78, 62, 28, 79.6, 69.3, 59.0, 48.7, 38.4),
    y2 = c(87, 71, 90, 87.2, 76.9, 66.6, 56.3, 46.0),
    label = c(
      "Automated\nliterature mining",
      "Expert curation\n(localization + function)",
      "",
      "Gene search\nannotation cards",
      "Cilia Analysis\n7 analysis views",
      "CiliAI\nNL assistant + viz",
      "Phenotype\ndisease + symptom + HPO",
      "Static-JSON API\nopen, no login"
    ),
    fc = c("white", "white", LIGHT, "white", "white", "white", "white", "white"),
    ec = c(NAVY, NAVY, NAVY, TEAL, BLUE, GOLD, TEAL, GREY)
  )
  
  # Chips inside Column 2
  chips <- c("Evidence tier", "Orthologs in 5 species", "Functional category", "Large-scale screens",
             "Pfam domains", "Protein-complex membership", "ClinVar variants", "Mouse (MGI) phenotypes",
             "HPA / CELLxGENE expression", "CilioGenics score", "Pan-/idio-ciliary class", "Ciliopathy class + HPO")
  
  cy_start <- 86
  chip_y1 <- numeric(length(chips))
  chip_y2 <- numeric(length(chips))
  for (i in seq_along(chips)) {
    chip_y1[i] <- (cy_start - (i - 1) * 4.55) - 3.2
    chip_y2[i] <- cy_start - (i - 1) * 4.55
  }
  
  chips_df <- data.frame(
    x1 = 35, x2 = 65,
    y1 = chip_y1, y2 = chip_y2,
    label = chips, fc = "white", ec = BLUE
  )
  
  # Bottom Row Summary Cards (Updated to Release v9.1: 2,786 Genes)
  bottom_labels <- c(
    "2,786 ciliary genes", 
    "2,179 gold-standard\n+ 607 associated",
    "86 ciliopathies /\n532 disease genes", 
    "orthologs in\n5 species"
  )
  
  bottom_df <- data.frame(
    x1 = c(2, 26.5, 51, 75.5),
    x2 = c(24.5, 49, 73.5, 98),
    y1 = 16, y2 = 23.5,
    label = bottom_labels,
    fc = NAVY, ec = NAVY
  )
  
  # Connecting Arrows Data
  arrows_df <- data.frame(
    x = c(13, 24, 67, 67, 67, 67, 67),
    xend = c(13, 33, 70, 70, 70, 70, 70),
    y = c(78, 66.5, 83.4, 73.1, 62.8, 52.5, 42.2),
    yend = c(71, 60, 83.4, 73.1, 62.8, 52.5, 42.2),
    color = c(GREY, GREY, TEAL, BLUE, GOLD, TEAL, GREY)
  )
  
  # Assemble Panel A Plot
  p <- ggplot() +
    annotate("text", x = 13, y = 96, label = "Curation", fontface = "bold", size = 3.5, color = NAVY) +
    annotate("text", x = 50, y = 96, label = "Integrated gene record", fontface = "bold", size = 3.5, color = NAVY) +
    annotate("text", x = 84, y = 96, label = "Modules & access", fontface = "bold", size = 3.5, color = NAVY) +
    
    geom_rect(data = boxes_df, aes(xmin = x1, xmax = x2, ymin = y1, ymax = y2),
              fill = boxes_df$fc, color = boxes_df$ec, linewidth = 0.5) +
    geom_text(data = boxes_df, aes(x = (x1 + x2)/2, y = (y1 + y2)/2, label = label),
              size = 2.4, color = INK, lineheight = 0.9) +
    
    geom_rect(data = chips_df, aes(xmin = x1, xmax = x2, ymin = y1, ymax = y2),
              fill = chips_df$fc, color = chips_df$ec, linewidth = 0.3) +
    geom_text(data = chips_df, aes(x = (x1 + x2)/2, y = (y1 + y2)/2, label = label),
              size = 2.1, color = INK) +
    
    geom_rect(data = bottom_df, aes(xmin = x1, xmax = x2, ymin = y1, ymax = y2),
              fill = bottom_df$fc, color = bottom_df$ec, linewidth = 0.5) +
    geom_text(data = bottom_df, aes(x = (x1 + x2)/2, y = (y1 + y2)/2, label = label),
              size = 2.3, color = "white", fontface = "bold", lineheight = 0.9) +
    
    geom_segment(data = arrows_df, aes(x = x, xend = xend, y = y, yend = yend),
                 color = arrows_df$color, linewidth = 0.5,
                 arrow = arrow(length = unit(0.08, "inches"), type = "closed")) +
    
    scale_x_continuous(limits = c(0, 100), expand = c(0, 0)) +
    scale_y_continuous(limits = c(14, 99), expand = c(0, 0)) +
    theme_void() +
    theme(panel.background = element_rect(fill = "white", color = NA))
  
  return(p)
}

# ------------------------------------------------------------------------------
# 3. Panel B Construction (Updated to v9.1: 2,786 Total / 2,179 Gold-Standard)
# ------------------------------------------------------------------------------
build_panel_b <- function() {
  df_b <- data.frame(
    label = factor(
      c("SCGSv1\n(2013)", "SCGSv2\n(2021)", "CiliaHub\nGold-Standard Genes", "CiliaHub\nfull catalogue"),
      levels = c("SCGSv1\n(2013)", "SCGSv2\n(2021)", "CiliaHub\nGold-Standard Genes", "CiliaHub\nfull catalogue")
    ),
    val = c(303, 686, 2179, 2786),
    col = c(LIGHTGREY, GREY, BLUE, NAVY)
  )
  
  p <- ggplot(df_b, aes(x = label, y = val, fill = label)) +
    geom_bar(stat = "identity", width = 0.62, color = "white") +
    geom_text(aes(label = comma(val)), hjust = -0.15, size = 2.8, fontface = "bold") +
    scale_fill_manual(values = c(LIGHTGREY, GREY, BLUE, NAVY)) +
    scale_y_continuous(limits = c(0, 3500), expand = c(0, 0)) +
    coord_flip() +
    labs(x = NULL, y = "Curated ciliary genes") +
    theme_classic() +
    theme(
      legend.position = "none",
      axis.text.y = element_text(size = 7.5, color = INK),
      axis.text.x = element_text(size = 7, color = INK),
      axis.title.x = element_text(size = 8, color = INK),
      axis.line = element_line(color = INK, linewidth = 0.4)
    )
  
  return(p)
}

# ------------------------------------------------------------------------------
# 4. Render and Save Output
# ------------------------------------------------------------------------------
pA <- build_panel_a()
pB <- build_panel_b()

# Combined Composite AB
composite_fig <- pA / pB + 
  plot_layout(heights = c(1.7, 1.0)) +
  plot_annotation(tag_levels = 'A') & 
  theme(plot.tag = element_text(size = 13, face = "bold", color = INK))

# Save PNG (300 DPI) and Vector PDF
ggsave("Figure1_composite_v9__21_.png", plot = composite_fig, width = 7.6, height = 6.2, dpi = 300)
ggsave("Figure1_composite_v9__2.pdf", plot = composite_fig, width = 7.6, height = 6.2)

cat("Success! Figure 1 updated with CiliaHub v9.1 metrics (2,786 total genes; 2,179 Gold-Standard).\n")
