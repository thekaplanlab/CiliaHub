# ============================================================
# CiliaHub - HUMAN GENE UNIVERSE
# Ensembl 116 + HGNC Approved + Protein-coding
# ============================================================

# Packages
library(data.table)
library(dplyr)
library(stringr)

# ------------------------------------------------------------
# 1. Output directory
# ------------------------------------------------------------

output_dir <- "C:/Users/lenovo/Documents/CiliaHub_Gene_Universe1"

dir.create(
  output_dir,
  recursive = TRUE,
  showWarnings = FALSE
)

# ------------------------------------------------------------
# 2. Ensembl 116 GTF
# ------------------------------------------------------------

ensembl_url <- paste0(
  "https://ftp.ensembl.org/pub/release-116/",
  "gtf/homo_sapiens/",
  "Homo_sapiens.GRCh38.116.gtf.gz"
)

ensembl_file <- file.path(
  output_dir,
  "Homo_sapiens.GRCh38.116.gtf.gz"
)

if (!file.exists(ensembl_file)) {
  
  download.file(
    ensembl_url,
    ensembl_file,
    mode = "wb",
    method = "libcurl"
  )
  
}

cat(
  "Ensembl 116 GTF:",
  file.info(ensembl_file)$size,
  "bytes\n"
)


# ------------------------------------------------------------
# 3. Read Ensembl 116 GTF - WINDOWS COMPATIBLE
# ------------------------------------------------------------

# ------------------------------------------------------------
# 3. Read Ensembl 116 GTF - WINDOWS SAFE
# ------------------------------------------------------------

con <- gzfile(
  ensembl_file,
  open = "rt"
)

gtf <- data.table::fread(
  con,
  sep = "\t",
  header = FALSE,
  quote = "",
  comment.char = "#",
  data.table = FALSE
)

close(con)

cat(
  "GTF loaded successfully:",
  nrow(gtf),
  "rows\n"
)

















# ============================================================
# READ ENSEMBL 116 GTF - WINDOWS
# ============================================================

install.packages("R.utils")   # sadece ilk sefer gerekli

library(data.table)
library(R.utils)

# Mevcut Ensembl 116 dosyan
ensembl_file <- "C:/Users/lenovo/Documents/CiliaHub_Gene_Universe1/Homo_sapiens.GRCh38.116.gtf.gz"

# Gzip'i a??
gtf_uncompressed <- gunzip(
  ensembl_file,
  remove = FALSE,
  overwrite = TRUE
)

cat(
  "Uncompressed GTF:",
  gtf_uncompressed,
  "\n"
)

# GTF'yi oku
gtf <- data.table::fread(
  gtf_uncompressed,
  sep = "\t",
  header = FALSE,
  quote = "",
  comment.char = "#",
  data.table = FALSE
)

colnames(gtf) <- c(
  "chromosome",
  "source",
  "feature",
  "start",
  "end",
  "score",
  "strand",
  "frame",
  "attribute"
)

cat("\n")
cat("============================================\n")
cat("ENSEMBL 116 GTF LOADED\n")
cat("============================================\n")

cat(
  "Total GTF rows:",
  nrow(gtf),
  "\n"
)

cat(
  "Gene records:",
  sum(gtf$feature == "gene"),
  "\n"
)



cat("\n")
cat("============================================\n")
cat("ENSEMBL 116 QC\n")
cat("============================================\n")

cat(
  "Gene records:",
  nrow(ensembl_genes),
  "\n"
)

cat(
  "Unique Ensembl IDs:",
  dplyr::n_distinct(
    ensembl_genes$ensembl_gene_id
  ),
  "\n"
)

cat(
  "Unique gene symbols:",
  dplyr::n_distinct(
    ensembl_genes$gene_name,
    na.rm = TRUE
  ),
  "\n"
)

cat(
  "Protein-coding:",
  sum(
    ensembl_genes$gene_biotype == "protein_coding",
    na.rm = TRUE
  ),
  "\n"
)


































library(dplyr)
library(stringr)

# ============================================================
# ENSEMBL 116 ??? GENE LEVEL ANNOTATION
# ============================================================

ensembl_genes <- gtf %>%
  filter(feature == "gene") %>%
  mutate(
    
    # Ensembl Gene ID
    ensembl_gene_id = str_extract(
      attribute,
      '(?<=gene_id ")[^"]+'
    ),
    
    # Official Ensembl gene name / symbol
    gene_name = str_extract(
      attribute,
      '(?<=gene_name ")[^"]+'
    ),
    
    # Gene biotype
    gene_biotype = str_extract(
      attribute,
      '(?<=gene_biotype ")[^"]+'
    )
    
  ) %>%
  select(
    ensembl_gene_id,
    gene_name,
    gene_biotype,
    chromosome,
    start,
    end,
    strand
  ) %>%
  distinct(
    ensembl_gene_id,
    .keep_all = TRUE
  )


# ============================================================
# QC
# ============================================================

cat("\n")
cat("============================================\n")
cat("ENSEMBL 116 GENE-LEVEL QC\n")
cat("============================================\n")

cat(
  "Gene records:",
  nrow(ensembl_genes),
  "\n"
)

cat(
  "Unique Ensembl IDs:",
  dplyr::n_distinct(
    ensembl_genes$ensembl_gene_id,
    na.rm = TRUE
  ),
  "\n"
)

cat(
  "Unique gene names:",
  dplyr::n_distinct(
    ensembl_genes$gene_name,
    na.rm = TRUE
  ),
  "\n"
)

cat(
  "Protein-coding genes:",
  sum(
    ensembl_genes$gene_biotype == "protein_coding",
    na.rm = TRUE
  ),
  "\n"
)

cat(
  "Missing Ensembl IDs:",
  sum(
    is.na(ensembl_genes$ensembl_gene_id)
  ),
  "\n"
)

cat(
  "Missing gene names:",
  sum(
    is.na(ensembl_genes$gene_name)
  ),
  "\n"
)

cat(
  "Missing biotypes:",
  sum(
    is.na(ensembl_genes$gene_biotype)
  ),
  "\n"
)

cat("============================================\n")



















# ============================================================
# CiliaHub ??? HGNC APPROVED + PROTEIN-CODING GENE UNIVERSE
# Ensembl 116 + Current HGNC Complete Set
# ============================================================

library(data.table)
library(dplyr)
library(tidyr)
library(stringr)

# ------------------------------------------------------------
# 1. Output directory
# ------------------------------------------------------------

output_dir <- "C:/Users/lenovo/Documents/CiliaHub_Gene_Universe1"

if (!dir.exists(output_dir)) {
  dir.create(output_dir, recursive = TRUE)
}


# ------------------------------------------------------------
# 2. Download current HGNC complete set
# ------------------------------------------------------------

hgnc_url <- paste0(
  "https://storage.googleapis.com/",
  "public-download-files/hgnc/tsv/tsv/",
  "hgnc_complete_set.txt"
)

hgnc_file <- file.path(
  output_dir,
  "hgnc_complete_set.txt"
)

if (!file.exists(hgnc_file)) {
  
  download.file(
    hgnc_url,
    hgnc_file,
    mode = "wb"
  )
  
}


# ------------------------------------------------------------
# 3. Read HGNC complete set
# ------------------------------------------------------------

hgnc <- data.table::fread(
  hgnc_file,
  sep = "\t",
  header = TRUE,
  quote = "",
  data.table = FALSE,
  fill = TRUE
)

cat("\n")
cat("============================================\n")
cat("HGNC COMPLETE SET\n")
cat("============================================\n")

cat(
  "Total HGNC records:",
  nrow(hgnc),
  "\n"
)

cat(
  "Columns:",
  ncol(hgnc),
  "\n"
)


# ------------------------------------------------------------
# 4. Check column names
# ------------------------------------------------------------

cat("\nHGNC columns:\n")
print(colnames(hgnc))


# ------------------------------------------------------------
# 5. Standardize column names
# ------------------------------------------------------------

colnames(hgnc) <- tolower(
  gsub(
    "[^A-Za-z0-9]+",
    "_",
    colnames(hgnc)
  )
)

# Remove leading/trailing underscores
colnames(hgnc) <- gsub(
  "^_|_$",
  "",
  colnames(hgnc)
)


# ------------------------------------------------------------
# 6. HGNC approved genes
# ------------------------------------------------------------

hgnc_approved <- hgnc %>%
  filter(
    status == "Approved"
  )

cat("\n")
cat(
  "HGNC Approved records:",
  nrow(hgnc_approved),
  "\n"
)


# ------------------------------------------------------------
# 7. HGNC protein-coding genes
# ------------------------------------------------------------

hgnc_protein_coding <- hgnc_approved %>%
  filter(
    locus_group == "protein-coding gene"
  )

cat(
  "HGNC Approved protein-coding:",
  nrow(hgnc_protein_coding),
  "\n"
)


# ------------------------------------------------------------
# 8. Clean Ensembl IDs
# ------------------------------------------------------------

hgnc_protein_coding <- hgnc_protein_coding %>%
  filter(
    !is.na(ensembl_gene_id),
    ensembl_gene_id != ""
  ) %>%
  mutate(
    ensembl_gene_id = str_trim(
      ensembl_gene_id
    )
  )


# ------------------------------------------------------------
# 9. Handle possible multiple Ensembl IDs
# ------------------------------------------------------------

hgnc_protein_coding <- hgnc_protein_coding %>%
  separate_rows(
    ensembl_gene_id,
    sep = "\\|"
  ) %>%
  mutate(
    ensembl_gene_id = str_trim(
      ensembl_gene_id
    )
  ) %>%
  filter(
    ensembl_gene_id != ""
  )


# ------------------------------------------------------------
# 10. Prepare Ensembl 116 protein-coding genes
# ------------------------------------------------------------

ensembl_pc <- ensembl_genes %>%
  filter(
    gene_biotype == "protein_coding"
  ) %>%
  select(
    ensembl_gene_id,
    gene_name,
    gene_biotype,
    chromosome,
    start,
    end,
    strand
  ) %>%
  distinct(
    ensembl_gene_id,
    .keep_all = TRUE
  )


cat("\n")
cat(
  "Ensembl 116 protein-coding:",
  nrow(ensembl_pc),
  "\n"
)


# ------------------------------------------------------------
# 11. Merge Ensembl 116 + HGNC
# ------------------------------------------------------------

final_gene_universe <- ensembl_pc %>%
  inner_join(
    hgnc_protein_coding,
    by = "ensembl_gene_id"
  )


# ------------------------------------------------------------
# 12. Remove duplicated Ensembl IDs
# ------------------------------------------------------------

final_gene_universe <- final_gene_universe %>%
  distinct(
    ensembl_gene_id,
    .keep_all = TRUE
  )


# ------------------------------------------------------------
# 13. Final QC
# ------------------------------------------------------------

cat("\n")
cat("============================================\n")
cat("FINAL CiliaHub GENE UNIVERSE\n")
cat("============================================\n")

cat(
  "Final genes:",
  nrow(final_gene_universe),
  "\n"
)

cat(
  "Unique Ensembl IDs:",
  n_distinct(
    final_gene_universe$ensembl_gene_id
  ),
  "\n"
)

cat(
  "Unique HGNC symbols:",
  n_distinct(
    final_gene_universe$symbol
  ),
  "\n"
)

cat(
  "Missing HGNC symbols:",
  sum(
    is.na(final_gene_universe$symbol) |
      final_gene_universe$symbol == ""
  ),
  "\n"
)

cat(
  "Missing HGNC IDs:",
  sum(
    is.na(final_gene_universe$hgnc_id) |
      final_gene_universe$hgnc_id == ""
  ),
  "\n"
)

cat(
  "Missing Ensembl IDs:",
  sum(
    is.na(final_gene_universe$ensembl_gene_id) |
      final_gene_universe$ensembl_gene_id == ""
  ),
  "\n"
)

cat("============================================\n")


# ------------------------------------------------------------
# 14. Create clean final table
# ------------------------------------------------------------

final_gene_table <- final_gene_universe %>%
  transmute(
    
    Gene = symbol,
    
    HGNC_ID = hgnc_id,
    
    Ensembl_Gene_ID = ensembl_gene_id,
    
    HGNC_Name = name,
    
    Gene_Biotype = gene_biotype,
    
    HGNC_Locus_Group = locus_group,
    
    HGNC_Locus_Type = locus_type,
    
    Chromosome = chromosome,
    
    Start = start,
    
    End = end,
    
    Strand = strand
    
  ) %>%
  arrange(
    Gene
  )


# ------------------------------------------------------------
# 15. Final duplicate checks
# ------------------------------------------------------------

cat("\n")
cat("FINAL DUPLICATE CHECK\n")
cat("--------------------------------------------\n")

cat(
  "Duplicated Gene symbols:",
  sum(
    duplicated(final_gene_table$Gene)
  ),
  "\n"
)

cat(
  "Duplicated HGNC IDs:",
  sum(
    duplicated(final_gene_table$HGNC_ID)
  ),
  "\n"
)

cat(
  "Duplicated Ensembl IDs:",
  sum(
    duplicated(final_gene_table$Ensembl_Gene_ID)
  ),
  "\n"
)


# ------------------------------------------------------------
# 16. Save detailed annotation table
# ------------------------------------------------------------

write.table(
  final_gene_table,
  file = file.path(
    output_dir,
    "CiliaHub_Ensembl116_HGNC_ProteinCoding.tsv"
  ),
  sep = "\t",
  row.names = FALSE,
  quote = FALSE,
  na = ""
)


# ------------------------------------------------------------
# 17. Create PubMed mining gene list
# ------------------------------------------------------------

pubmed_gene_list <- final_gene_table %>%
  select(
    Gene
  ) %>%
  distinct() %>%
  arrange(
    Gene
  )


write.table(
  pubmed_gene_list,
  file = file.path(
    output_dir,
    "CiliaHub_PubMed_Mining_Gene_List.tsv"
  ),
  sep = "\t",
  row.names = FALSE,
  quote = FALSE,
  na = ""
)


# ------------------------------------------------------------
# 18. Save QC summary
# ------------------------------------------------------------

qc_summary <- data.frame(
  
  Metric = c(
    "Ensembl_116_gene_records",
    "Ensembl_116_protein_coding",
    "HGNC_approved",
    "HGNC_approved_protein_coding",
    "Final_intersection",
    "Unique_final_HGNC_symbols",
    "Unique_final_Ensembl_IDs"
  ),
  
  Value = c(
    nrow(ensembl_genes),
    nrow(ensembl_pc),
    nrow(hgnc_approved),
    nrow(hgnc_protein_coding),
    nrow(final_gene_table),
    n_distinct(final_gene_table$Gene),
    n_distinct(final_gene_table$Ensembl_Gene_ID)
  )
  
)


write.table(
  qc_summary,
  file = file.path(
    output_dir,
    "CiliaHub_Gene_Universe_QC.tsv"
  ),
  sep = "\t",
  row.names = FALSE,
  quote = FALSE
)


# ------------------------------------------------------------
# 19. Save metadata
# ------------------------------------------------------------

metadata <- c(
  
  "CiliaHub Human Gene Universe",
  "============================================",
  paste0(
    "Ensembl release: 116"
  ),
  paste0(
    "Ensembl assembly: GRCh38.p14"
  ),
  paste0(
    "HGNC dataset: current complete set"
  ),
  paste0(
    "HGNC filter: status == Approved"
  ),
  paste0(
    "HGNC filter: locus_group == protein-coding gene"
  ),
  paste0(
    "Ensembl filter: gene_biotype == protein_coding"
  ),
  paste0(
    "Final set: intersection of Ensembl and HGNC"
  ),
  paste0(
    "Generated: ",
    format(
      Sys.time(),
      "%Y-%m-%d %H:%M:%S"
    )
  )
  
)


writeLines(
  metadata,
  con = file.path(
    output_dir,
    "CiliaHub_Gene_Universe_Metadata.txt"
  )
)


# ------------------------------------------------------------
# DONE
# ------------------------------------------------------------

cat("\n")
cat("============================================\n")
cat("DONE\n")
cat("============================================\n")

cat(
  "Final gene universe:",
  nrow(final_gene_table),
  "genes\n"
)

cat(
  "Output directory:\n",
  output_dir,
  "\n"
)

cat("\nFiles created:\n")

cat(
  "1. CiliaHub_Ensembl116_HGNC_ProteinCoding.tsv\n"
)

cat(
  "2. CiliaHub_PubMed_Mining_Gene_List.tsv\n"
)

cat(
  "3. CiliaHub_Gene_Universe_QC.tsv\n"
)

cat(
  "4. CiliaHub_Gene_Universe_Metadata.txt\n"
)

cat("============================================\n")



# ============================================================
# CHECK ENSEMBL PROTEIN-CODING GENES NOT IN FINAL HGNC SET
# ============================================================

excluded_from_final <- ensembl_pc %>%
  anti_join(
    final_gene_table,
    by = c(
      "ensembl_gene_id" = "Ensembl_Gene_ID"
    )
  )

cat("\n")
cat("============================================\n")
cat("EXCLUDED ENSEMBL PROTEIN-CODING GENES\n")
cat("============================================\n")

cat(
  "Ensembl protein-coding:",
  nrow(ensembl_pc),
  "\n"
)

cat(
  "Final universe:",
  nrow(final_gene_table),
  "\n"
)

cat(
  "Excluded:",
  nrow(excluded_from_final),
  "\n"
)

cat(
  "Excluded with gene name:",
  sum(!is.na(excluded_from_final$gene_name)),
  "\n"
)

cat("\nExamples:\n")

print(
  head(
    excluded_from_final,
    20
  )
)

# Save
write.table(
  excluded_from_final,
  file = file.path(
    output_dir,
    "CiliaHub_Excluded_Ensembl_ProteinCoding.tsv"
  ),
  sep = "\t",
  row.names = FALSE,
  quote = FALSE,
  na = ""
)








# ============================================================
# HGNC PROTEIN-CODING GENES WITHOUT ENSEMBL 116 MATCH
# ============================================================

hgnc_not_in_ensembl <- hgnc_protein_coding %>%
  anti_join(
    ensembl_pc,
    by = "ensembl_gene_id"
  )

cat("\n")
cat("============================================\n")
cat("HGNC PROTEIN-CODING WITHOUT ENSEMBL 116 MATCH\n")
cat("============================================\n")

cat(
  "HGNC approved protein-coding:",
  nrow(hgnc_protein_coding),
  "\n"
)

cat(
  "Not matched to Ensembl 116:",
  nrow(hgnc_not_in_ensembl),
  "\n"
)

print(
  head(
    hgnc_not_in_ensembl %>%
      select(
        hgnc_id,
        symbol,
        name,
        locus_group,
        locus_type,
        ensembl_gene_id
      ),
    20
  )
)

write.table(
  hgnc_not_in_ensembl,
  file = file.path(
    output_dir,
    "CiliaHub_HGNC_Not_Matched_Ensembl116.tsv"
  ),
  sep = "\t",
  row.names = FALSE,
  quote = FALSE,
  na = ""
)













# ============================================================
# INVESTIGATE THE 40 HGNC GENES NOT MATCHED TO
# ENSEMBL 116 PROTEIN-CODING GENES
# ============================================================

hgnc_40_check <- hgnc_not_in_ensembl %>%
  select(
    hgnc_id,
    symbol,
    name,
    locus_group,
    locus_type,
    ensembl_gene_id
  ) %>%
  left_join(
    ensembl_genes %>%
      select(
        ensembl_gene_id,
        gene_name,
        gene_biotype
      ),
    by = "ensembl_gene_id"
  )

# ------------------------------------------------------------
# QC
# ------------------------------------------------------------

cat("\n")
cat("============================================\n")
cat("HGNC 40-MATCH INVESTIGATION\n")
cat("============================================\n")

cat(
  "Total HGNC unmatched:",
  nrow(hgnc_40_check),
  "\n"
)

cat(
  "Found anywhere in Ensembl 116:",
  sum(!is.na(hgnc_40_check$gene_biotype)),
  "\n"
)

cat(
  "Not found anywhere in Ensembl 116:",
  sum(is.na(hgnc_40_check$gene_biotype)),
  "\n"
)

cat("\n")
cat("Biotypes of matched records:\n")

print(
  table(
    hgnc_40_check$gene_biotype,
    useNA = "ifany"
  )
)

cat("\n")
cat("Full list:\n")

print(
  hgnc_40_check,
  n = Inf
)

# ------------------------------------------------------------
# Save
# ------------------------------------------------------------

write.table(
  hgnc_40_check,
  file = file.path(
    output_dir,
    "CiliaHub_HGNC_40_Mismatch_Investigation.tsv"
  ),
  sep = "\t",
  row.names = FALSE,
  quote = FALSE,
  na = ""
)








# ============================================================
# FINAL GENE UNIVERSE ??? FINAL QC
# ============================================================

cat("\n")
cat("====================================================\n")
cat("CiliaHub FINAL HUMAN GENE UNIVERSE QC\n")
cat("====================================================\n")

cat(
  "Final genes:",
  nrow(final_gene_table),
  "\n"
)

cat(
  "Unique Gene symbols:",
  n_distinct(final_gene_table$Gene),
  "\n"
)

cat(
  "Unique HGNC IDs:",
  n_distinct(final_gene_table$HGNC_ID),
  "\n"
)

cat(
  "Unique Ensembl IDs:",
  n_distinct(final_gene_table$Ensembl_Gene_ID),
  "\n"
)

cat(
  "Protein-coding:",
  sum(
    final_gene_table$Gene_Biotype == "protein_coding"
  ),
  "\n"
)

cat(
  "HGNC Approved:",
  sum(
    final_gene_table$HGNC_Locus_Group ==
      "protein-coding gene"
  ),
  "\n"
)

cat(
  "Missing Gene:",
  sum(
    is.na(final_gene_table$Gene) |
      final_gene_table$Gene == ""
  ),
  "\n"
)

cat(
  "Missing HGNC ID:",
  sum(
    is.na(final_gene_table$HGNC_ID) |
      final_gene_table$HGNC_ID == ""
  ),
  "\n"
)

cat(
  "Missing Ensembl ID:",
  sum(
    is.na(final_gene_table$Ensembl_Gene_ID) |
      final_gene_table$Ensembl_Gene_ID == ""
  ),
  "\n"
)

cat(
  "Duplicate Gene:",
  sum(duplicated(final_gene_table$Gene)),
  "\n"
)

cat(
  "Duplicate HGNC ID:",
  sum(duplicated(final_gene_table$HGNC_ID)),
  "\n"
)

cat(
  "Duplicate Ensembl ID:",
  sum(
    duplicated(
      final_gene_table$Ensembl_Gene_ID
    )
  ),
  "\n"
)

cat("====================================================\n")







































# ============================================================
# CiliaHub - PubMed Search Symbol List
# Current + HGNC Alias + Previous Symbols
#
# Final gene universe:
#   Ensembl 116 protein-coding
#   ??? HGNC approved protein-coding
#   = 19,214 genes
#
# Purpose:
#   Prepare PubMed search terms without changing the
#   underlying gene universe.
# ============================================================


# ------------------------------------------------------------
# 1. Packages
# ------------------------------------------------------------

library(readr)
library(dplyr)
library(tidyr)
library(stringr)


# ------------------------------------------------------------
# 2. Paths
# ------------------------------------------------------------

base_dir <- "C:/Users/lenovo/Documents/CiliaHub_Gene_Universe1"

gene_file <- file.path(
  base_dir,
  "CiliaHub_Ensembl116_HGNC_ProteinCoding.tsv"
)

# Put your HGNC complete-set file here
hgnc_file <- file.path(
  base_dir,
  "hgnc_complete_set.txt"
)

output_dir <- base_dir


# ------------------------------------------------------------
# 3. Check files
# ------------------------------------------------------------

if (!file.exists(gene_file)) {
  stop(
    "Final gene universe file not found:\n",
    gene_file
  )
}

if (!file.exists(hgnc_file)) {
  stop(
    "HGNC complete set file not found:\n",
    hgnc_file,
    "\n\nPlease put the HGNC complete set TXT file in:\n",
    base_dir
  )
}


# ------------------------------------------------------------
# 4. Read final 19,214-gene universe
# ------------------------------------------------------------

gene_universe <- read_tsv(
  gene_file,
  show_col_types = FALSE,
  progress = TRUE
)

cat("\n========================================\n")
cat("FINAL GENE UNIVERSE QC\n")
cat("========================================\n")

cat("Rows:", nrow(gene_universe), "\n")
cat("Unique genes:", n_distinct(gene_universe$Gene), "\n")
cat("Unique HGNC IDs:", n_distinct(gene_universe$HGNC_ID), "\n")
cat("Unique Ensembl IDs:", n_distinct(gene_universe$Ensembl_Gene_ID), "\n")


# ------------------------------------------------------------
# 5. Read HGNC complete set
# ------------------------------------------------------------

hgnc <- read_tsv(
  hgnc_file,
  show_col_types = FALSE,
  progress = TRUE,
  quote = "\""
)

cat("\n========================================\n")
cat("HGNC QC\n")
cat("========================================\n")

cat("HGNC records:", nrow(hgnc), "\n")

cat(
  "Required columns present:",
  all(
    c(
      "hgnc_id",
      "symbol",
      "status",
      "locus_group",
      "ensembl_gene_id",
      "alias_symbol",
      "prev_symbol"
    ) %in% colnames(hgnc)
  ),
  "\n"
)


# ------------------------------------------------------------
# 6. Keep only HGNC-approved protein-coding genes
# ------------------------------------------------------------

hgnc_pc <- hgnc %>%
  filter(
    status == "Approved",
    locus_group == "protein-coding gene",
    !is.na(ensembl_gene_id),
    ensembl_gene_id != ""
  ) %>%
  select(
    hgnc_id,
    symbol,
    name,
    ensembl_gene_id,
    alias_symbol,
    prev_symbol
  )


cat("\nHGNC approved protein-coding:", nrow(hgnc_pc), "\n")


# ------------------------------------------------------------
# 7. Match HGNC to the 19,214 final genes
# ------------------------------------------------------------

hgnc_final <- gene_universe %>%
  select(
    Gene,
    HGNC_ID,
    Ensembl_Gene_ID
  ) %>%
  inner_join(
    hgnc_pc,
    by = c(
      "HGNC_ID" = "hgnc_id",
      "Gene" = "symbol",
      "Ensembl_Gene_ID" = "ensembl_gene_id"
    )
  )


cat("\n========================================\n")
cat("FINAL MATCH QC\n")
cat("========================================\n")

cat("Final genes:", nrow(gene_universe), "\n")
cat("Matched to HGNC:", nrow(hgnc_final), "\n")


if (nrow(hgnc_final) != nrow(gene_universe)) {
  
  warning(
    "WARNING: HGNC matching does not equal 19,214 genes!"
  )
  
}


# ------------------------------------------------------------
# 8. Create CURRENT symbols
# ------------------------------------------------------------

current_symbols <- hgnc_final %>%
  transmute(
    Gene,
    HGNC_ID,
    Ensembl_Gene_ID,
    Search_Symbol = Gene,
    Symbol_Type = "Current"
  )


# ------------------------------------------------------------
# 9. Create ALIAS symbols
# ------------------------------------------------------------

alias_symbols <- hgnc_final %>%
  select(
    Gene,
    HGNC_ID,
    Ensembl_Gene_ID,
    alias_symbol
  ) %>%
  filter(
    !is.na(alias_symbol),
    alias_symbol != ""
  ) %>%
  separate_rows(
    alias_symbol,
    sep = "\\|"
  ) %>%
  mutate(
    alias_symbol = str_trim(alias_symbol)
  ) %>%
  filter(
    alias_symbol != "",
    alias_symbol != Gene
  ) %>%
  transmute(
    Gene,
    HGNC_ID,
    Ensembl_Gene_ID,
    Search_Symbol = alias_symbol,
    Symbol_Type = "Alias"
  )


# ------------------------------------------------------------
# 10. Create PREVIOUS symbols
# ------------------------------------------------------------

previous_symbols <- hgnc_final %>%
  select(
    Gene,
    HGNC_ID,
    Ensembl_Gene_ID,
    prev_symbol
  ) %>%
  filter(
    !is.na(prev_symbol),
    prev_symbol != ""
  ) %>%
  separate_rows(
    prev_symbol,
    sep = "\\|"
  ) %>%
  mutate(
    prev_symbol = str_trim(prev_symbol)
  ) %>%
  filter(
    prev_symbol != "",
    prev_symbol != Gene
  ) %>%
  transmute(
    Gene,
    HGNC_ID,
    Ensembl_Gene_ID,
    Search_Symbol = prev_symbol,
    Symbol_Type = "Previous"
  )


# ------------------------------------------------------------
# 11. Combine all search symbols
# ------------------------------------------------------------

search_symbols <- bind_rows(
  current_symbols,
  alias_symbols,
  previous_symbols
)


# ------------------------------------------------------------
# 12. Remove exact duplicate Gene + Search_Symbol
# ------------------------------------------------------------

search_symbols <- search_symbols %>%
  distinct(
    Gene,
    Search_Symbol,
    .keep_all = TRUE
  )


# ------------------------------------------------------------
# 13. If same symbol occurs as Alias and Previous,
#     prioritize Current > Previous > Alias
# ------------------------------------------------------------

search_symbols <- search_symbols %>%
  mutate(
    Symbol_Type = factor(
      Symbol_Type,
      levels = c(
        "Current",
        "Previous",
        "Alias"
      )
    )
  ) %>%
  arrange(
    Gene,
    Symbol_Type,
    Search_Symbol
  ) %>%
  distinct(
    Gene,
    Search_Symbol,
    .keep_all = TRUE
  ) %>%
  mutate(
    Symbol_Type = as.character(Symbol_Type)
  )


# ------------------------------------------------------------
# 14. Add number of search symbols per gene
# ------------------------------------------------------------

search_symbols <- search_symbols %>%
  group_by(Gene) %>%
  mutate(
    Number_of_Search_Symbols = n()
  ) %>%
  ungroup()


# ------------------------------------------------------------
# 15. QC
# ------------------------------------------------------------

cat("\n========================================\n")
cat("SEARCH SYMBOL QC\n")
cat("========================================\n")

cat(
  "Total search rows:",
  nrow(search_symbols),
  "\n"
)

cat(
  "Unique genes:",
  n_distinct(search_symbols$Gene),
  "\n"
)

cat(
  "Current:",
  sum(search_symbols$Symbol_Type == "Current"),
  "\n"
)

cat(
  "Previous:",
  sum(search_symbols$Symbol_Type == "Previous"),
  "\n"
)

cat(
  "Alias:",
  sum(search_symbols$Symbol_Type == "Alias"),
  "\n"
)

cat(
  "Unique search symbols:",
  n_distinct(search_symbols$Search_Symbol),
  "\n"
)


# ------------------------------------------------------------
# 16. Check that every one of the 19,214 genes has
#     at least one search symbol
# ------------------------------------------------------------

missing_genes <- gene_universe %>%
  anti_join(
    search_symbols,
    by = "Gene"
  )


cat(
  "\nGenes without ANY search symbol:",
  nrow(missing_genes),
  "\n"
)


if (nrow(missing_genes) > 0) {
  
  print(missing_genes)
  
  stop(
    "Some genes do not have a search symbol."
  )
  
}


# ------------------------------------------------------------
# 17. Check duplicate Gene + Search_Symbol
# ------------------------------------------------------------

duplicate_check <- search_symbols %>%
  count(
    Gene,
    Search_Symbol
  ) %>%
  filter(n > 1)


cat(
  "Duplicate Gene + Search_Symbol pairs:",
  nrow(duplicate_check),
  "\n"
)


# ------------------------------------------------------------
# 18. Save main search-symbol table
# ------------------------------------------------------------

search_symbol_file <- file.path(
  output_dir,
  "CiliaHub_PubMed_Search_Symbols.tsv"
)

write_tsv(
  search_symbols,
  search_symbol_file
)


# ------------------------------------------------------------
# 19. Create gene-level QC summary
# ------------------------------------------------------------

search_symbol_qc <- search_symbols %>%
  group_by(Gene) %>%
  summarise(
    HGNC_ID = first(HGNC_ID),
    Ensembl_Gene_ID = first(Ensembl_Gene_ID),
    
    Current_Symbols =
      sum(Symbol_Type == "Current"),
    
    Previous_Symbols =
      sum(Symbol_Type == "Previous"),
    
    Alias_Symbols =
      sum(Symbol_Type == "Alias"),
    
    Total_Search_Symbols =
      n(),
    
    .groups = "drop"
  ) %>%
  arrange(Gene)


qc_file <- file.path(
  output_dir,
  "CiliaHub_PubMed_Search_Symbols_QC.tsv"
)

write_tsv(
  search_symbol_qc,
  qc_file
)


# ------------------------------------------------------------
# 20. Create a compact gene-level query table
# ------------------------------------------------------------

query_table <- search_symbols %>%
  group_by(
    Gene,
    HGNC_ID,
    Ensembl_Gene_ID
  ) %>%
  summarise(
    Search_Symbols = paste(
      unique(Search_Symbol),
      collapse = " | "
    ),
    Number_of_Search_Symbols = n(),
    .groups = "drop"
  ) %>%
  arrange(Gene)


query_file <- file.path(
  output_dir,
  "CiliaHub_PubMed_Gene_Search_Terms.tsv"
)

write_tsv(
  query_table,
  query_file
)


# ------------------------------------------------------------
# 21. Final report
# ------------------------------------------------------------

cat("\n========================================\n")
cat("FILES CREATED\n")
cat("========================================\n")

cat(
  "1.",
  search_symbol_file,
  "\n"
)

cat(
  "2.",
  qc_file,
  "\n"
)

cat(
  "3.",
  query_file,
  "\n"
)


cat("\n========================================\n")
cat("FINAL RESULT\n")
cat("========================================\n")

cat(
  "Genes in universe:",
  n_distinct(search_symbols$Gene),
  "\n"
)

cat(
  "Total search symbols:",
  nrow(search_symbols),
  "\n"
)

cat(
  "Current symbols:",
  sum(search_symbols$Symbol_Type == "Current"),
  "\n"
)

cat(
  "Previous symbols:",
  sum(search_symbols$Symbol_Type == "Previous"),
  "\n"
)

cat(
  "Alias symbols:",
  sum(search_symbols$Symbol_Type == "Alias"),
  "\n"
)

cat(
  "Genes with >1 search symbol:",
  sum(search_symbol_qc$Total_Search_Symbols > 1),
  "\n"
)

cat(
  "Genes with no synonym:",
  sum(search_symbol_qc$Total_Search_Symbols == 1),
  "\n"
)

cat("\nDONE.\n")
