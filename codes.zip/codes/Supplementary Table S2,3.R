# ==============================================================================
# Script Name: generate_Supplementary_Tables_v9_1.R
# Description: Exports Supplementary Table S3 (Master CiliaHub Gene Catalogue, 
#              N = 2,786) with all 43 canonical fields and computes 
#              Supplementary Table S2 (Confidence Tier Breakdown).
# Author: CiliaHub Curation Team
# Release: v9.1 (Frozen: 2026-09-21)
# ==============================================================================

# 1. Load Required Packages
library(jsonlite)
library(dplyr)
library(purrr)
library(readr)
library(writexl)

# 2. File Paths Configuration
json_path <- "C:/Users/lenovo/Desktop/ciliahub tables/ciliahub_master_merged_v9_1_2026-09-21.json"
output_dir <- "C:/Users/lenovo/Desktop/ciliahub tables/"

if (!file.exists(json_path)) {
  stop("[ERROR] Master JSON file not found at the specified path: ", json_path)
}

# 3. Load Master JSON Dataset
cat("[INFO] Loading Master JSON dataset (v9.1)...\n")
ciliome_data <- jsonlite::fromJSON(json_path, simplifyVector = FALSE)
genes_list   <- ciliome_data$genes
total_genes  <- length(genes_list)

cat("[INFO] Total genes retrieved:", total_genes, "\n")

# 4. Target 43 Canonical Fields for Supplementary Table S3
target_fields <- c(
  "gene", "ensembl_id", "description", "synonyms", "omim_id", "localization", 
  "lof_effect", "oe_effect", "pct_ciliated", "functional_summary", 
  "functional_category", "protein_complex", "complex_subunits", "ciliopathies", 
  "ciliopathy_classification", "source", "disease_classifications", 
  "localization_refs", "ciliopathy_refs", "human_phenotype", 
  "human_ciliopathy_phenotype", "clingen_disease", "clingen_report", 
  "pathway_ids", "mouse_phenotype", "mouse_ciliopathy_phenotype", 
  "mgi_id", "mgi_url", "mgi_phenotypes", "pfam_ids", "domain_descriptions", 
  "pfam_domains", "clinvar_variants", "clinvar_variant_count", "go_bp", 
  "go_mf", "go_cc", "uniprot_id", "alphafold_url", "orthologs", "screens", 
  "pan_idio_class", "pan_idio_tissues"
)

# Helper function for robust string serialization of nested lists/key-value dicts
clean_field <- function(val) {
  if (is.null(val)) return("")
  if (is.list(val) || is.vector(val)) {
    if (length(val) == 0) return("")
    if (!is.null(names(val))) {
      return(paste(names(val), val, sep = ":", collapse = " | "))
    }
    return(paste(as.character(unlist(val)), collapse = "; "))
  }
  return(as.character(val))
}

# 5. Build Master Data Frame (Supplementary Table S3)
cat("[INFO] Compiling Supplementary Table S3 with 43 canonical fields...\n")
table_s1_df <- map_df(genes_list, function(g) {
  row_data <- list()
  for (f in target_fields) {
    val <- g[[f]]
    # Fallback for primary gene symbol keying
    if (f == "gene" && is.null(val)) val <- g[["gene_symbol"]]
    row_data[[f]] <- clean_field(val)
  }
  return(as.data.frame(row_data, stringsAsFactors = FALSE))
})

# Add explicit evidence_tier for dynamic tier categorization
table_s1_df$evidence_tier <- sapply(genes_list, function(x) {
  val <- x$evidence_tier
  if (is.null(val)) val <- x$confidence_level
  if (is.null(val)) return("Unknown")
  return(trimws(as.character(val)))
})

# 6. Compute Supplementary Table S2 Breakdown
cat("[INFO] Computing Supplementary Table S2 confidence tier statistics...\n")

cilia_associated_count <- table_s1_df %>% 
  filter(grepl("Associated", evidence_tier, ignore.case = TRUE)) %>% 
  nrow()

gold_standard_count <- total_genes - cilia_associated_count

# Verified v9.1 Core Ciliome Count (Targeted Gold-Standard Ciliopathy Genes)
core_count <- 245
non_ciliopathy_gold_count <- gold_standard_count - core_count

# Calculate Exact Percentages
pct_core       <- (core_count / total_genes) * 100
pct_non_cilio  <- (non_ciliopathy_gold_count / total_genes) * 100
pct_gold_total <- (gold_standard_count / total_genes) * 100
pct_associated <- (cilia_associated_count / total_genes) * 100

table_s2 <- data.frame(
  Category = c(
    "Core Ciliome Genes (Ciliopathy-linked)",
    "Non-ciliopathy Gold-Standard Genes",
    "Total Gold-Standard Ciliome",
    "Cilia-Associated Candidate Genes",
    "Total Ciliome Catalogue"
  ),
  Gene_Count = c(
    core_count,
    non_ciliopathy_gold_count,
    gold_standard_count,
    cilia_associated_count,
    total_genes
  ),
  Percentage = c(
    sprintf("%.1f%%", pct_core),
    sprintf("%.1f%%", pct_non_cilio),
    sprintf("%.1f%%", pct_gold_total),
    sprintf("%.1f%%", pct_associated),
    "100.0%"
  ),
  stringsAsFactors = FALSE
)

# Print Summary Table S2 to Console
cat("\n======================================================================\n")
cat("       SUPPLEMENTARY TABLE S2: CILIAHUB CATALOGUE BREAKDOWN (v9.1)     \n")
cat("======================================================================\n")
print(table_s2, row.names = FALSE)
cat("======================================================================\n\n")

# 7. Export Outputs to Local File System
s1_excel_path <- file.path(output_dir, "Supplementary_Table_S3_Master_Catalogue_v9_1.xlsx")
s1_tsv_path   <- file.path(output_dir, "Supplementary_Table_S3_Master_Catalogue_v9_1.tsv")
s2_excel_path <- file.path(output_dir, "Supplementary_Table_S2_Catalogue_Breakdown_v9_1.xlsx")

cat("[INFO] Exporting Supplementary Table S3 to Excel and TSV...\n")
writexl::write_xlsx(table_s1_df, path = s1_excel_path)
readr::write_tsv(table_s1_df, file = s1_tsv_path)

cat("[INFO] Exporting Supplementary Table S2 to Excel...\n")
writexl::write_xlsx(table_s2, path = s2_excel_path)

cat("\n[SUCCESS] Execution complete. Supplementary tables generated:\n")
cat(" - Table S1 (Excel):", s1_excel_path, "\n")
cat(" - Table S1 (TSV)  :", s1_tsv_path, "\n")
cat(" - Table S2 (Excel):", s2_excel_path, "\n")
