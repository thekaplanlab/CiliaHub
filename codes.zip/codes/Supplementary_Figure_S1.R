# ==============================================================================
# CiliaHub v9.1 Supplementary Figure S1 Generation Script
# Panel 1: Literature Mining Architecture
# Panel 2: Biological Curation Pipeline & Explicit 99 Ciliary Entities Scope
# ==============================================================================

required_packages <- c("ggplot2", "patchwork", "scales")
for (pkg in required_packages) {
  if (!requireNamespace(pkg, quietly = TRUE)) install.packages(pkg)
}

library(ggplot2)
library(patchwork)
library(scales)

# Color Palette Definitions
NAVY       <- "#0f172a"
BLUE_DARK  <- "#1e3a8a"
BLUE_MED   <- "#2563eb"
BLUE_LIGHT <- "#0284c7"
AMBER      <- "#d97706"
PINK       <- "#db2777"
EMERALD    <- "#059669"
GREY_BG    <- "#f8fafc"
TEXT_DARK  <- "#1e293b"

# ------------------------------------------------------------------------------
# PANEL 1: Literature Mining Architecture
# ------------------------------------------------------------------------------
build_panel_1 <- function() {
  tiers <- data.frame(
    title = c("Tier 1: Direct Ciliary Evidence", "Tier 2: Structure & Trafficking", "Tier 3: Ciliopathy & Disease"),
    genes = c("7,874 Genes", "4,417 Genes", "3,327 Genes"),
    pmids = c("135,254 PMIDs", "48,563 PMIDs", "29,600 PMIDs"),
    scope = c("Scope: cilia, cilium, axoneme, ciliary membrane, flagella, basal body transport",
              "Scope: transition zone, IFT, appendages, ciliary gate, assembly/disassembly",
              "Scope: Joubert, BBS, Meckel, PCD, Senior-Loken, ciliary diseases"),
    color = c(BLUE_LIGHT, AMBER, PINK),
    bg    = c("#f0f9ff", "#fffbeb", "#fdf2f8"),
    y_center = c(43.5, 30, 16.5)
  )
  
  ggplot() +
    # Outer Panel Card
    geom_rect(aes(xmin = 0, xmax = 48, ymin = 0, ymax = 94), fill = "#fffbeb", color = "#fde68a", linewidth = 0.8) +
    annotate("text", x = 24, y = 90, label = "1. Literature Mining Architecture", fontface = "bold", size = 4.5, color = "#b45309") +
    
    # Ensembl Gene Universe Card
    geom_rect(aes(xmin = 2, xmax = 46, ymin = 78, ymax = 86), fill = BLUE_DARK) +
    annotate("text", x = 24, y = 83, label = "Ensembl Release 116 Gene Universe", color = "white", fontface = "bold", size = 3.2) +
    annotate("text", x = 24, y = 80, label = "n = 45,045 HGNC Symbols  |  19,214 Protein-Coding Genes", color = "#93c5fd", fontface = "bold", size = 2.5) +
    
    annotate("segment", x = 24, xend = 24, y = 78, yend = 73.5, color = BLUE_DARK, linewidth = 0.8, arrow = arrow(length = unit(0.06, "inches"), type = "closed")) +
    
    # Mining 1 Card
    geom_rect(aes(xmin = 2, xmax = 46, ymin = 63.5, ymax = 73.5), fill = BLUE_MED) +
    annotate("text", x = 24, y = 70, label = "Mining 1: Broad PubMed Candidate Retrieval", color = "white", fontface = "bold", size = 3) +
    annotate("text", x = 24, y = 67, label = "Yield: 6,732 Candidate Genes (94,568 Publication Records)", color = "#f1f5f9", fontface = "bold", size = 2.5) +
    annotate("text", x = 24, y = 64.8, label = "Scope: Broad ciliary terms across Title & Abstract fields", color = "#bfdbfe", fontface = "italic", size = 2.2) +
    
    annotate("segment", x = 24, xend = 24, y = 63.5, yend = 58, color = BLUE_MED, linewidth = 0.8, arrow = arrow(length = unit(0.06, "inches"), type = "closed")) +
    
    # Mining 2 Subtitle
    annotate("text", x = 24, y = 55.5, label = "Mining 2: Synonym-Aware 3-Tier Categorization", fontface = "bold", size = 2.8, color = "#b45309") +
    
    # Tier Cards
    geom_rect(data = tiers, aes(xmin = 2, xmax = 46, ymin = y_center - 5.5, ymax = y_center + 6), fill = tiers$bg, color = tiers$color, linewidth = 0.8) +
    geom_rect(data = tiers, aes(xmin = 2, xmax = 46, ymin = y_center + 2.8, ymax = y_center + 6), fill = tiers$color) +
    geom_text(data = tiers, aes(x = 24, y = y_center + 4.4, label = title), color = "white", fontface = "bold", size = 2.8) +
    
    # Gene & PMID Badges
    geom_rect(data = tiers, aes(xmin = 4, xmax = 21, ymin = y_center - 2.8, ymax = y_center + 2), fill = "white", color = tiers$color, linewidth = 0.5) +
    geom_text(data = tiers, aes(x = 12.5, y = y_center - 0.4, label = genes), color = tiers$color, fontface = "bold", size = 3) +
    
    geom_rect(data = tiers, aes(xmin = 27, xmax = 44, ymin = y_center - 2.8, ymax = y_center + 2), fill = "white", color = "#cbd5e1", linewidth = 0.5) +
    geom_text(data = tiers, aes(x = 35.5, y = y_center - 0.4, label = pmids), color = TEXT_DARK, fontface = "bold", size = 2.8) +
    
    geom_text(data = tiers, aes(x = 24, y = y_center - 4.6, label = scope), color = "#475569", fontface = "italic", size = 2.1) +
    
    # Summary Card
    geom_rect(aes(xmin = 5, xmax = 43, ymin = 3.5, ymax = 7.7), fill = "#fef3c7", color = "#f59e0b", linewidth = 0.6) +
    annotate("text", x = 24, y = 5.6, label = "Total 8,289 Non-Redundant Candidate Genes Evaluated", fontface = "bold", size = 2.9, color = "#b45309") +
    
    scale_x_continuous(limits = c(0, 48), expand = c(0, 0)) +
    scale_y_continuous(limits = c(0, 94), expand = c(0, 0)) +
    theme_void()
}

# ------------------------------------------------------------------------------
# PANEL 2: Biological Curation Pipeline & Explicit 99 Ciliary Entities Scope
# ------------------------------------------------------------------------------
build_panel_2 <- function() {
  y_cil <- seq(48, 85, length.out = 100)
  x_cil_left  <- 12 - 1.5 * sin((y_cil - 48) / 37 * pi)
  x_cil_right <- 18 + 1.5 * sin((y_cil - 48) / 37 * pi)
  cil_df <- data.frame(x_left = x_cil_left, x_right = x_cil_right, y = y_cil)
  
  boxes_df <- data.frame(
    x1 = 28, x2 = 46,
    y1 = c(73, 58, 43, 28, 13),
    y2 = c(83, 68, 53, 38, 23),
    title = c("Ensembl 116 Universe", "Protein-Coding Genes", "PubMed Candidate Pool", "Expert Manual Curation", "CiliaHub v9.1 Release"),
    sub   = c("n = 45,045 symbols", "19,214 genes", "6,732 candidates", "2,102 initial genes", "2,786 unique genes"),
    fill  = c("#1e3a8a", "#1d4ed8", "#2563eb", "#3b82f6", NAVY)
  )
  
  # 99 Ciliary Entities Category Breakdown Box Data (Fully English)
  entities_df <- data.frame(
    y1 = c(33, 23, 13, 3),
    y2 = c(41, 31, 21, 11),
    cat_title = c("Major Compartments (10)", "Transport & Motors (15)", "Sub-structures & Micro-domains (24)", "Functional & Phenotypic Classes (50)"),
    cat_terms = c("Ciliary membrane, Axoneme, Transition zone, Basal body, Tip, Appendages, Flagellum, Centrosome, Satellites",
                  "IFT-A, IFT-B, BBSome, Outer/Inner Dynein Arms, Kinesin-2, Radial spokes, Central pair apparatus",
                  "Ciliary pocket, Gate, Diffusion barrier, Basal feet, Rootlet, Photoreceptor outer segment, Connecting cilium",
                  "Hedgehog signaling machinery, Ciliary length regulators, Ciliogenesis initiation, Motility apparatus"),
    border_col = c(BLUE_LIGHT, PINK, AMBER, EMERALD),
    bg_col     = c("#f0f9ff", "#fdf2f8", "#fffbeb", "#ecfdf5")
  )
  
  ggplot() +
    # Outer Panel Card
    geom_rect(aes(xmin = 0, xmax = 48, ymin = 0, ymax = 94), fill = "#f0f9ff", color = "#bae6fd", linewidth = 0.8) +
    annotate("text", x = 24, y = 90, label = "2. Biological Curation Pipeline & Ciliary Scope", fontface = "bold", size = 4.5, color = "#0369a1") +
    
    # Primary Cilium Structure
    geom_ribbon(data = cil_df, aes(y = y, xmin = x_left, xmax = x_right), fill = "#e0f2fe", alpha = 0.85) +
    geom_path(data = cil_df, aes(x = x_left, y = y), color = BLUE_LIGHT, linewidth = 1.1) +
    geom_path(data = cil_df, aes(x = x_right, y = y), color = BLUE_LIGHT, linewidth = 1.1) +
    
    annotate("segment", x = 13.6, xend = 13.6, y = 52, yend = 83, color = "#38bdf8", linetype = "dashed", linewidth = 0.6) +
    annotate("segment", x = 16.4, xend = 16.4, y = 52, yend = 83, color = "#38bdf8", linetype = "dashed", linewidth = 0.6) +
    
    # IFT Particles
    annotate("point", x = c(13.6, 16.4, 13.6), y = c(60, 70, 79), color = PINK, size = 2.5) +
    
    # Transition Zone & Basal Body
    geom_rect(aes(xmin = 10.5, xmax = 19.5, ymin = 49, ymax = 53), fill = "#f59e0b", color = AMBER) +
    annotate("text", x = 15, y = 51, label = "Transition Zone", color = "white", fontface = "bold", size = 2.2) +
    
    geom_rect(aes(xmin = 9.5, xmax = 20.5, ymin = 43, ymax = 48), fill = "#1e293b", color = NAVY) +
    annotate("text", x = 15, y = 45.5, label = "Basal Body", color = "white", fontface = "bold", size = 2.2) +
    
    # Cilium Compartment Labels
    annotate("text", x = 8.5, y = 82, label = "Ciliary Membrane", size = 2.2, fontface = "bold", color = BLUE_LIGHT, hjust = 1) +
    annotate("text", x = 8.5, y = 68, label = "Axoneme &\nIFT Trains", size = 2.2, fontface = "bold", color = PINK, hjust = 1) +
    
    # --- Curation Funnel Cards (Right Side) ---
    geom_rect(data = boxes_df, aes(xmin = x1, xmax = x2, ymin = y1, ymax = y2), fill = boxes_df$fill) +
    geom_text(data = boxes_df, aes(x = (x1 + x2)/2, y = (y1 + y2)/2 + 1.8, label = title), color = "white", fontface = "bold", size = 2.6) +
    geom_text(data = boxes_df, aes(x = (x1 + x2)/2, y = (y1 + y2)/2 - 2.2, label = sub), color = "#f1f5f9", size = 2.3) +
    
    # Downward Funnel Arrows
    annotate("segment", x = 37, xend = 37, y = 73, yend = 68, color = "#3b82f6", linewidth = 0.7, arrow = arrow(length = unit(0.05, "inches"), type = "closed")) +
    annotate("segment", x = 37, xend = 37, y = 58, yend = 53, color = "#3b82f6", linewidth = 0.7, arrow = arrow(length = unit(0.05, "inches"), type = "closed")) +
    annotate("segment", x = 37, xend = 37, y = 43, yend = 38, color = "#3b82f6", linewidth = 0.7, arrow = arrow(length = unit(0.05, "inches"), type = "closed")) +
    annotate("segment", x = 37, xend = 37, y = 28, yend = 23, color = "#3b82f6", linewidth = 0.7, arrow = arrow(length = unit(0.05, "inches"), type = "closed")) +
    
    # --- 99 CILIARY ENTITIES DETAILED CATEGORIES (Left Bottom Block) ---
    annotate("text", x = 13.5, y = 41.5, label = "Curated Controlled Vocabulary (99 Ciliary Entities)", fontface = "bold", size = 2.6, color = "#0f172a") +
    
    geom_rect(data = entities_df, aes(xmin = 2, xmax = 25, ymin = y1, ymax = y2), fill = entities_df$bg_col, color = entities_df$border_col, linewidth = 0.6) +
    geom_text(data = entities_df, aes(x = 2.5, y = (y1 + y2)/2 + 2, label = cat_title), color = entities_df$border_col, fontface = "bold", size = 2.3, hjust = 0) +
    geom_text(data = entities_df, aes(x = 2.5, y = (y1 + y2)/2 - 1.8, label = cat_terms), color = TEXT_DARK, fontface = "italic", size = 1.9, hjust = 0) +
    
    # Footnote
    annotate("text", x = 37, y = 7.5, label = "v9.1 Breakdown:\n2,179 Gold-Standard  |  607 Cilia-Associated", fontface = "bold", size = 2.2, color = "#334155") +
    
    scale_x_continuous(limits = c(0, 48), expand = c(0, 0)) +
    scale_y_continuous(limits = c(0, 94), expand = c(0, 0)) +
    theme_void()
}

# ------------------------------------------------------------------------------
# Composite Figure Assembly & High-Resolution Export
# ------------------------------------------------------------------------------
p1 <- build_panel_1()
p2 <- build_panel_2()

supplementary_figure_s1 <- p1 + p2 +
  plot_layout(ncol = 2, widths = c(1, 1)) +
  plot_annotation(
    theme = theme(
      plot.background = element_rect(fill = GREY_BG, color = NA)
    )
  )

# Export High-Resolution PNG (300 DPI) and Vector PDF
ggsave("Supplementary_Figure_S1_2.png", plot = supplementary_figure_s1, width = 15, height = 8.2, dpi = 300)
ggsave("Supplementary_Figure_S1_2.pdf", plot = supplementary_figure_s1, width = 15, height = 8.2)

cat("SUCCESS: Supplementary_Figure_S1.png and Supplementary_Figure_S1.pdf successfully created containing all 99 ciliary entities!\n")
