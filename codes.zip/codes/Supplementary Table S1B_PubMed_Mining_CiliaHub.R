# ============================================================
# CiliaHub
# SYNONYM-AWARE PUBMED MINING PIPELINE
#
# Gene universe:
#   19,214 HGNC-approved protein-coding genes
#
# Search terms:
#   Current HGNC symbol
#   HGNC alias_symbol
#   HGNC prev_symbol
#
# Mining 1:
#   Broad cilia-related retrieval
#
# Mining 2:
#   Three-tier evidence retrieval
#
# Features:
#   - synonym-aware PubMed queries
#   - Title/Abstract restriction
#   - retry system
#   - checkpoint/resume
#   - XML parsing
#   - PMID + title extraction
#   - duplicate removal
#   - TSV output
# ============================================================


# ------------------------------------------------------------
# 1. Packages
# ------------------------------------------------------------

required_packages <- c(
  "rentrez",
  "xml2",
  "dplyr",
  "purrr",
  "readr",
  "stringr",
  "tidyr"
)

for (pkg in required_packages) {
  
  if (!requireNamespace(pkg, quietly = TRUE)) {
    install.packages(pkg)
  }
  
}

library(rentrez)
library(xml2)
library(dplyr)
library(purrr)
library(readr)
library(stringr)


# ------------------------------------------------------------
# 2. Paths
# ------------------------------------------------------------

input_file <- paste0(
  "C:/Users/lenovo/Documents/",
  "CiliaHub_Gene_Universe1/",
  "CiliaHub_PubMed_Gene_Search_Terms.tsv"
)

output_dir <- paste0(
  "C:/Users/lenovo/Documents/",
  "PubMed_Mining_CiliaHub_Final_Alias"
)

dir.create(
  output_dir,
  showWarnings = FALSE,
  recursive = TRUE
)


# ------------------------------------------------------------
# 3. Parameters
# ------------------------------------------------------------

max_results <- 200

retries <- 3

delay_mining1 <- 0.34

delay_mining2 <- 0.50

checkpoint_every <- 100

checkpoint_file <- file.path(
  output_dir,
  "CiliaHub_PubMed_Mining_Checkpoint_Alias_v2.rds"
)


# ------------------------------------------------------------
# 4. Read gene search table
# ------------------------------------------------------------

gene_search <- read_tsv(
  input_file,
  show_col_types = FALSE,
  progress = TRUE
)


# ------------------------------------------------------------
# 5. Basic QC
# ------------------------------------------------------------

cat("\n")
cat("================================================\n")
cat("INPUT QC\n")
cat("================================================\n")

cat(
  "Rows:",
  nrow(gene_search),
  "\n"
)

cat(
  "Unique genes:",
  n_distinct(gene_search$Gene),
  "\n"
)

cat(
  "Unique HGNC IDs:",
  n_distinct(gene_search$HGNC_ID),
  "\n"
)

cat(
  "Unique Ensembl IDs:",
  n_distinct(gene_search$Ensembl_Gene_ID),
  "\n"
)


if (nrow(gene_search) != 19214) {
  
  stop(
    "ERROR: Expected 19,214 genes but found ",
    nrow(gene_search),
    "."
  )
  
}


if (n_distinct(gene_search$Gene) != 19214) {
  
  stop(
    "ERROR: Gene column does not contain 19,214 unique genes."
  )
  
}


# ------------------------------------------------------------
# 6. Clean Search_Symbols
# ------------------------------------------------------------

gene_search <- gene_search %>%
  mutate(
    Search_Symbols = str_trim(Search_Symbols)
  )


# ------------------------------------------------------------
# 7. Function:
#    Convert Search_Symbols into PubMed OR query
# ------------------------------------------------------------

make_symbol_query <- function(
    search_symbols
) {
  
  if (is.na(search_symbols) ||
      search_symbols == "") {
    
    return(NA_character_)
    
  }
  
  symbols <- unlist(
    str_split(
      search_symbols,
      "\\|"
    )
  )
  
  symbols <- str_trim(symbols)
  
  symbols <- symbols[
    !is.na(symbols) &
      symbols != ""
  ]
  
  symbols <- unique(symbols)
  
  if (length(symbols) == 0) {
    return(NA_character_)
  }
  
  # Escape quotation marks
  symbols <- str_replace_all(
    symbols,
    '"',
    '\\"'
  )
  
  terms <- paste0(
    '"',
    symbols,
    '"[Title/Abstract]'
  )
  
  if (length(terms) == 1) {
    
    return(terms)
    
  }
  
  paste0(
    "(",
    paste(
      terms,
      collapse = " OR "
    ),
    ")"
  )
}


# ------------------------------------------------------------
# 8. Mining 1 terms
# ------------------------------------------------------------

mining1_terms <- c(
  "cilia",
  "cilium",
  "transition zone",
  "basal body",
  "ciliogenesis",
  "flagella"
)


# ------------------------------------------------------------
# 9. Function:
#    Build Mining 1 query
# ------------------------------------------------------------

make_mining1_query <- function(
    search_symbols
) {
  
  symbol_query <- make_symbol_query(
    search_symbols
  )
  
  evidence_terms <- paste0(
    '"',
    mining1_terms,
    '"[Title/Abstract]'
  )
  
  evidence_query <- paste(
    evidence_terms,
    collapse = " OR "
  )
  
  paste0(
    symbol_query,
    " AND (",
    evidence_query,
    ")"
  )
}


# ------------------------------------------------------------
# 10. Mining 2 - Tier 1
# ------------------------------------------------------------

tier1_terms <- c(
  "cilia",
  "cilium",
  "ciliary",
  "ciliogenesis",
  "primary cilium",
  "primary cilia",
  "motile cilium",
  "motile cilia",
  "ciliary axoneme",
  "axoneme",
  "ciliary membrane",
  "ciliary compartment",
  "flagellum",
  "flagella",
  "flagellar",
  "flagellar assembly",
  "flagellar axoneme",
  "flagellar basal body",
  "flagellar transport"
)


# ------------------------------------------------------------
# 11. Mining 2 - Tier 2
# ------------------------------------------------------------

tier2_terms <- c(
  "basal body",
  "basal bodies",
  "transition zone",
  "transition fibers",
  "distal appendage",
  "distal appendages",
  "proximal appendage",
  "ciliary trafficking",
  "ciliary transport",
  "ciliary localization",
  "cilium localization",
  "ciliary targeting",
  "intraflagellar transport",
  "IFT",
  "ciliary assembly",
  "cilium assembly",
  "ciliary disassembly",
  "cilium disassembly",
  "ciliary gate",
  "ciliary barrier",
  "ciliary diffusion barrier",
  "flagellar localization",
  "flagellar membrane",
  "flagellar motility",
  "flagellar biogenesis",
  "flagellar microtubule",
  "flagellar structure",
  "flagellar trafficking",
  "flagellar function"
)


# ------------------------------------------------------------
# 12. Mining 2 - Tier 3
# ------------------------------------------------------------

tier3_terms <- c(
  "ciliopathy",
  "ciliopathies",
  "ciliary disease",
  "ciliary disorder",
  "Joubert syndrome",
  "Bardet-Biedl syndrome",
  "Meckel syndrome",
  "Senior-Loken syndrome",
  "Alstrom syndrome",
  "nephronophthisis",
  "primary ciliary dyskinesia"
)


# ------------------------------------------------------------
# 13. Function:
#    Build tier query
# ------------------------------------------------------------

make_tier_query <- function(
    search_symbols,
    tier_terms
) {
  
  symbol_query <- make_symbol_query(
    search_symbols
  )
  
  evidence_terms <- paste0(
    '"',
    tier_terms,
    '"[Title/Abstract]'
  )
  
  evidence_query <- paste(
    evidence_terms,
    collapse = " OR "
  )
  
  paste0(
    symbol_query,
    " AND (",
    evidence_query,
    ")"
  )
}


# ------------------------------------------------------------
# 14. XML parser
# ------------------------------------------------------------

parse_pubmed_xml <- function(
    xml_text,
    gene,
    tier = NA_character_
) {
  
  if (is.null(xml_text) ||
      length(xml_text) == 0 ||
      is.na(xml_text)) {
    
    return(
      tibble(
        Gene = character(),
        Tier = character(),
        PMID = character(),
        Title = character()
      )
    )
    
  }
  
  
  # Try parsing XML
  doc <- tryCatch(
    read_xml(xml_text),
    error = function(e) NULL
  )
  
  
  if (is.null(doc)) {
    
    return(
      tibble(
        Gene = character(),
        Tier = character(),
        PMID = character(),
        Title = character()
      )
    )
    
  }
  
  
  articles <- xml_find_all(
    doc,
    ".//PubmedArticle"
  )
  
  
  if (length(articles) == 0) {
    
    return(
      tibble(
        Gene = character(),
        Tier = character(),
        PMID = character(),
        Title = character()
      )
    )
    
  }
  
  
  results <- map_dfr(
    articles,
    function(article) {
      
      # PMID
      pmid_node <- xml_find_first(
        article,
        ".//PubmedData/ArticleIdList/ArticleId[@IdType='pubmed']"
      )
      
      
      if (inherits(pmid_node, "xml_missing")) {
        
        pmid_node <- xml_find_first(
          article,
          ".//PMID"
        )
        
      }
      
      
      pmid <- if (
        !inherits(
          pmid_node,
          "xml_missing"
        )
      ) {
        
        xml_text(
          pmid_node
        )
        
      } else {
        
        NA_character_
        
      }
      
      
      # Title
      title_node <- xml_find_first(
        article,
        ".//ArticleTitle"
      )
      
      
      title <- if (
        !inherits(
          title_node,
          "xml_missing"
        )
      ) {
        
        xml_text(
          title_node,
          trim = TRUE
        )
        
      } else {
        
        NA_character_
        
      }
      
      
      tibble(
        Gene = gene,
        Tier = tier,
        PMID = pmid,
        Title = title
      )
      
    }
  )
  
  
  results %>%
    filter(
      !is.na(PMID),
      PMID != "",
      !is.na(Title),
      Title != ""
    ) %>%
    distinct(
      Gene,
      Tier,
      PMID,
      .keep_all = TRUE
    )
  
}


# ------------------------------------------------------------
# 15. PubMed search function
# ------------------------------------------------------------

search_pubmed <- function(
    gene,
    query,
    tier,
    retmax = 200,
    retries = 3,
    delay = 0.5
) {
  
  
  if (
    is.na(query) ||
    query == ""
  ) {
    
    return(
      tibble(
        Gene = character(),
        Tier = character(),
        PMID = character(),
        Title = character()
      )
    )
    
  }
  
  
  for (
    attempt in seq_len(retries)
  ) {
    
    
    cat(
      "  Attempt",
      attempt,
      "/",
      retries,
      "\n"
    )
    
    
    result <- tryCatch({
      
      # ------------------------------------------
      # PubMed search
      # ------------------------------------------
      
      search_result <- entrez_search(
        db = "pubmed",
        term = query,
        retmax = retmax,
        sort = "pub date"
      )
      
      
      pmids <- search_result$ids
      
      
      if (
        length(pmids) == 0
      ) {
        
        return(
          tibble(
            Gene = character(),
            Tier = character(),
            PMID = character(),
            Title = character()
          )
        )
        
      }
      
      
      # ------------------------------------------
      # Fetch XML
      # ------------------------------------------
      
      Sys.sleep(delay)
      
      
      xml_data <- entrez_fetch(
        db = "pubmed",
        id = pmids,
        rettype = "xml",
        retmode = "xml"
      )
      
      
      # ------------------------------------------
      # Parse XML
      # ------------------------------------------
      
      parse_pubmed_xml(
        xml_data,
        gene = gene,
        tier = tier
      )
      
    },
    
    error = function(e) {
      
      cat(
        "  ERROR:",
        conditionMessage(e),
        "\n"
      )
      
      NULL
      
    })
    
    
    if (!is.null(result)) {
      
      return(result)
      
    }
    
    
    # ------------------------------------------
    # Retry delay
    # ------------------------------------------
    
    if (
      attempt < retries
    ) {
      
      wait_time <- 2 ^ attempt
      
      cat(
        "  Waiting",
        wait_time,
        "seconds before retry...\n"
      )
      
      Sys.sleep(
        wait_time
      )
      
    }
    
  }
  
  
  cat(
    "  FAILED after",
    retries,
    "attempts\n"
  )
  
  
  tibble(
    Gene = character(),
    Tier = character(),
    PMID = character(),
    Title = character()
  )
  
}


# ============================================================
# 16. CHECKPOINT SYSTEM
# ============================================================

if (
  file.exists(checkpoint_file)
) {
  
  cat("\n")
  cat("================================================\n")
  cat("CHECKPOINT FOUND\n")
  cat("================================================\n")
  
  checkpoint <- readRDS(
    checkpoint_file
  )
  
  processed_genes <- checkpoint$processed_genes
  
  mining1_results <- checkpoint$mining1_results
  
  mining2_results <- checkpoint$mining2_results
  
  cat(
    "Processed genes:",
    length(processed_genes),
    "\n"
  )
  
} else {
  
  processed_genes <- character()
  
  mining1_results <- tibble(
    Gene = character(),
    Tier = character(),
    PMID = character(),
    Title = character()
  )
  
  mining2_results <- tibble(
    Gene = character(),
    Tier = character(),
    PMID = character(),
    Title = character()
  )
  
}


# ------------------------------------------------------------
# 17. Main mining loop
# ------------------------------------------------------------

test_gene <- gene_search %>%
  filter(Gene == "A1CF")

test_query <- make_mining1_query(
  test_gene$Search_Symbols
)

cat(test_query)




total_genes <- nrow(
  gene_search
)


for (
  i in seq_len(total_genes)
) {
  
  
  gene <- gene_search$Gene[i]
  
  
  # ------------------------------------------
  # Skip if already processed
  # ------------------------------------------
  
  if (
    gene %in% processed_genes
  ) {
    
    next
    
  }
  
  
  search_symbols <- gene_search$Search_Symbols[i]
  
  
  cat("\n")
  cat("================================================\n")
  cat(
    "Processing:",
    gene,
    "|",
    i,
    "/",
    total_genes,
    "\n"
  )
  cat(
    "Search symbols:",
    search_symbols,
    "\n"
  )
  cat("================================================\n")
  
  
  # ==========================================================
  # MINING 1
  # ==========================================================
  
  mining1_query <- make_mining1_query(
    search_symbols
  )
  
  
  cat(
    "Mining 1 query:\n",
    mining1_query,
    "\n"
  )
  
  
  mining1_gene <- search_pubmed(
    gene = gene,
    query = mining1_query,
    tier = "Mining1_Broad",
    retmax = max_results,
    retries = retries,
    delay = delay_mining1
  )
  
  
  if (
    nrow(mining1_gene) > 0
  ) {
    
    mining1_results <- bind_rows(
      mining1_results,
      mining1_gene
    )
    
  }
  
  
  cat(
    "Mining1 papers:",
    nrow(mining1_gene),
    "\n"
  )
  
  
  # ==========================================================
  # MINING 2 - TIER 1
  # ==========================================================
  
  tier1_query <- make_tier_query(
    search_symbols,
    tier1_terms
  )
  
  
  tier1_gene <- search_pubmed(
    gene = gene,
    query = tier1_query,
    tier = "Tier1_Direct_Ciliary",
    retmax = max_results,
    retries = retries,
    delay = delay_mining2
  )
  
  
  if (
    nrow(tier1_gene) > 0
  ) {
    
    mining2_results <- bind_rows(
      mining2_results,
      tier1_gene
    )
    
  }
  
  
  cat(
    "Tier1 papers:",
    nrow(tier1_gene),
    "\n"
  )
  
  
  # ==========================================================
  # MINING 2 - TIER 2
  # ==========================================================
  
  tier2_query <- make_tier_query(
    search_symbols,
    tier2_terms
  )
  
  
  tier2_gene <- search_pubmed(
    gene = gene,
    query = tier2_query,
    tier = "Tier2_Structure_Trafficking",
    retmax = max_results,
    retries = retries,
    delay = delay_mining2
  )
  
  
  if (
    nrow(tier2_gene) > 0
  ) {
    
    mining2_results <- bind_rows(
      mining2_results,
      tier2_gene
    )
    
  }
  
  
  cat(
    "Tier2 papers:",
    nrow(tier2_gene),
    "\n"
  )
  
  
  # ==========================================================
  # MINING 2 - TIER 3
  # ==========================================================
  
  tier3_query <- make_tier_query(
    search_symbols,
    tier3_terms
  )
  
  
  tier3_gene <- search_pubmed(
    gene = gene,
    query = tier3_query,
    tier = "Tier3_Ciliopathy_Disease",
    retmax = max_results,
    retries = retries,
    delay = delay_mining2
  )
  
  
  if (
    nrow(tier3_gene) > 0
  ) {
    
    mining2_results <- bind_rows(
      mining2_results,
      tier3_gene
    )
    
  }
  
  
  cat(
    "Tier3 papers:",
    nrow(tier3_gene),
    "\n"
  )
  
  
  # ==========================================================
  # Mark gene as processed
  # ==========================================================
  
  processed_genes <- c(
    processed_genes,
    gene
  )
  
  
  # ==========================================================
  # Checkpoint
  # ==========================================================
  
  if (
    i %% checkpoint_every == 0 ||
    i == total_genes
  ) {
    
    
    checkpoint <- list(
      processed_genes = processed_genes,
      mining1_results = mining1_results,
      mining2_results = mining2_results
    )
    
    
    saveRDS(
      checkpoint,
      checkpoint_file
    )
    
    
    cat("\n")
    cat(
      "CHECKPOINT SAVED:",
      length(processed_genes),
      "/",
      total_genes,
      "\n"
    )
    
  }
  
  
  cat(
    "Completed:",
    gene,
    "| Processed:",
    length(processed_genes),
    "/",
    total_genes,
    "\n"
  )
  
}


# ============================================================
# 18. FINAL CLEANUP
# ============================================================

cat("\n")
cat("================================================\n")
cat("MINING COMPLETE\n")
cat("================================================\n")


# ------------------------------------------------------------
# Mining 1 cleanup
# ------------------------------------------------------------

mining1_results <- mining1_results %>%
  distinct(
    Gene,
    PMID,
    .keep_all = TRUE
  )


# ------------------------------------------------------------
# Mining 2 cleanup
# ------------------------------------------------------------

mining2_results <- mining2_results %>%
  distinct(
    Gene,
    Tier,
    PMID,
    .keep_all = TRUE
  )


# ------------------------------------------------------------
# 19. Save raw Mining 1
# ------------------------------------------------------------

write_tsv(
  mining1_results,
  file.path(
    output_dir,
    "Mining1_Broad_Gene_PubMed.tsv"
  )
)


# ------------------------------------------------------------
# 20. Save raw Mining 2
# ------------------------------------------------------------

write_tsv(
  mining2_results,
  file.path(
    output_dir,
    "Mining2_ThreeTier_Gene_PubMed.tsv"
  )
)


# ============================================================
# 21. COMBINED PAPER-LEVEL EVIDENCE
# ============================================================

# Mining 1 is the master paper table.
# Mining 2 adds tier classifications.

mining2_flags <- mining2_results %>%
  distinct(
    Gene,
    PMID,
    Tier
  ) %>%
  mutate(
    Hit = 1
  ) %>%
  tidyr::pivot_wider(
    names_from = Tier,
    values_from = Hit,
    values_fill = 0
  )


combined_paper <- mining1_results %>%
  select(
    Gene,
    PMID,
    Title
  ) %>%
  left_join(
    mining2_flags,
    by = c(
      "Gene",
      "PMID"
    )
  )


# Ensure columns exist
for (
  col in c(
    "Tier1_Direct_Ciliary",
    "Tier2_Structure_Trafficking",
    "Tier3_Ciliopathy_Disease"
  )
) {
  
  if (
    !col %in% colnames(combined_paper)
  ) {
    
    combined_paper[[col]] <- 0
    
  }
  
}


combined_paper <- combined_paper %>%
  mutate(
    Tier1_Flag =
      as.integer(Tier1_Direct_Ciliary > 0),
    
    Tier2_Flag =
      as.integer(Tier2_Structure_Trafficking > 0),
    
    Tier3_Flag =
      as.integer(Tier3_Ciliopathy_Disease > 0)
  ) %>%
  select(
    Gene,
    PMID,
    Title,
    Tier1_Flag,
    Tier2_Flag,
    Tier3_Flag
  )


write_tsv(
  combined_paper,
  file.path(
    output_dir,
    "CiliaHub_Combined_Paper_Evidence.tsv"
  )
)


# ============================================================
# 22. GENE-LEVEL EVIDENCE TABLE
# ============================================================

gene_summary <- gene_search %>%
  select(
    Gene,
    HGNC_ID,
    Ensembl_Gene_ID,
    Search_Symbols,
    Number_of_Search_Symbols
  ) %>%
  left_join(
    
    combined_paper %>%
      
      group_by(Gene) %>%
      
      summarise(
        
        Total_Papers =
          n_distinct(PMID),
        
        Tier1_Papers =
          n_distinct(
            PMID[Tier1_Flag == 1]
          ),
        
        Tier2_Papers =
          n_distinct(
            PMID[Tier2_Flag == 1]
          ),
        
        Tier3_Papers =
          n_distinct(
            PMID[Tier3_Flag == 1]
          ),
        
        .groups = "drop"
      ),
    
    by = "Gene"
  ) %>%
  
  mutate(
    
    Total_Papers =
      coalesce(
        Total_Papers,
        0L
      ),
    
    Tier1_Papers =
      coalesce(
        Tier1_Papers,
        0L
      ),
    
    Tier2_Papers =
      coalesce(
        Tier2_Papers,
        0L
      ),
    
    Tier3_Papers =
      coalesce(
        Tier3_Papers,
        0L
      )
  ) %>%
  
  mutate(
    
    Tier1_Flag =
      as.integer(Tier1_Papers > 0),
    
    Tier2_Flag =
      as.integer(Tier2_Papers > 0),
    
    Tier3_Flag =
      as.integer(Tier3_Papers > 0),
    
    Evidence_Score =
      3 * Tier1_Papers +
      2 * Tier2_Papers +
      1 * Tier3_Papers
  ) %>%
  
  arrange(
    desc(Evidence_Score),
    desc(Tier1_Papers),
    desc(Tier2_Papers),
    Gene
  )


# ------------------------------------------------------------
# Save gene-level table
# ------------------------------------------------------------

write_tsv(
  gene_summary,
  file.path(
    output_dir,
    "CiliaHub_Combined_Gene_Evidence.tsv"
  )
)


# ============================================================
# 23. TIER SUMMARY
# ============================================================

tier_summary <- tibble(
  Tier = c(
    "Mining1_Broad",
    "Tier1_Direct_Ciliary",
    "Tier2_Structure_Trafficking",
    "Tier3_Ciliopathy_Disease"
  ),
  
  Unique_Genes = c(
    
    n_distinct(
      mining1_results$Gene
    ),
    
    n_distinct(
      mining2_results$Gene[
        mining2_results$Tier ==
          "Tier1_Direct_Ciliary"
      ]
    ),
    
    n_distinct(
      mining2_results$Gene[
        mining2_results$Tier ==
          "Tier2_Structure_Trafficking"
      ]
    ),
    
    n_distinct(
      mining2_results$Gene[
        mining2_results$Tier ==
          "Tier3_Ciliopathy_Disease"
      ]
    )
  ),
  
  Unique_PMIDs = c(
    
    n_distinct(
      mining1_results$PMID
    ),
    
    n_distinct(
      mining2_results$PMID[
        mining2_results$Tier ==
          "Tier1_Direct_Ciliary"
      ]
    ),
    
    n_distinct(
      mining2_results$PMID[
        mining2_results$Tier ==
          "Tier2_Structure_Trafficking"
      ]
    ),
    
    n_distinct(
      mining2_results$PMID[
        mining2_results$Tier ==
          "Tier3_Ciliopathy_Disease"
      ]
    )
  ),
  
  Gene_Publication_Records = c(
    
    nrow(
      mining1_results
    ),
    
    nrow(
      mining2_results[
        mining2_results$Tier ==
          "Tier1_Direct_Ciliary",
      ]
    ),
    
    nrow(
      mining2_results[
        mining2_results$Tier ==
          "Tier2_Structure_Trafficking",
      ]
    ),
    
    nrow(
      mining2_results[
        mining2_results$Tier ==
          "Tier3_Ciliopathy_Disease",
      ]
    )
  )
)


write_tsv(
  tier_summary,
  file.path(
    output_dir,
    "CiliaHub_Tier_Summary.tsv"
  )
)


# ============================================================
# 24. METADATA
# ============================================================

metadata_file <- file.path(
  output_dir,
  "CiliaHub_PubMed_Mining_Metadata.txt"
)


metadata_text <- paste0(
  
  "CiliaHub PubMed Mining Metadata\n",
  "========================================\n\n",
  
  "Gene universe: 19,214\n",
  "Reference: Ensembl release 116 + HGNC approved protein-coding genes\n",
  "Search symbol strategy: Current + HGNC alias_symbol + HGNC prev_symbol\n\n",
  
  "Mining 1:\n",
  "Broad cilia-related PubMed retrieval\n",
  "Maximum records per gene: 200\n",
  "Field: Title/Abstract\n",
  "Terms: cilia, cilium, transition zone, basal body, ciliogenesis, flagella\n\n",
  
  "Mining 2:\n",
  "Three independent evidence tiers\n",
  "Maximum records per gene per tier: 200\n",
  "Field: Title/Abstract\n",
  "Tier 1: Direct ciliary evidence\n",
  "Tier 2: Structural/trafficking evidence\n",
  "Tier 3: Ciliopathy/disease evidence\n\n",
  
  "Retry attempts: ",
  retries,
  "\n",
  
  "Mining 1 request spacing: ",
  delay_mining1,
  " seconds\n",
  
  "Mining 2 request spacing: ",
  delay_mining2,
  " seconds\n",
  
  "Checkpoint interval: ",
  checkpoint_every,
  " genes\n",
  
  "Generated: ",
  format(
    Sys.time(),
    "%Y-%m-%d %H:%M:%S"
  ),
  "\n"
  
)


writeLines(
  metadata_text,
  metadata_file
)


# ============================================================
# 25. FINAL QC
# ============================================================

cat("\n")
cat("================================================\n")
cat("FINAL QC\n")
cat("================================================\n")

cat(
  "Input genes:",
  nrow(gene_search),
  "\n"
)

cat(
  "Processed genes:",
  length(processed_genes),
  "\n"
)

cat(
  "Mining1 records:",
  nrow(mining1_results),
  "\n"
)

cat(
  "Mining1 genes:",
  n_distinct(mining1_results$Gene),
  "\n"
)

cat(
  "Mining2 records:",
  nrow(mining2_results),
  "\n"
)

cat(
  "Mining2 genes:",
  n_distinct(mining2_results$Gene),
  "\n"
)

cat(
  "Combined papers:",
  nrow(combined_paper),
  "\n"
)

cat(
  "Combined genes:",
  nrow(gene_summary),
  "\n"
)

cat(
  "Genes with Tier1:",
  sum(gene_summary$Tier1_Flag),
  "\n"
)

cat(
  "Genes with Tier2:",
  sum(gene_summary$Tier2_Flag),
  "\n"
)

cat(
  "Genes with Tier3:",
  sum(gene_summary$Tier3_Flag),
  "\n"
)

cat("\n")
cat("================================================\n")
cat("DONE\n")
cat("================================================\n")