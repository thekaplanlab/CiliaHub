# ==============================================================================
# CiliaHub Benchmark: Resource Overlap and Gap Analysis
# Description: Evaluates CiliaHub against CiliaCarta (n=956), SCGSv1/v2, 
#              and CilioGenics using a dual-layer resolution strategy 
#              (Ensembl ID flattening + case-insensitive gene symbol matching).
# ==============================================================================

library(dplyr)
library(readr)
library(readxl)
library(tidyr)
library(stringr)

# ------------------------------------------------------------------------------
# 1. DIRECTORY CONFIGURATION & DATA LOADING
# ------------------------------------------------------------------------------
base_dir <- "C:/Users/lenovo/Desktop/revision/Response_to_Reviewers/method 3s"

cat("Loading input benchmark datasets...\n")
ciliahub_master <- read_excel(file.path(base_dir, "ciliahub_master_genes.xlsx"))
ciliacarta     <- read_csv(file.path(base_dir, "CiliaCarta.csv"), show_col_types = FALSE)
scgsv1         <- read_excel(file.path(base_dir, "SCGSv1_list.xlsx"))
scgsv2         <- read_excel(file.path(base_dir, "SCGSv2_list.xlsx"))
ciliogenics    <- read_csv(file.path(base_dir, "ciliogenics.csv"), show_col_types = FALSE)

# ------------------------------------------------------------------------------
# 2. CILIAHUB MASTER ENSEMBL & SYMBOL POOL EXTRACTION
# ------------------------------------------------------------------------------
# Flatten multi-Ensembl ID entries per cell (delimited by comma/semicolon/space)
ciliahub_ensembl_gs <- ciliahub_master %>%
  filter(evidence_tier == "Gold Standard Ciliary Genes") %>%
  separate_rows(ensembl_id, sep = "[,;\\s]+") %>%
  filter(!is.na(ensembl_id) & ensembl_id != "NA" & nchar(ensembl_id) > 0) %>%
  pull(ensembl_id) %>%
  toupper() %>%
  trimws() %>%
  unique()

ciliahub_ensembl_ca <- ciliahub_master %>%
  filter(evidence_tier != "Gold Standard Ciliary Genes" | is.na(evidence_tier)) %>%
  separate_rows(ensembl_id, sep = "[,;\\s]+") %>%
  filter(!is.na(ensembl_id) & ensembl_id != "NA" & nchar(ensembl_id) > 0) %>%
  pull(ensembl_id) %>%
  toupper() %>%
  trimws() %>%
  unique()

# Case-insensitive symbol pools as secondary fallback layer
ciliahub_symbol_gs <- ciliahub_master %>%
  filter(evidence_tier == "Gold Standard Ciliary Genes") %>%
  pull(gene_symbol) %>%
  toupper() %>%
  trimws() %>%
  unique()

ciliahub_symbol_ca <- ciliahub_master %>%
  filter(evidence_tier != "Gold Standard Ciliary Genes" | is.na(evidence_tier)) %>%
  pull(gene_symbol) %>%
  toupper() %>%
  trimws() %>%
  unique()

# ------------------------------------------------------------------------------
# 3. CILIACARTA DATA CLEANING & EXCEL CORRUPTION RESOLUTION
# ------------------------------------------------------------------------------
ciliacarta_cleaned <- ciliacarta %>%
  rename(
    ensembl_id_carta = `Ensembl Gene ID`,
    symbol_carta     = `Associated Gene Name`
  ) %>%
  mutate(
    ensembl_clean = toupper(trimws(as.character(ensembl_id_carta))),
    symbol_clean  = toupper(trimws(as.character(symbol_carta))),
    # Resolve classic spreadsheet text-to-date auto-formatting mangling
    symbol_clean  = case_when(
      symbol_clean %in% c("SEP-02", "SEP-2", "SEPT2", "SEP2") ~ "SEPTIN2",
      symbol_clean %in% c("SEP-07", "SEP-7", "SEPT7", "SEP7") ~ "SEPTIN7",
      TRUE ~ symbol_clean
    )
  )

# ------------------------------------------------------------------------------
# 4. DUAL-LAYER OVERLAP COMPUTATION (ENSEMBL OR SYMBOL)
# ------------------------------------------------------------------------------
overlap_summary <- ciliacarta_cleaned %>%
  mutate(
    in_gs = (ensembl_clean %in% ciliahub_ensembl_gs) | (symbol_clean %in% ciliahub_symbol_gs),
    in_ca = ((ensembl_clean %in% ciliahub_ensembl_ca) | (symbol_clean %in% ciliahub_symbol_ca)) & !in_gs,
    cilia_status = case_when(
      in_gs ~ "Gold-Standard Tier",
      in_ca ~ "Cilia-Associated Tier",
      TRUE  ~ "Excluded (No Experimental Evidence)"
    )
  )

n_total    <- nrow(ciliacarta_cleaned)
n_gs       <- sum(overlap_summary$in_gs, na.rm = TRUE)
n_ca       <- sum(overlap_summary$in_ca, na.rm = TRUE)
n_overlap  <- n_gs + n_ca
n_excluded <- n_total - n_overlap

# Print Dynamic Summary Statistics to Console
cat("========================================================\n")
cat("   CILIACARTA BENCHMARK OVERLAP (ENSEMBL + SYMBOL)     \n")
cat("========================================================\n")
cat(sprintf("Total CiliaCarta Input Genes : %d\n", n_total))
cat(sprintf("Total Overlap in CiliaHub   : %d (%.1f%%)\n", n_overlap, (n_overlap/n_total)*100))
cat(sprintf("  - Gold-Standard Tier      : %d\n", n_gs))
cat(sprintf("  - Cilia-Associated Tier   : %d\n", n_ca))
cat(sprintf("Excluded (No Exp Evidence)  : %d (%.1f%%)\n", n_excluded, (n_excluded/n_total)*100))
cat("========================================================\n\n")

# ------------------------------------------------------------------------------
# 5. EXPORT PROCESSED OVERLAP MATRIX TO CSV (SUPPLEMENTARY ARTIFACT)
# ------------------------------------------------------------------------------
output_csv_path <- file.path(base_dir, "Supplementary_Table_S3_1_CiliaCarta_Overlap_Results.csv")
write_csv(overlap_summary, output_csv_path)

cat(sprintf("SUCCESS: Processed benchmark file saved to:\n%s\n", output_csv_path))
