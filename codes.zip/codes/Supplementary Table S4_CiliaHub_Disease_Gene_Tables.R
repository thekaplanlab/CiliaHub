# ==============================================================================
# Script Name : generate_CiliaHub_Disease_Gene_Tables.R
# Description : Validates CiliaHub Release v9.1 metrics from master JSON and 
#               generates disease gene tables (Master, By Class, and By Disease)
# Author      : CiliaHub Pipeline Team
# Date        : 2026-09-22
# ==============================================================================

library(jsonlite)
library(dplyr)
library(readxl)
library(stringr)
library(purrr)
library(writexl)
library(readr)

# ------------------------------------------------------------------------------
# 1. Verification of Release v9.1 Metrics from Master JSON
# ------------------------------------------------------------------------------
json_path <- "C:/Users/lenovo/Desktop/ciliahub tables/ciliahub_master_merged_v9_1_2026-09-21.json"

if (file.exists(json_path)) {
  ciliome_data <- fromJSON(json_path, simplifyVector = FALSE)
  genes_list <- ciliome_data$genes
  meta_counts <- ciliome_data$meta$counts
  
  cat("\n=======================================================\n")
  cat("      CILIAHUB RELEASE v9.1 METRICS VERIFICATION       \n")
  cat("=======================================================\n")
  cat("Catalogue Version             : ", ciliome_data$meta$version, "\n")
  cat("Freeze Timestamp              : ", ciliome_data$meta$frozen_at, "\n")
  cat("Total Catalogue Genes (N)     : ", length(genes_list), "\n")
  cat("Confirmed Ciliopathy Genes    : ", meta_counts$confirmed_ciliopathy_genes, "\n")
  cat("Total Disease Entities        : ", meta_counts$diseases, "\n")
  cat("=======================================================\n\n")
} else {
  cat("\n[WARNING] JSON file not found at specified path. Skipping JSON verification step.\n\n")
}

# ------------------------------------------------------------------------------
# 2. Load and Clean Master Excel Data
# ------------------------------------------------------------------------------
input_path <- "C:/Users/lenovo/Desktop/table3_1.xlsx"
df <- read_excel(input_path, col_types = "text")

# String cleaning utility function
clean_str <- function(x) {
  x <- ifelse(is.na(x) | x == "NA" | x == "N/A", "", trimws(as.character(x)))
  return(x)
}

# Clean all text fields across the dataframe
df_clean <- df %>% mutate(across(everything(), clean_str))

# ------------------------------------------------------------------------------
# 3. TABLE 1: ALL DISEASE GENES (Master Table)
# Columns: Gene, Ensembl ID, OMIM ID, UniProt ID, Synonyms, Description, 
#          Ciliopathies, Disease classifications, Ciliopathy classes, 
#          Pan/idio classification, Pan/idio tissue count, Localisation, 
#          Functional category, Functional summary, Protein complex, 
#          Ciliopathy refs (PMIDs), Localisation refs (PMIDs), 
#          Human ciliopathy phenotype, Mouse ciliopathy phenotype, 
#          Evidence type, Curation notes
# ------------------------------------------------------------------------------
all_disease_genes <- df_clean %>%
  filter(ciliopathies != "" | disease_classifications != "" | omim_disease_ids != "") %>%
  dplyr::select(
    Gene = gene_symbol,
    `Ensembl ID` = ensembl_id,
    `OMIM ID` = omim_id,
    `UniProt ID` = uniprot_id,
    Synonyms = synonyms,
    Description = description,
    Ciliopathies = ciliopathies,
    `Disease classifications` = disease_classifications,
    `Ciliopathy classes` = ciliopathy_classification,
    `Pan/idio classification` = pan_idio_class,
    `Pan/idio tissue count` = pan_idio_tissues,
    Localisation = localization,
    `Functional category` = functional_category,
    `Functional summary` = functional_summary,
    `Protein complex` = protein_complex,
    `Ciliopathy refs (PMIDs)` = ciliopathy_refs,
    `Localisation refs (PMIDs)` = localization_refs,
    `Human ciliopathy phenotype` = human_ciliopathy_phenotype,
    `Mouse ciliopathy phenotype` = mouse_ciliopathy_phenotype,
    `Evidence type` = evidence_type,
    `Curation notes` = curation_notes
  )

# ------------------------------------------------------------------------------
# 4. TABLE 2: BY_CLASS TABLES (Primary, Motile, Tissue-restricted, Secondary)
# Columns: Gene, OMIM ID, Disease classifications, Ciliopathy classes, 
#          Pan/idio classification, Localisation, Functional category, 
#          Ciliopathy refs (PMIDs)
# ------------------------------------------------------------------------------
filter_by_class <- function(data, class_pattern) {
  data %>%
    filter(grepl(class_pattern, `Disease classifications`, ignore.case = TRUE) | 
             grepl(class_pattern, `Ciliopathy classes`, ignore.case = TRUE)) %>%
    dplyr::select(
      Gene,
      `OMIM ID`,
      `Disease classifications`,
      `Ciliopathy classes`,
      `Pan/idio classification`,
      Localisation,
      `Functional category`,
      `Ciliopathy refs (PMIDs)`
    )
}

by_class_primary           <- filter_by_class(all_disease_genes, "Primary Ciliopathies")
by_class_motile            <- filter_by_class(all_disease_genes, "Motile Ciliopathies")
by_class_tissue_restricted <- filter_by_class(all_disease_genes, "Tissue-restricted Ciliopathies")
by_class_secondary         <- filter_by_class(all_disease_genes, "Secondary")

# ------------------------------------------------------------------------------
# 5. TABLE 3: BY_DISEASE (Disaggregated Per-Disease Mapping)
# Columns: Disease, Disease class, Gene Symbol, Alias / BBS#, Role, OMIM ID, 
#          Pan/idio, Other diseases for this gene, Localisation, Refs (PMIDs)
# ------------------------------------------------------------------------------
by_disease_list <- list()

# Unpack multiple disease entries per row into discrete rows
for (i in seq_len(nrow(all_disease_genes))) {
  row <- all_disease_genes[i, ]
  
  dis_class_str <- row$`Disease classifications`
  if (dis_class_str == "") next
  
  # Split "Disease1:Class1, Disease2:Class2" pairs
  pairs <- unlist(strsplit(dis_class_str, ","))
  
  for (p in pairs) {
    p <- trimws(p)
    if (p == "") next
    
    parts <- unlist(strsplit(p, ":"))
    dis_name  <- trimws(parts[1])
    dis_class <- ifelse(length(parts) > 1, trimws(parts[2]), "Unclassified")
    
    # Compute other associated diseases for the current gene
    all_dis_array <- unlist(lapply(strsplit(dis_class_str, ",")[[1]], function(x) trimws(unlist(strsplit(x, ":"))[1])))
    other_dis <- paste(setdiff(all_dis_array, dis_name), collapse = "; ")
    
    by_disease_list[[length(by_disease_list) + 1]] <- data.frame(
      Disease = dis_name,
      `Disease class` = dis_class,
      `Gene Symbol` = row$Gene,
      `Alias / BBS#` = row$Synonyms,
      Role = "Causing",
      `OMIM ID` = row$`OMIM ID`,
      `Pan/idio` = row$`Pan/idio classification`,
      `Other diseases for this gene` = other_dis,
      Localisation = row$Localisation,
      `Refs (PMIDs)` = row$`Ciliopathy refs (PMIDs)`,
      stringsAsFactors = FALSE,
      check.names = FALSE
    )
  }
}

by_disease_df <- bind_rows(by_disease_list) %>%
  arrange(Disease, `Gene Symbol`)

# ------------------------------------------------------------------------------
# 6. Export Outputs (Multi-Sheet Excel and Individual TSV Files)
# ------------------------------------------------------------------------------
output_dir <- "C:/Users/lenovo/Desktop/ciliahub tables/"

# Ensure output directory exists
if (!dir.exists(output_dir)) {
  dir.create(output_dir, recursive = TRUE)
}

# Save multi-sheet Excel file
sheets <- list(
  "All_Disease_Genes"   = all_disease_genes,
  "By_Class_Primary"    = by_class_primary,
  "By_Class_Motile"     = by_class_motile,
  "By_Class_Tissue"     = by_class_tissue_restricted,
  "By_Class_Secondary"  = by_class_secondary,
  "By_Disease"          = by_disease_df
)

excel_output_path <- file.path(output_dir, "CiliaHub_v9_1_Disease_Gene_Tables.xlsx")
write_xlsx(sheets, path = excel_output_path)

# Save individual TSV files
write_tsv(all_disease_genes, file.path(output_dir, "Table_All_Disease_Genes.tsv"))
write_tsv(by_class_primary, file.path(output_dir, "Table_By_Class_Primary.tsv"))
write_tsv(by_class_motile, file.path(output_dir, "Table_By_Class_Motile.tsv"))
write_tsv(by_class_tissue_restricted, file.path(output_dir, "Table_By_Class_Tissue.tsv"))
write_tsv(by_class_secondary, file.path(output_dir, "Table_By_Class_Secondary.tsv"))
write_tsv(by_disease_df, file.path(output_dir, "Table_By_Disease.tsv"))

cat("\n=========================================================\n")
cat("[SUCCESS] All disease gene tables successfully generated!\n")
cat("Excel Output Path           : ", excel_output_path, "\n")
cat("Total Disease-Gene Pairs    : ", nrow(by_disease_df), "\n")
cat("=========================================================\n\n")