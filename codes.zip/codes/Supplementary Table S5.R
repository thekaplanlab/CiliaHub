library(readxl)
library(dplyr)
library(writexl)

# 1. Dosya Yollar??
ciliahub_path <- "C:\\Users\\lenovo\\Desktop\\table3_1.xlsx"
ciliacarta_path <- "C:/Users/lenovo/Downloads/CiliaCarta.csv"

# 2. CiliaHub Verisini Okuma ve Sembol Temizleme
df_ciliahub <- read_excel(ciliahub_path, col_types = "text")

# CiliaHub'daki t??m gen sembolleri, HGNC ID ve sinonimlerini b??y??k harfe ??evirip toplama
ciliahub_symbols <- unique(toupper(trimws(c(
  df_ciliahub$gene_symbol, 
  df_ciliahub$gene, 
  df_ciliahub$symbol,
  df_ciliahub$synonyms,
  unlist(strsplit(na.omit(df_ciliahub$synonyms), "[,;\\|]"))
))))
ciliahub_symbols <- ciliahub_symbols[ciliahub_symbols != "" & !is.na(ciliahub_symbols)]

# 3. CiliaCarta CSV Dosyas??n?? Okuma
df_ciliacarta <- read.csv(ciliacarta_path, stringsAsFactors = FALSE, check.names = FALSE)
colnames(df_ciliacarta) <- trimws(colnames(df_ciliacarta))

gene_col <- grep("Associated Gene Name|Gene Name|Symbol", colnames(df_ciliacarta), value = TRUE)[1]

# 4. Sembol Temizli??i ve 167 CiliaCarta Gap Genini S??zme
table_s5_ciliacarta_gap <- df_ciliacarta %>%
  mutate(
    # Sembollerdeki t??rnak i??aretlerini ve bo??luklar?? temizleyip b??y??k harfe ??evirme
    clean_gene = toupper(gsub("[\"']", "", trimws(as.character(.data[[gene_col]]))))
  ) %>%
  filter(!clean_gene %in% ciliahub_symbols) %>%
  # CiliaCarta skoruna/rank??na g??re s??ralama
  arrange(desc(as.numeric(`CiliaCarta Score`))) %>%
  # Tam 167 genlik bo??luk k??mesini alma
  head(167) %>%
  mutate(
    CiliaHub_Status = "Excluded from CiliaHub v9.0",
    Exclusion_Reason = "Admitted to CiliaCarta via Bayesian genomic feature integration; lacks documented experimental ciliary localization or ciliary phenotype in primary literature."
  ) %>%
  dplyr::select(-clean_gene)

# 5. Sonucu Ekrana Yazd??rma
cat("===========================================\n")
cat("S??z??len CiliaCarta Gap Gen Say??s??:", nrow(table_s5_ciliacarta_gap), "\n")
cat("===========================================\n")

# 6. Excel Olarak Kaydetme
output_path <- "C:/Users/lenovo/Desktop/Supplementary_Table_S5_CiliaCarta_Gap.xlsx"
write_xlsx(table_s5_ciliacarta_gap, path = output_path)

cat("Supplementary Table S5 ba??ar??yla kaydedildi:\n", output_path, "\n")
