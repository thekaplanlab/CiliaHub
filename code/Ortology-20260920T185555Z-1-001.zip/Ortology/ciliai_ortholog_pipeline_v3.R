#!/usr/bin/env Rscript

# ==============================================================================
# CiliAI ORTHOLOG PUBMED PIPELINE  (v2 - 2026-05-22)
# Searches PubMed for ciliary phenotype papers using model organism orthologs
# Run for: (1) Full ciliary gene list  (2) Ciliopathy genes subset
#
# CHANGES vs original:
#   - get_orthologs() now splits on BOTH "," and ";" (was comma-only).
#     Roughly 21% of multi-ortholog cells in the v5_4 master JSON use
#     semicolons (e.g. "Abcb11; Abcb5; Abcb1b" for ABCB11). The original
#     comma-only split treated each such string as a single PubMed search
#     term and silently returned no hits. Splitting on /[,;]/ fixes this.
#   - Term cleaner now also drops parenthetical qualifiers like
#     "abcb1 (provisional)" → "abcb1", which is what PubMed indexes.
#   - Trailing-whitespace and empty-token guards tightened.
#   - No other logic changes; checkpointing, PubMed query, and outputs
#     are identical to the original script.
# ==============================================================================

library(rentrez)
library(stringr)
library(jsonlite)
library(dplyr)

# ============================================================
# SETTINGS — change MODE to switch between datasets
# ============================================================
MODE <- "ciliary"   # "ciliary" = full list | "ciliopathy" = disease genes only

# Use the current working directory. Run this script from the folder that
# contains the input CSVs:
#   cd /path/to/csv/folder
#   Rscript ciliai_ortholog_pipeline_v2.R
# (No setwd() — keeps the script portable across machines.)
cat(sprintf("Working directory: %s\n", getwd()))

if (MODE == "ciliary") {
  input_file       <- "ciliary_gene_orthologs.csv"
  csv_output       <- "ciliary_ortholog_pubmed_output.csv"
  checkpoint_file  <- "ciliary_checkpoint.rds"
  summary_output   <- "ciliary_gene_summary.csv"
} else {
  input_file       <- "ciliopathy_gene_orthologs.csv"
  csv_output       <- "ciliopathy_ortholog_pubmed_output.csv"
  checkpoint_file  <- "ciliopathy_checkpoint.rds"
  summary_output   <- "ciliopathy_gene_summary.csv"
}

# ============================================================
# LOAD DATA
# ============================================================
if (!file.exists(input_file)) {
  stop(sprintf(
    "Input file not found in current directory: %s\n\n  Working dir: %s\n\n  Run this script from the folder that contains %s, or copy the CSV there.\n",
    input_file, getwd(), input_file
  ), call. = FALSE)
}
master_data <- read.csv(input_file, stringsAsFactors = FALSE)
cat(sprintf("Loaded %d genes from %s\n", nrow(master_data), input_file))

# ============================================================
# ORTHOLOG EXTRACTION
# ============================================================
# Splits each ortholog cell on commas OR semicolons, trims whitespace,
# drops parenthetical qualifiers, and returns a unique vector of terms.
get_orthologs <- function(row) {
  fields <- c("Ortholog_Mouse", "Ortholog_C_elegans", "Ortholog_Xenopus",
              "Ortholog_Zebrafish", "Ortholog_Drosophila")
  terms <- c()
  for (f in fields) {
    val <- row[[f]]
    if (!is.null(val) && !is.na(val) && nchar(trimws(as.character(val))) > 0) {
      # Split on EITHER comma OR semicolon (any number of either, in any order)
      split_vals <- trimws(unlist(strsplit(as.character(val), "[,;]")))
      # Drop trailing qualifiers like " (provisional)" / " (predicted)".
      # We REQUIRE one or more whitespace characters before the "(" so we
      # don't mangle real FlyBase symbols where the paren is part of the
      # name: E(z), Su(dx), Su(fu), su(sable), fs(1)h, l(2)03659 etc.
      split_vals <- trimws(sub("\\s+\\(.*\\)\\s*$", "", split_vals))
      # Drop empties
      split_vals <- split_vals[nchar(split_vals) > 0]
      terms <- c(terms, split_vals)
    }
  }
  unique(terms)
}

# ============================================================
# PUBMED SEARCH
# ============================================================
run_pubmed_search <- function(gene_symbol, ortho_terms) {
  if (length(ortho_terms) == 0) return(NULL)

  # Same query pattern as DCP1A_DCP2_retrieve.R (the working diagnostic):
  # (term1 OR term2 OR ...) AND (cilia OR ciliary OR flagella)
  query <- paste0(
    "(", paste(ortho_terms, collapse = " OR "), ")",
    " AND (cilia OR ciliary OR flagella)"
  )

  res <- tryCatch({
    entrez_search(db = "pubmed", term = query, retmax = 20)
  }, error = function(e) return(NULL))

  if (is.null(res) || length(res$ids) == 0) return(NULL)

  results <- list()
  for (id in res$ids) {
    txt <- tryCatch({
      entrez_fetch(db = "pubmed", id = id, rettype = "abstract", retmode = "text")
    }, error = function(e) return(NULL))
    if (is.null(txt)) next

    # Determine which species the hit is about
    species_hit <- "Unknown"
    txt_lower <- tolower(txt)
    if (grepl("mus musculus|mouse|mice", txt_lower))         species_hit <- "Mus musculus"
    else if (grepl("c\\. elegans|caenorhabditis", txt_lower)) species_hit <- "C. elegans"
    else if (grepl("xenopus|frog", txt_lower))                species_hit <- "Xenopus"
    else if (grepl("zebrafish|danio rerio", txt_lower))       species_hit <- "Danio rerio"
    else if (grepl("drosophila|fly", txt_lower))              species_hit <- "Drosophila"

    results[[length(results) + 1]] <- list(
      pmid    = id,
      species = species_hit,
      abstract = substr(txt, 1, 2000)
    )
  }
  return(results)
}

# ============================================================
# RESUME SUPPORT
# ============================================================
if (file.exists(checkpoint_file)) {
  cat("Resuming from checkpoint...\n")
  rows <- readRDS(checkpoint_file)
  start_i <- length(rows) + 1
} else {
  rows <- list()
  start_i <- 1
}

cat(sprintf("Starting pipeline from gene %d / %d\n", start_i, nrow(master_data)))

# ============================================================
# MAIN LOOP
# ============================================================
for (i in start_i:nrow(master_data)) {

  row <- master_data[i, ]
  gene <- row$Human_Gene
  ortho_terms <- get_orthologs(row)

  cat(sprintf("[%d/%d] %s | orthologs: %d ",
              i, nrow(master_data), gene, length(ortho_terms)))

  res <- run_pubmed_search(gene, ortho_terms)

  if (!is.null(res)) {
    cat(sprintf("| PMIDs: %d\n", length(res)))
    for (r in res) {
      rows[[length(rows) + 1]] <- data.frame(
        Human_Gene   = gene,
        Orthologs    = paste(ortho_terms, collapse = ", "),
        PMID         = r$pmid,
        Species_Hit  = r$species,
        Abstract     = r$abstract,
        stringsAsFactors = FALSE
      )
    }
  } else {
    cat("| no hits\n")
  }

  # Checkpoint every 50 genes
  if (i %% 50 == 0) {
    saveRDS(rows, checkpoint_file)
    cat("Checkpoint saved\n")
  }

  Sys.sleep(0.35)  # NCBI rate limit: max 3 requests/sec
}

# ============================================================
# FINAL SAVE
# ============================================================
final_table <- if (length(rows) > 0) do.call(rbind, rows) else data.frame()
write.csv(final_table, csv_output, row.names = FALSE)

cat("\n============================================================\n")
cat(sprintf("COMPLETE: %d rows saved to %s\n", nrow(final_table), csv_output))
cat("============================================================\n")

# ============================================================
# SUMMARY TABLE
# ============================================================
if (nrow(final_table) > 0) {
  summary_table <- final_table %>%
    group_by(Human_Gene) %>%
    summarise(
      n_papers     = n(),
      unique_pmids = n_distinct(PMID),
      species_hits = paste(unique(Species_Hit), collapse = "; ")
    ) %>%
    arrange(desc(n_papers))

  write.csv(summary_table, summary_output, row.names = FALSE)
  cat(sprintf("Summary saved to %s\n", summary_output))
  cat(sprintf("Genes with hits: %d\n", nrow(summary_table)))
}
