#!/usr/bin/env python3
"""
================================================================================
 generate_ortholog_csvs_for_pubmed.py
 ------------------------------------------------------------------------------
 Produces the two input CSVs required by ciliai_ortholog_pipeline.R:

   1. ciliary_gene_orthologs.csv       — all ~2,610 ciliary genes from v5_4
   2. ciliopathy_gene_orthologs.csv    — the 603 ciliopathy subset

 Column schema (matches what the R script expects):
   Human_Gene, Ortholog_Mouse, Ortholog_C_elegans, Ortholog_Xenopus,
   Ortholog_Zebrafish, Ortholog_Drosophila

 Source:   ciliahub_master_merged_v5_4_2026-05-22.json
 Ciliopathy subset is defined as: gene has non-empty 'ciliopathies' list.

 Notes:
   - Comma-separated orthologs (e.g. "Aladin, CG13137" for fly multi-orthologs)
     are passed through unchanged; the R script splits on comma.
   - Empty / placeholder values are written as empty strings so the R script's
     get_orthologs() function correctly skips them.
   - Output is UTF-8 with Unix line endings, no BOM (R's read.csv handles this).
================================================================================
"""

import csv
import json
import sys
from pathlib import Path
from datetime import datetime

# ─────────────────────────────────────────────────────────────────────────────
#  CONFIGURATION
# ─────────────────────────────────────────────────────────────────────────────

# Auto-detect the most recent v5_4 file in the current directory
def find_master_file() -> Path:
    candidates = sorted(Path(".").glob("ciliahub_master_merged_v5_4_*.json"))
    if candidates:
        return candidates[-1]
    # Fallback: any master_merged
    candidates = sorted(Path(".").glob("ciliahub_master_merged_*.json"))
    if candidates:
        print(f"WARNING: no v5_4 file found, using {candidates[-1].name}")
        return candidates[-1]
    sys.exit("ERROR: no ciliahub_master_merged_*.json found in current dir")

INPUT_FILE = find_master_file()
OUT_DIR    = Path(".")

OUTPUT_CILIARY     = OUT_DIR / "ciliary_gene_orthologs.csv"
OUTPUT_CILIOPATHY  = OUT_DIR / "ciliopathy_gene_orthologs.csv"

# Map CiliaHub species key → R CSV column name
SPECIES_TO_COL = {
    "mouse":      "Ortholog_Mouse",
    "c_elegans":  "Ortholog_C_elegans",
    "xenopus":    "Ortholog_Xenopus",
    "zebrafish":  "Ortholog_Zebrafish",
    "drosophila": "Ortholog_Drosophila",
}

FIELDNAMES = ["Human_Gene"] + [SPECIES_TO_COL[k] for k in
                                ["mouse", "c_elegans", "xenopus",
                                 "zebrafish", "drosophila"]]

PLACEHOLDERS = {"none", "n/a", "na", "-", "unknown",
                "no ortholog", "not found", "null"}

# ─────────────────────────────────────────────────────────────────────────────
#  HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def clean_ortholog_value(val) -> str:
    """
    Normalize ortholog values for the R script:
      - None / placeholder → empty string
      - String → stripped, with internal whitespace normalized after commas
    """
    if val is None:
        return ""
    if not isinstance(val, str):
        val = str(val)
    val = val.strip()
    if val.lower() in PLACEHOLDERS:
        return ""
    # Normalize "A,B" and "A , B" → "A, B"
    if "," in val:
        parts = [p.strip() for p in val.split(",")]
        parts = [p for p in parts if p]
        val = ", ".join(parts)
    return val


def gene_to_row(symbol: str, info: dict) -> dict:
    """Build one CSV row for a single gene."""
    orth = info.get("orthologs") or {}
    if not isinstance(orth, dict):
        orth = {}
    return {
        "Human_Gene":          symbol,
        "Ortholog_Mouse":      clean_ortholog_value(orth.get("mouse")),
        "Ortholog_C_elegans":  clean_ortholog_value(orth.get("c_elegans")),
        "Ortholog_Xenopus":    clean_ortholog_value(orth.get("xenopus")),
        "Ortholog_Zebrafish":  clean_ortholog_value(orth.get("zebrafish")),
        "Ortholog_Drosophila": clean_ortholog_value(orth.get("drosophila")),
    }


def is_ciliopathy_gene(info: dict) -> bool:
    """A gene is in the ciliopathy subset if it has a non-empty
    'ciliopathies' list. Matches the 603-gene set in v5_3/v5_4."""
    cilio = info.get("ciliopathies") or []
    if isinstance(cilio, list) and len(cilio) > 0:
        return True
    return False


# ─────────────────────────────────────────────────────────────────────────────
#  MAIN
# ─────────────────────────────────────────────────────────────────────────────

def main():
    print(f"Loading {INPUT_FILE} ...")
    with open(INPUT_FILE, "r") as f:
        master = json.load(f)

    genes = master["genes"]
    total = len(genes)
    print(f"  Loaded {total} genes\n")

    # Build rows
    print("Building rows ...")
    ciliary_rows    = []
    ciliopathy_rows = []
    stats = {
        "ciliary_total":          0,
        "ciliopathy_total":       0,
        "ciliary_any_ortholog":   0,
        "ciliopathy_any_ortholog":0,
    }
    per_species_filled = {sp: 0 for sp in SPECIES_TO_COL}

    for symbol in sorted(genes.keys()):
        info = genes[symbol]
        row  = gene_to_row(symbol, info)

        # Count ortholog coverage
        any_ortho = any(row[SPECIES_TO_COL[sp]] for sp in SPECIES_TO_COL)
        for sp, col in SPECIES_TO_COL.items():
            if row[col]:
                per_species_filled[sp] += 1

        # Ciliary list: ALL genes in the master JSON
        ciliary_rows.append(row)
        stats["ciliary_total"] += 1
        if any_ortho:
            stats["ciliary_any_ortholog"] += 1

        # Ciliopathy subset
        if is_ciliopathy_gene(info):
            ciliopathy_rows.append(row)
            stats["ciliopathy_total"] += 1
            if any_ortho:
                stats["ciliopathy_any_ortholog"] += 1

    # Write CSVs
    def write_csv(path: Path, rows: list[dict]) -> None:
        # newline='' avoids universal-newlines mangling; lineterminator='\n'
        # forces Unix line endings (R reads either, but '\n' is cleaner).
        with open(path, "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=FIELDNAMES,
                               lineterminator="\n")
            w.writeheader()
            w.writerows(rows)
        print(f"  Wrote {len(rows):5d} rows → {path}")

    print(f"\nWriting outputs ...")
    write_csv(OUTPUT_CILIARY,    ciliary_rows)
    write_csv(OUTPUT_CILIOPATHY, ciliopathy_rows)

    # Stats
    print("\n" + "=" * 60)
    print("SUMMARY")
    print("=" * 60)
    print(f"Input: {INPUT_FILE.name}")
    print(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}")
    print()
    print(f"Ciliary CSV (all genes):")
    print(f"  total rows:           {stats['ciliary_total']:5d}")
    print(f"  with ≥1 ortholog:     {stats['ciliary_any_ortholog']:5d} "
          f"({100*stats['ciliary_any_ortholog']/stats['ciliary_total']:.1f}%)")
    print()
    print(f"Ciliopathy CSV (subset):")
    print(f"  total rows:           {stats['ciliopathy_total']:5d}")
    print(f"  with ≥1 ortholog:     {stats['ciliopathy_any_ortholog']:5d} "
          f"({100*stats['ciliopathy_any_ortholog']/stats['ciliopathy_total']:.1f}%)")
    print()
    print(f"Per-species coverage across all {stats['ciliary_total']} ciliary genes:")
    for sp, col in SPECIES_TO_COL.items():
        n = per_species_filled[sp]
        pct = 100 * n / stats["ciliary_total"]
        print(f"  {sp:14s}: {n:5d} ({pct:5.1f}%)")
    print()
    print(f"Next: copy these CSVs to wherever you'll run the R script:")
    print(f"  cp {OUTPUT_CILIARY.name} {OUTPUT_CILIOPATHY.name} \\")
    print(f"     /Users/sebihacevik/Desktop/Manuscripts/CiliAI_workin/STRING_Clinvar/")
    print()


if __name__ == "__main__":
    main()
