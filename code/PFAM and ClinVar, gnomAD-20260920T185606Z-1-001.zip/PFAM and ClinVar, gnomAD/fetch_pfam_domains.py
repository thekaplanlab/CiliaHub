#!/usr/bin/env python3
"""
CiliaHub PFAM/InterPro Domain Fetcher
=====================================
Fetches PFAM and InterPro domain annotations for all ciliary genes.

Pipeline:
1. Load gene symbols from ciliary_gene_orthologs.csv
2. Map gene symbol → UniProt accession via MyGene.info API
3. Fetch InterPro/PFAM domains per UniProt accession via InterPro API
4. Output: pfam_domains.json (ready to deploy to /data/genes/)

Usage:
    python3 fetch_pfam_domains.py

Requirements:
    pip install requests pandas tqdm

Output files:
    pfam_domains.json        — deploy to /var/www/ciliahub/data/genes/
    pfam_domains_raw.csv     — full domain data for review
    pfam_fetch_errors.txt    — genes that failed lookup
    pfam_checkpoint.json     — checkpoint for resuming interrupted runs

Run time: ~2-4 hours for 2,618 genes (rate limited to 10 req/sec)
"""

import requests
import json
import time
import os
import csv
import pandas as pd
from datetime import datetime

# ── Settings ──────────────────────────────────────────────────────────────
INPUT_CSV       = 'ciliary_gene_orthologs.csv'
OUTPUT_JSON     = 'pfam_domains.json'
OUTPUT_CSV      = 'pfam_domains_raw.csv'
ERROR_FILE      = 'pfam_fetch_errors.txt'
CHECKPOINT_FILE = 'pfam_checkpoint.json'

MYGENE_URL   = 'https://mygene.info/v3/query'
INTERPRO_URL = 'https://www.ebi.ac.uk/interpro/api/entry/pfam/protein/UniProt/{uniprot}/?format=json&page_size=100'
UNIPROT_URL  = 'https://rest.uniprot.org/uniprotkb/search?query=gene_exact:{gene}+AND+organism_id:9606+AND+reviewed:true&fields=accession,protein_name&format=json&size=1'

SLEEP_MYGENE   = 0.1   # 10 req/sec max for MyGene.info
SLEEP_INTERPRO = 0.2   # 5 req/sec max for InterPro
SLEEP_ERROR    = 2.0   # Wait longer after errors

# ── Load checkpoint ───────────────────────────────────────────────────────
def load_checkpoint():
    if os.path.exists(CHECKPOINT_FILE):
        with open(CHECKPOINT_FILE) as f:
            return json.load(f)
    return {'results': {}, 'errors': [], 'processed': []}

def save_checkpoint(data):
    with open(CHECKPOINT_FILE, 'w') as f:
        json.dump(data, f)

# ── Step 1: Map gene symbol to UniProt via MyGene.info ────────────────────
def get_uniprot_id(gene_symbol):
    """Map human gene symbol to canonical UniProt accession."""
    # Try MyGene.info first
    try:
        r = requests.get(MYGENE_URL, params={
            'q': gene_symbol,
            'species': 'human',
            'fields': 'uniprot,symbol',
            'size': 1
        }, timeout=10)
        if r.status_code == 200:
            data = r.json()
            hits = data.get('hits', [])
            if hits:
                uniprot = hits[0].get('uniprot', {})
                # Prefer Swiss-Prot (reviewed) over TrEMBL
                sp = uniprot.get('Swiss-Prot')
                if sp:
                    return sp if isinstance(sp, str) else sp[0]
                tr = uniprot.get('TrEMBL')
                if tr:
                    return tr if isinstance(tr, str) else tr[0]
    except Exception as e:
        pass

    # Fallback: UniProt REST API
    try:
        r = requests.get(UNIPROT_URL.format(gene=gene_symbol), timeout=10)
        if r.status_code == 200:
            data = r.json()
            results = data.get('results', [])
            if results:
                return results[0].get('primaryAccession', '')
    except Exception:
        pass

    return None

# ── Step 2: Fetch PFAM domains from InterPro ─────────────────────────────
def get_pfam_domains(uniprot_id):
    """Fetch PFAM domain entries for a UniProt accession."""
    try:
        url = INTERPRO_URL.format(uniprot=uniprot_id)
        r = requests.get(url, timeout=15)
        if r.status_code == 200:
            data = r.json()
            domains = []
            for entry in data.get('results', []):
                meta = entry.get('metadata', {})
                pfam_id = meta.get('accession', '')
                name    = meta.get('name', '')
                # Get domain positions on the protein
                locations = []
                proteins  = entry.get('proteins', [])
                for prot in proteins:
                    for loc in prot.get('entry_protein_locations', []):
                        for frag in loc.get('fragments', []):
                            locations.append({
                                'start': frag.get('start'),
                                'end':   frag.get('end')
                            })
                domains.append({
                    'pfam_id':     pfam_id,
                    'name':        name,
                    'locations':   locations
                })
            return domains
        elif r.status_code == 404:
            return []  # No domains found — valid result
    except Exception as e:
        pass
    return None  # None = error (retry)

# ── Main pipeline ─────────────────────────────────────────────────────────
def main():
    print("=" * 60)
    print("CiliaHub PFAM Domain Fetcher")
    print(f"Started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 60)

    # Load gene list
    df = pd.read_csv(INPUT_CSV)
    genes = df['Human_Gene'].dropna().unique().tolist()
    print(f"Genes to process: {len(genes)}")

    # Load checkpoint
    ckpt = load_checkpoint()
    results   = ckpt['results']    # gene -> domain data
    errors    = ckpt['errors']     # genes that failed
    processed = set(ckpt['processed'])

    remaining = [g for g in genes if g not in processed]
    print(f"Already processed: {len(processed)} | Remaining: {len(remaining)}")

    for i, gene in enumerate(remaining):
        print(f"[{len(processed)+1}/{len(genes)}] {gene}", end='', flush=True)

        # Step 1: Get UniProt ID
        time.sleep(SLEEP_MYGENE)
        uniprot = get_uniprot_id(gene)
        if not uniprot:
            print(f" | no UniProt ID")
            errors.append(gene)
            processed.add(gene)
            results[gene] = {'uniprot': None, 'domains': [], 'domain_count': 0}
            continue

        print(f" | UniProt: {uniprot}", end='', flush=True)

        # Step 2: Get PFAM domains
        time.sleep(SLEEP_INTERPRO)
        domains = get_pfam_domains(uniprot)

        if domains is None:
            # Error — retry once
            time.sleep(SLEEP_ERROR)
            domains = get_pfam_domains(uniprot)

        if domains is None:
            print(f" | ERROR fetching domains")
            errors.append(gene)
            processed.add(gene)
            results[gene] = {'uniprot': uniprot, 'domains': [], 'domain_count': 0}
            continue

        print(f" | {len(domains)} domains")
        results[gene] = {
            'uniprot':      uniprot,
            'domains':      domains,
            'domain_count': len(domains)
        }
        processed.add(gene)

        # Checkpoint every 50 genes
        if len(processed) % 50 == 0:
            ckpt['results']   = results
            ckpt['errors']    = errors
            ckpt['processed'] = list(processed)
            save_checkpoint(ckpt)
            print(f"  >>> Checkpoint saved ({len(processed)} genes done)")

    # ── Final save ────────────────────────────────────────────────────────
    ckpt['results']   = results
    ckpt['errors']    = errors
    ckpt['processed'] = list(processed)
    save_checkpoint(ckpt)

    # Build final JSON for deployment
    out = {
        'meta': {
            'generated_at':  datetime.now().strftime('%Y-%m-%d'),
            'total_genes':   len(results),
            'genes_with_domains': sum(1 for v in results.values() if v['domain_count'] > 0),
            'total_domains': sum(v['domain_count'] for v in results.values()),
            'errors':        len(errors),
            'source':        'InterPro/PFAM via EBI REST API + MyGene.info'
        },
        'genes': results
    }
    with open(OUTPUT_JSON, 'w') as f:
        json.dump(out, f, indent=2, ensure_ascii=False)

    # Build CSV for review
    csv_rows = []
    for gene, data in results.items():
        if not data['domains']:
            csv_rows.append({
                'Gene': gene, 'UniProt': data.get('uniprot',''),
                'PFAM_ID': '', 'Domain_Name': '',
                'Start': '', 'End': ''
            })
        for dom in data['domains']:
            for loc in (dom['locations'] or [{}]):
                csv_rows.append({
                    'Gene':        gene,
                    'UniProt':     data.get('uniprot',''),
                    'PFAM_ID':     dom['pfam_id'],
                    'Domain_Name': dom['name'],
                    'Start':       loc.get('start',''),
                    'End':         loc.get('end','')
                })
    pd.DataFrame(csv_rows).to_csv(OUTPUT_CSV, index=False)

    # Error log
    with open(ERROR_FILE, 'w') as f:
        f.write('\n'.join(errors))

    print("\n" + "=" * 60)
    print("COMPLETE")
    print(f"  Total genes:        {out['meta']['total_genes']}")
    print(f"  With PFAM domains:  {out['meta']['genes_with_domains']}")
    print(f"  Total domains:      {out['meta']['total_domains']}")
    print(f"  Errors:             {out['meta']['errors']}")
    print(f"  Output JSON:        {OUTPUT_JSON}")
    print(f"  Output CSV:         {OUTPUT_CSV}")
    print("=" * 60)
    print("\nDeploy with:")
    print(f"  scp {OUTPUT_JSON} root@161.97.146.90:/var/www/ciliahub/data/genes/")

if __name__ == '__main__':
    main()
