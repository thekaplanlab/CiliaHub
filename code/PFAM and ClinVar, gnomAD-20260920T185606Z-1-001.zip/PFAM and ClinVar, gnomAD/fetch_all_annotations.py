#!/usr/bin/env python3
"""
CiliaHub Annotation Pipeline — All 5 data sources
===================================================
Fetches: ClinVar variants, gnomAD constraints, AlphaFold links,
         GO terms, MGI mouse phenotypes

Usage:
    pip install requests pandas tqdm
    python3 fetch_all_annotations.py

    # Or run individual modules:
    python3 fetch_all_annotations.py --module clinvar
    python3 fetch_all_annotations.py --module gnomad
    python3 fetch_all_annotations.py --module alphafold
    python3 fetch_all_annotations.py --module go
    python3 fetch_all_annotations.py --module mgi

Input:  ciliary_gene_orthologs.csv
Output: annotations/ folder with one JSON per module
        final: all_annotations.json (merged, deploy-ready)
"""

import requests, json, time, os, sys, argparse
import pandas as pd, numpy as np
from datetime import datetime
from pathlib import Path

# ── Config ────────────────────────────────────────────────────────────────
INPUT_CSV   = 'ciliary_gene_orthologs.csv'
OUT_DIR     = Path('annotations')
OUT_DIR.mkdir(exist_ok=True)
FINAL_JSON  = 'all_annotations.json'

MYGENE_URL  = 'https://mygene.info/v3'
NCBI_EUTIL  = 'https://eutils.ncbi.nlm.nih.gov/entrez/eutils'
GNOMAD_URL  = 'https://gnomad.broadinstitute.org/api'
MGI_URL     = 'https://www.informatics.jax.org/marker/phenotypes'

def load_genes():
    df = pd.read_csv(INPUT_CSV)
    return df['Human_Gene'].dropna().unique().tolist()

def load_checkpoint(name):
    p = OUT_DIR / f'{name}_checkpoint.json'
    if p.exists():
        with open(p) as f: return json.load(f)
    return {'results': {}, 'processed': []}

def save_checkpoint(name, data):
    p = OUT_DIR / f'{name}_checkpoint.json'
    with open(p, 'w') as f: json.dump(data, f)

def mygene_batch(genes, fields, batch=1000):
    """Batch query MyGene.info — up to 1000 genes per request."""
    results = {}
    for i in range(0, len(genes), batch):
        chunk = genes[i:i+batch]
        r = requests.post(f'{MYGENE_URL}/gene',
            json={'ids': ','.join(chunk), 'species': 'human', 'fields': fields},
            timeout=30)
        if r.status_code == 200:
            for hit in r.json():
                sym = hit.get('symbol') or hit.get('query','')
                if sym: results[sym.upper()] = hit
        time.sleep(0.5)
    return results

# ══════════════════════════════════════════════════════════════════════════
# MODULE 1: ClinVar variants
# ══════════════════════════════════════════════════════════════════════════
def fetch_clinvar(genes):
    print("\n" + "="*50)
    print("MODULE 1: ClinVar Variants")
    print("="*50)

    ckpt = load_checkpoint('clinvar')
    results   = ckpt['results']
    processed = set(ckpt['processed'])
    remaining = [g for g in genes if g not in processed]
    print(f"Remaining: {len(remaining)}/{len(genes)}")

    for i, gene in enumerate(remaining):
        print(f"[{len(processed)+1}/{len(genes)}] {gene}", end='', flush=True)
        try:
            # Search ClinVar for pathogenic variants in this gene
            search_url = f"{NCBI_EUTIL}/esearch.fcgi"
            r = requests.get(search_url, params={
                'db': 'clinvar', 'retmax': 100, 'retmode': 'json',
                'term': f'{gene}[gene] AND (pathogenic[clinical_significance] OR "likely pathogenic"[clinical_significance])'
            }, timeout=15)
            time.sleep(0.34)  # NCBI rate limit: 3/sec

            ids = []
            if r.status_code == 200:
                ids = r.json().get('esearchresult', {}).get('idlist', [])

            if not ids:
                print(f" | 0 variants")
                results[gene] = {'variant_count': 0, 'variants': []}
                processed.add(gene)
                continue

            # Fetch summary for top variants
            fetch_url = f"{NCBI_EUTIL}/esummary.fcgi"
            r2 = requests.get(fetch_url, params={
                'db': 'clinvar', 'id': ','.join(ids[:20]),
                'retmode': 'json'
            }, timeout=20)
            time.sleep(0.34)

            variants = []
            if r2.status_code == 200:
                summaries = r2.json().get('result', {})
                for vid in ids[:20]:
                    s = summaries.get(str(vid), {})
                    if not s or vid == 'uids': continue
                    clin_sig = s.get('clinical_significance', {})
                    if isinstance(clin_sig, dict):
                        sig = clin_sig.get('description', '')
                    else:
                        sig = str(clin_sig)
                    variants.append({
                        'id':          vid,
                        'title':       s.get('title', ''),
                        'significance': sig,
                        'conditions':  [c.get('name','') for c in s.get('trait_set', [])[:3]],
                        'review_status': s.get('review_status', ''),
                        'url': f'https://www.ncbi.nlm.nih.gov/clinvar/variation/{vid}/'
                    })

            print(f" | {len(variants)} pathogenic variants")
            results[gene] = {'variant_count': len(variants), 'variants': variants}
            processed.add(gene)

        except Exception as e:
            print(f" | ERROR: {e}")
            results[gene] = {'variant_count': 0, 'variants': [], 'error': str(e)}
            processed.add(gene)

        if len(processed) % 50 == 0:
            ckpt['results'] = results; ckpt['processed'] = list(processed)
            save_checkpoint('clinvar', ckpt)
            print(f"  >>> Checkpoint ({len(processed)} done)")

    ckpt['results'] = results; ckpt['processed'] = list(processed)
    save_checkpoint('clinvar', ckpt)

    out = {'meta': {'generated_at': datetime.now().strftime('%Y-%m-%d'),
                    'total_genes': len(results),
                    'genes_with_variants': sum(1 for v in results.values() if v.get('variant_count',0) > 0),
                    'source': 'NCBI ClinVar REST API'},
           'genes': results}
    with open(OUT_DIR / 'clinvar.json', 'w') as f: json.dump(out, f, indent=2)
    print(f"\nClinVar: {out['meta']['genes_with_variants']} genes with pathogenic variants")
    return results

# ══════════════════════════════════════════════════════════════════════════
# MODULE 2: gnomAD constraint scores
# ══════════════════════════════════════════════════════════════════════════
def fetch_gnomad(genes):
    print("\n" + "="*50)
    print("MODULE 2: gnomAD Constraint Scores")
    print("="*50)

    # Try to use the gnomAD GraphQL API for constraint scores
    # Batch 50 genes at a time
    results = {}
    BATCH = 50

    for i in range(0, len(genes), BATCH):
        chunk = genes[i:i+BATCH]
        print(f"Fetching gnomAD batch {i//BATCH+1}/{len(genes)//BATCH+1} ({len(chunk)} genes)...", flush=True)

        for gene in chunk:
            query = """
            query GeneConstraint($geneSymbol: String!) {
              gene(gene_symbol: $geneSymbol, reference_genome: GRCh38) {
                gnomad_constraint {
                  lof_z
                  oe_lof
                  oe_lof_lower
                  oe_lof_upper
                  pLI
                  syn_z
                  mis_z
                }
              }
            }"""
            try:
                r = requests.post(GNOMAD_URL,
                    json={'query': query, 'variables': {'geneSymbol': gene}},
                    timeout=15)
                time.sleep(0.2)
                if r.status_code == 200:
                    data = r.json().get('data', {}).get('gene', {})
                    constraint = (data or {}).get('gnomad_constraint', {}) or {}
                    if constraint:
                        pli = constraint.get('pLI')
                        oe  = constraint.get('oe_lof')
                        results[gene] = {
                            'pLI':         round(pli, 4) if pli is not None else None,
                            'oe_lof':      round(oe, 4) if oe is not None else None,
                            'oe_lof_lower':constraint.get('oe_lof_lower'),
                            'oe_lof_upper':constraint.get('oe_lof_upper'),
                            'lof_z':       constraint.get('lof_z'),
                            'mis_z':       constraint.get('mis_z'),
                            'syn_z':       constraint.get('syn_z'),
                            'intolerant':  pli >= 0.9 if pli is not None else None,
                        }
                    else:
                        results[gene] = {'pLI': None, 'oe_lof': None}
            except Exception as e:
                results[gene] = {'pLI': None, 'oe_lof': None, 'error': str(e)}

    with_scores = sum(1 for v in results.values() if v.get('pLI') is not None)
    intolerant  = sum(1 for v in results.values() if v.get('intolerant'))

    out = {'meta': {'generated_at': datetime.now().strftime('%Y-%m-%d'),
                    'total_genes': len(results),
                    'genes_with_scores': with_scores,
                    'intolerant_to_lof': intolerant,
                    'source': 'gnomAD v4 GraphQL API'},
           'genes': results}
    with open(OUT_DIR / 'gnomad.json', 'w') as f: json.dump(out, f, indent=2)
    print(f"\ngnomAD: {with_scores} genes with scores, {intolerant} intolerant to LoF (pLI≥0.9)")
    return results

# ══════════════════════════════════════════════════════════════════════════
# MODULE 3: AlphaFold links (via UniProt IDs from MyGene.info)
# ══════════════════════════════════════════════════════════════════════════
def fetch_alphafold(genes):
    print("\n" + "="*50)
    print("MODULE 3: AlphaFold Structure Links")
    print("="*50)

    print(f"Fetching UniProt IDs for {len(genes)} genes via MyGene.info...")
    mg_results = mygene_batch(genes, 'uniprot,symbol,name')

    results = {}
    for gene in genes:
        hit = mg_results.get(gene.upper(), {})
        uniprot = hit.get('uniprot', {})
        sp = uniprot.get('Swiss-Prot') if isinstance(uniprot, dict) else None
        if sp:
            uid = sp if isinstance(sp, str) else sp[0]
            results[gene] = {
                'uniprot':       uid,
                'alphafold_url': f'https://alphafold.ebi.ac.uk/entry/{uid}',
                'uniprot_url':   f'https://www.uniprot.org/uniprot/{uid}',
                'name':          hit.get('name','')
            }
        else:
            results[gene] = {'uniprot': None, 'alphafold_url': None}

    with_af = sum(1 for v in results.values() if v.get('alphafold_url'))
    out = {'meta': {'generated_at': datetime.now().strftime('%Y-%m-%d'),
                    'total_genes': len(results),
                    'genes_with_alphafold': with_af,
                    'source': 'MyGene.info → UniProt → AlphaFold EBI'},
           'genes': results}
    with open(OUT_DIR / 'alphafold.json', 'w') as f: json.dump(out, f, indent=2)
    print(f"\nAlphaFold: {with_af} genes with structure links")
    return results

# ══════════════════════════════════════════════════════════════════════════
# MODULE 4: GO terms via MyGene.info
# ══════════════════════════════════════════════════════════════════════════
def fetch_go_terms(genes):
    print("\n" + "="*50)
    print("MODULE 4: GO Term Annotations")
    print("="*50)

    print(f"Fetching GO terms for {len(genes)} genes via MyGene.info...")
    mg_results = mygene_batch(genes, 'go,symbol')

    results = {}
    for gene in genes:
        hit = mg_results.get(gene.upper(), {})
        go_raw = hit.get('go', {})
        if not go_raw:
            results[gene] = {'bp': [], 'mf': [], 'cc': []}
            continue

        def extract_go(section):
            terms = go_raw.get(section, [])
            if isinstance(terms, dict): terms = [terms]
            return [{'id': t.get('id',''), 'term': t.get('term','')}
                    for t in (terms or []) if t.get('term')][:10]

        bp = extract_go('BP')  # Biological Process
        mf = extract_go('MF')  # Molecular Function
        cc = extract_go('CC')  # Cellular Component

        # Flag cilia-relevant GO terms
        cilia_terms = [t for t in bp+mf+cc
                       if any(k in t['term'].lower() for k in
                              ['cili','flagell','basal body','axoneme','intraflagellar',
                               'transition zone','centrosome'])]

        results[gene] = {
            'biological_process': bp,
            'molecular_function':  mf,
            'cellular_component':  cc,
            'cilia_go_terms':      cilia_terms,
            'n_cilia_terms':       len(cilia_terms)
        }

    with_go    = sum(1 for v in results.values() if v.get('biological_process'))
    with_cilia = sum(1 for v in results.values() if v.get('n_cilia_terms',0) > 0)

    out = {'meta': {'generated_at': datetime.now().strftime('%Y-%m-%d'),
                    'total_genes': len(results),
                    'genes_with_go': with_go,
                    'genes_with_cilia_go': with_cilia,
                    'source': 'MyGene.info GO annotations'},
           'genes': results}
    with open(OUT_DIR / 'go_terms.json', 'w') as f: json.dump(out, f, indent=2)
    print(f"\nGO terms: {with_go} genes annotated, {with_cilia} with cilia-related GO terms")
    return results

# ══════════════════════════════════════════════════════════════════════════
# MODULE 5: MGI mouse phenotypes
# ══════════════════════════════════════════════════════════════════════════
def fetch_mgi(genes, orthologs_df):
    print("\n" + "="*50)
    print("MODULE 5: MGI Mouse Phenotypes")
    print("="*50)

    # Use MyGene.info to get MGI IDs, then fetch phenotypes
    print(f"Fetching MGI IDs via MyGene.info...")
    mg_results = mygene_batch(genes, 'MGI,symbol,mouse.phenotypes')

    ckpt = load_checkpoint('mgi')
    results   = ckpt['results']
    processed = set(ckpt['processed'])
    remaining = [g for g in genes if g not in processed]
    print(f"Remaining: {len(remaining)}/{len(genes)}")

    MGI_SEARCH = 'https://www.informatics.jax.org/searchtool/Search.do'

    for i, gene in enumerate(remaining):
        hit = mg_results.get(gene.upper(), {})

        # Try MyGene phenotype data first (fast)
        mouse_pheno = hit.get('mouse', {})
        if isinstance(mouse_pheno, dict):
            phenotypes = mouse_pheno.get('phenotypes', [])
            if phenotypes:
                # Format phenotype terms
                terms = []
                if isinstance(phenotypes, list):
                    terms = [p.get('term','') for p in phenotypes[:10] if isinstance(p,dict) and p.get('term')]
                results[gene] = {
                    'source':     'mygene',
                    'phenotypes': terms,
                    'mgi_url':    f'https://www.informatics.jax.org/searchtool/Search.do?query={gene}',
                    'n_phenotypes': len(terms)
                }
                processed.add(gene)
                if i % 100 == 0:
                    print(f"[{len(processed)}/{len(genes)}] {gene} | {len(terms)} phenotype terms")
                continue

        # Fallback: use mouse ortholog from our CSV
        mouse_orth = orthologs_df[orthologs_df['Human_Gene']==gene]['Ortholog_Mouse'].values
        mouse_sym  = mouse_orth[0] if len(mouse_orth) > 0 and pd.notna(mouse_orth[0]) else None

        results[gene] = {
            'source':     'ortholog_only',
            'phenotypes': [],
            'mgi_url':    f'https://www.informatics.jax.org/searchtool/Search.do?query={mouse_sym or gene}',
            'mouse_symbol': mouse_sym,
            'n_phenotypes': 0
        }
        processed.add(gene)

        if len(processed) % 50 == 0:
            ckpt['results'] = results; ckpt['processed'] = list(processed)
            save_checkpoint('mgi', ckpt)

    ckpt['results'] = results; ckpt['processed'] = list(processed)
    save_checkpoint('mgi', ckpt)

    with_pheno = sum(1 for v in results.values() if v.get('n_phenotypes',0) > 0)
    out = {'meta': {'generated_at': datetime.now().strftime('%Y-%m-%d'),
                    'total_genes': len(results),
                    'genes_with_phenotypes': with_pheno,
                    'source': 'MyGene.info mouse phenotypes + MGI'},
           'genes': results}
    with open(OUT_DIR / 'mgi.json', 'w') as f: json.dump(out, f, indent=2)
    print(f"\nMGI: {with_pheno} genes with mouse phenotype data")
    return results

# ══════════════════════════════════════════════════════════════════════════
# MERGE: Combine all annotations into single deploy-ready JSON
# ══════════════════════════════════════════════════════════════════════════
def merge_all(genes):
    print("\n" + "="*50)
    print("MERGING all annotation files...")
    print("="*50)

    modules = ['clinvar', 'gnomad', 'alphafold', 'go_terms', 'mgi']
    module_data = {}
    for mod in modules:
        p = OUT_DIR / f'{mod}.json'
        if p.exists():
            with open(p) as f:
                module_data[mod] = json.load(f).get('genes', {})
            print(f"  Loaded {mod}: {len(module_data[mod])} genes")
        else:
            print(f"  MISSING: {mod}.json — skipping")

    merged = {}
    for gene in genes:
        merged[gene] = {}
        for mod, data in module_data.items():
            rec = data.get(gene, {})
            if rec: merged[gene][mod] = rec

    out = {
        'meta': {
            'generated_at': datetime.now().strftime('%Y-%m-%d'),
            'total_genes':  len(merged),
            'modules':      list(module_data.keys()),
            'description':  'Merged annotation data: ClinVar, gnomAD, AlphaFold, GO terms, MGI'
        },
        'genes': merged
    }
    with open(FINAL_JSON, 'w') as f: json.dump(out, f, indent=2)

    size_mb = os.path.getsize(FINAL_JSON) / 1024 / 1024
    print(f"\nMerged → {FINAL_JSON} ({size_mb:.1f} MB)")
    print(f"\nDeploy with:")
    print(f"  scp {FINAL_JSON} root@161.97.146.90:/var/www/ciliahub/data/genes/")
    print(f"  scp annotations/clinvar.json root@161.97.146.90:/var/www/ciliahub/data/genes/")
    print(f"  scp annotations/gnomad.json root@161.97.146.90:/var/www/ciliahub/data/genes/")
    print(f"  scp annotations/alphafold.json root@161.97.146.90:/var/www/ciliahub/data/genes/")
    print(f"  scp annotations/go_terms.json root@161.97.146.90:/var/www/ciliahub/data/genes/")
    print(f"  scp annotations/mgi.json root@161.97.146.90:/var/www/ciliahub/data/genes/")

# ══════════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════════
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--module', choices=['clinvar','gnomad','alphafold','go','mgi','merge','all'],
                        default='all')
    args = parser.parse_args()

    print("=" * 60)
    print("CiliaHub Annotation Pipeline")
    print(f"Started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"Module: {args.module}")
    print("=" * 60)

    genes = load_genes()
    df    = pd.read_csv(INPUT_CSV)
    print(f"Genes loaded: {len(genes)}")

    if args.module in ('all', 'clinvar'):   fetch_clinvar(genes)
    if args.module in ('all', 'gnomad'):    fetch_gnomad(genes)
    if args.module in ('all', 'alphafold'): fetch_alphafold(genes)
    if args.module in ('all', 'go'):        fetch_go_terms(genes)
    if args.module in ('all', 'mgi'):       fetch_mgi(genes, df)
    if args.module in ('all', 'merge'):     merge_all(genes)

    if args.module == 'all':
        merge_all(genes)

    print("\n✅ DONE")

if __name__ == '__main__':
    main()
