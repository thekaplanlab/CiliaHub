# ================================================
# generate_cilia_variant.R  —  ROBUST FINAL VERSION
# ================================================

library(jsonlite)
library(data.table)
library(httr)

setwd("/Users/sebihacevik/Desktop/Manuscripts/CiliAI_workin/STRING_Clinvar")

# High timeout for large file
options(timeout = 3600)
options(download.file.method = "libcurl")

# ========================================
# 1. Load masterData
# ========================================
cat("Loading ciliAI_master_database.json...\n")

raw_json <- fromJSON("ciliAI_master_database.json", simplifyVector = TRUE)

if ("masterData" %in% names(raw_json)) {
  master <- raw_json$masterData
} else {
  master <- raw_json
}

gene_col <- if ("Gene" %in% names(master)) {
  "Gene"
} else if ("gene" %in% names(master)) {
  "gene"
} else {
  stop("❌ No Gene column found in master database.")
}

ciliary_genes <- unique(toupper(trimws(master[[gene_col]])))
ciliary_genes <- ciliary_genes[ciliary_genes != "" & !is.na(ciliary_genes)]

cat("✅ Loaded", length(ciliary_genes), "ciliary genes.\n")

# ========================================
# 2. Download ClinVar (if needed)
# ========================================
clinvar_gz <- "variant_summary.txt.gz"
clinvar_url <- "https://ftp.ncbi.nlm.nih.gov/pub/clinvar/tab_delimited/variant_summary.txt.gz"

if (!file.exists(clinvar_gz)) {
  cat("Downloading ClinVar (~416 MB)...\n")
  download.file(clinvar_url, clinvar_gz, mode = "wb")
  cat("Download finished.\n")
} else {
  cat("Using existing ClinVar file.\n")
}

# ========================================
# 3. Read ClinVar safely
# ========================================
cat("Reading ClinVar file...\n")

clinvar <- fread(
  clinvar_gz,
  sep = "\t",
  header = TRUE,
  stringsAsFactors = FALSE,
  fill = TRUE,
  blank.lines.skip = TRUE,
  showProgress = TRUE
)

cat("Columns detected:\n")
print(names(clinvar))

# ========================================
# 4. Normalize required columns
# ========================================

# Required core columns
required_cols <- c(
  "VariationID",
  "GeneSymbol",
  "Name",
  "ClinicalSignificance",
  "PhenotypeList",
  "ReviewStatus",
  "LastEvaluated"
)

missing_required <- setdiff(required_cols, names(clinvar))
if (length(missing_required) > 0) {
  stop(paste("❌ Missing required columns:", paste(missing_required, collapse = ", ")))
}

# --- Protein change handling (robust) ---
if ("ProteinChange" %in% names(clinvar)) {
  # OK
} else if ("AminoAcidChange" %in% names(clinvar)) {
  setnames(clinvar, "AminoAcidChange", "ProteinChange")
} else {
  clinvar[, ProteinChange := NA_character_]
}

# Ensure column exists
if (!"ProteinChange" %in% names(clinvar)) {
  stop("❌ ProteinChange column could not be created.")
}

# Keep only needed columns
keep_cols <- c(required_cols, "ProteinChange")
clinvar <- clinvar[, ..keep_cols]

# ========================================
# 5. Clean + filter
# ========================================

# Normalize gene symbols
clinvar[, GeneSymbol := toupper(trimws(GeneSymbol))]

# Filter ciliary genes
clinvar <- clinvar[GeneSymbol %in% ciliary_genes]

# Filter pathogenic variants
clinvar <- clinvar[
  grepl("Pathogenic|Likely pathogenic", ClinicalSignificance, ignore.case = TRUE)
]

cat("✅ Found", nrow(clinvar), "pathogenic variants in",
    length(unique(clinvar$GeneSymbol)), "ciliary genes.\n")

# ========================================
# 6. Build per-gene variant list
# ========================================

cilia_variants <- split(clinvar, by = "GeneSymbol")

cilia_variants <- lapply(cilia_variants, function(df) {
  df[, .(
    variant_id = as.character(VariationID),
    hgvs_c = as.character(Name),
    hgvs_p = as.character(ProteinChange),
    clinical_significance = as.character(ClinicalSignificance),
    conditions = as.character(PhenotypeList),
    review_status = as.character(ReviewStatus),
    last_evaluated = as.character(LastEvaluated)
  )]
})

# ========================================
# 7. Save JSON
# ========================================

write_json(
  cilia_variants,
  "cilia_variant.json",
  pretty = TRUE,
  auto_unbox = TRUE
)

# ========================================
# 8. Final summary
# ========================================

cat("\n🎉 SUCCESS!\n")
cat("File created: cilia_variant.json\n")
cat("Genes with variants:", length(cilia_variants), "\n")

if ("CEP290" %in% names(cilia_variants)) {
  cat("CEP290 variants:", nrow(cilia_variants[["CEP290"]]), "\n")
} else {
  cat("CEP290 variants: 0\n")
}

cat("\nYou can now:\n")
cat("✔ Run your PPI script\n")
cat("✔ Upload both files to GitHub /data/\n")