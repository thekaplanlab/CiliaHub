/* ciliai-reason.js — CiliAI reasoning engine (flagship #1)
 *
 * Turns CiliAI from a bank of ~15 pre-built handlers into an open-ended, compositional
 * assistant WITHOUT giving up the data-grounded guarantee. An LLM acts only as a PLANNER:
 * it decomposes a natural-language question into calls to a fixed set of deterministic
 * TOOLS that query the curated lookups, and composes the tool RESULTS into the answer.
 * The LLM never supplies biological facts — every gene, count, and citation comes from the
 * data. This answers arbitrary multi-hop questions ("transition-zone genes with a retinal
 * phenotype in mouse but no human disease yet") with no new handler per question shape.
 *
 * Integration: this module is LLM-agnostic. `reason(query, llmCall, opts)` takes an
 * injectable `llmCall(prompt) -> Promise<string>`. Wire it to CiliaHub's existing LLM path
 * (window.CiliAIAssistant.ask or equivalent) at deploy time. It reads window.CiliAI.lookups
 * and the two sidecars (disease profiles, literature) the same way the handlers do.
 *
 * Field-name tolerant: reads both the master form (localization, protein_complex,
 * ciliopathies) and the runtime geneMap form (Localization, Complex, Ciliopathies).
 */
(function (root) {
  'use strict';

  // ── helpers ────────────────────────────────────────────────────────────────
  function norm(s){ return String(s == null ? '' : s).toUpperCase().replace(/[^A-Z0-9]/g, ''); }
  function dnorm(s){
    s = String(s == null ? '' : s).toLowerCase();
    try { s = s.normalize('NFD').replace(/[\u0300-\u036f]/g, ''); } catch (e) {}
    return s.replace(/ø/g,'o').replace(/ł/g,'l').replace(/[^a-z0-9]/g,'');
  }
  function asArr(v){ return v == null ? [] : (Array.isArray(v) ? v : [v]); }
  function uniq(a){ return Array.from(new Set(a)); }
  // field accessors tolerant of master (lowercase) vs runtime geneMap (Title-case)
  function fLoc(r){ var v = r.localization != null ? r.localization : r.Localization;
    return (Array.isArray(v) ? v.join('; ') : String(v||'')).toLowerCase(); }
  function fComplex(r){ var v = r.protein_complex != null ? r.protein_complex : r.Complex;
    return String(v||'').toLowerCase(); }
  function fCilio(r){ var v = r.ciliopathies != null ? r.ciliopathies : r.Ciliopathies;
    return asArr(v).filter(Boolean); }
  function fTier(r){ return String(r.evidence_tier||''); }
  function fPanIdio(r){ return String(r.pan_idio_class||'').toLowerCase(); }
  function fDomains(r){ return asArr(r.pfam_domains).map(function(d){
    return String((d && (d.name || d.pfam_id)) || d || '').toLowerCase(); }); }
  function fOrtho(r){ return (r.orthologs && typeof r.orthologs === 'object') ? r.orthologs : {}; }
  function fPheno(r, organism){
    if (/mouse/i.test(organism||'')) return String(r.mouse_phenotype || r.mouse_ciliopathy_phenotype || '').toLowerCase();
    if (/human/i.test(organism||'')) return String(r.human_phenotype || r.human_ciliopathy_phenotype || '').toLowerCase();
    return String([r.mouse_phenotype, r.human_phenotype, r.human_ciliopathy_phenotype,
                   r.model_organism_phenotypes].filter(Boolean).join(' ')).toLowerCase();
  }
  function geneList(L){ return Object.keys(L.geneMap || {}); }
  function recOf(L, key){ var gm = L.geneMap||{}; return gm[key] || gm[key && key.toUpperCase()] || null; }
  function symOf(L, key){ var r = recOf(L, key); return (r && (r.gene || r.symbol)) || key; }

  function resolveDiseaseKey(L, text){
    var bc = L.byCiliopathy || {}; var q = dnorm(text), best = null, bl = 0;
    Object.keys(bc).forEach(function(k){
      var kn = dnorm(k);
      if (kn.length >= 5 && q.indexOf(kn) !== -1 && kn.length > bl){ best = k; bl = kn.length; return; }
      var core = kn.replace(/(syndrome|disease|ciliopathy|ciliopathies|dysplasia|degeneration|dystrophy)$/,'');
      if (core.length >= 5 && q.indexOf(core) !== -1 && core.length > bl){ best = k; bl = core.length; }
    });
    return best;
  }
  function resolveClassKey(L, text){
    var bcl = L.byClassification || {}; var t = (text||'').toLowerCase();
    var want = /primary/.test(t) ? 'primary' : /motile/.test(t) ? 'motile'
             : /idio|tissue/.test(t) ? 'tissue-restricted' : /secondary/.test(t) ? 'secondary' : null;
    if (!want) return null;
    return Object.keys(bcl).find(function(k){ return k.toLowerCase().indexOf(want) !== -1; }) || null;
  }

  // ── TOOLS (each: {desc, run(L,args)->{genes|value|count, note}}) ─────────────
  var TOOLS = {
    genes_in_disease: { desc: "genes associated with a ciliopathy/disease. args:{disease}",
      run: function(L,a){ var k = resolveDiseaseKey(L, a.disease);
        return { genes: k ? uniq((L.byCiliopathy[k]||[])) : [], note: k ? ('disease='+k) : 'no disease match' }; } },
    genes_in_class: { desc: "genes in a disease class: primary|motile|idio/tissue-restricted|secondary. args:{class}",
      run: function(L,a){ var k = resolveClassKey(L, a['class'] || a.klass || a.category);
        var s = k ? uniq((L.byClassification[k]||[])) : [];
        if (k && /secondary/i.test(k)){ var mod = Object.keys(L.byClassification).find(function(x){return /bbs modifier/i.test(x);});
          if (mod) s = uniq(s.concat(L.byClassification[mod]||[])); }
        return { genes: s, note: k || 'no class match' }; } },
    genes_in_complex: { desc: "genes in a protein complex/module (e.g. BBSome, IFT-B). args:{complex}",
      run: function(L,a){ var byMod = L.byModuleOrComplex||{}; var q = dnorm(a.complex);
        var mk = Object.keys(byMod).find(function(k){ return dnorm(k).indexOf(q) !== -1; });
        if (mk) return { genes: uniq(byMod[mk]||[]), note: 'complex='+mk };
        // fallback: scan per-gene protein_complex
        var g = geneList(L).filter(function(s){ return fComplex(recOf(L,s)).indexOf((a.complex||'').toLowerCase()) !== -1; });
        return { genes: g.map(function(s){return symOf(L,s);}), note: 'scanned protein_complex' }; } },
    genes_with_localization: { desc: "genes localizing to a compartment (transition zone, basal body, axoneme...). args:{localization}",
      run: function(L,a){ var t = (a.localization||'').toLowerCase();
        var g = geneList(L).filter(function(s){ return fLoc(recOf(L,s)).indexOf(t) !== -1; });
        return { genes: g.map(function(s){return symOf(L,s);}), note: 'localization~'+t }; } },
    genes_with_domain: { desc: "genes with a Pfam domain (e.g. WD40, coiled-coil, TPR). args:{domain}",
      run: function(L,a){ var t = (a.domain||'').toLowerCase().replace(/[^a-z0-9]/g,'');
        var g = geneList(L).filter(function(s){ return fDomains(recOf(L,s)).some(function(d){ return d.replace(/[^a-z0-9]/g,'').indexOf(t)!==-1; }); });
        return { genes: g.map(function(s){return symOf(L,s);}), note: 'domain~'+t }; } },
    genes_conserved_in: { desc: "genes with an ortholog in a species: mouse|c_elegans|zebrafish|drosophila|xenopus. args:{species}",
      run: function(L,a){ var sp = (a.species||'').toLowerCase().replace(/[^a-z]/g,'');
        var map = {mouse:'mouse',mice:'mouse',celegans:'c_elegans',worm:'c_elegans',zebrafish:'zebrafish',danio:'zebrafish',
                   drosophila:'drosophila',fly:'drosophila',xenopus:'xenopus',frog:'xenopus'};
        var key = map[sp] || sp;
        var g = geneList(L).filter(function(s){ var v = fOrtho(recOf(L,s))[key]; return v && String(v).trim() && String(v).trim()!=='—'; });
        return { genes: g.map(function(s){return symOf(L,s);}), note: 'ortholog in '+key }; } },
    genes_by_tier: { desc: "genes by evidence tier: gold | cilia-associated. args:{tier}",
      run: function(L,a){ var gold = /gold/i.test(a.tier||'');
        var g = geneList(L).filter(function(s){ var t = fTier(recOf(L,s)); return gold ? /gold/i.test(t) : /cilia.?associated/i.test(t); });
        return { genes: g.map(function(s){return symOf(L,s);}), note: gold?'gold standard':'cilia-associated' }; } },
    genes_by_pan_idio: { desc: "genes by EXPRESSION class (not disease class): pan | idio. args:{category}",
      run: function(L,a){ var pan = /pan/i.test(a.category||'');
        var g = geneList(L).filter(function(s){ var c = fPanIdio(recOf(L,s)); return pan ? c==='pan_ciliary' : c==='idio_ciliary'; });
        return { genes: g.map(function(s){return symOf(L,s);}), note: pan?'pan-ciliary':'idio-ciliary' }; } },
    genes_with_phenotype_text: { desc: "genes whose phenotype text mentions a term, optionally per organism. args:{text, organism?}",
      run: function(L,a){ var t = (a.text||'').toLowerCase();
        var g = geneList(L).filter(function(s){ return fPheno(recOf(L,s), a.organism).indexOf(t) !== -1; });
        return { genes: g.map(function(s){return symOf(L,s);}), note: 'phenotype~'+t+(a.organism?(' ('+a.organism+')'):'') }; } },
    genes_with_any_disease: { desc: "all genes that carry at least one human ciliopathy association. args:{}",
      run: function(L){ var g = geneList(L).filter(function(s){ return fCilio(recOf(L,s)).length > 0; });
        return { genes: g.map(function(s){return symOf(L,s);}), note: 'has >=1 ciliopathy' }; } },
    all_genes: { desc: "every gene in the catalog (use as a base set for differences). args:{}",
      run: function(L){ return { genes: geneList(L).map(function(s){return symOf(L,s);}), note: 'all curated genes' }; } },
    gene_info: { desc: "attributes of one gene. args:{gene, fields?:[localization,complex,tier,pan_idio,ciliopathies,orthologs,clingen,mouse_phenotype,ids,synonyms]}",
      run: function(L,a){ var r = recOf(L, a.gene); if (!r) return { value: null, note: a.gene+' not in catalog' };
        var out = {};
        out.localization = fLoc(r); out.complex = fComplex(r); out.tier = fTier(r);
        out.pan_idio = fPanIdio(r); out.ciliopathies = fCilio(r); out.orthologs = fOrtho(r);
        out.clingen = r.clingen_disease || ''; out.mouse_phenotype = r.mouse_phenotype || '';
        out.ids = { uniprot:r.uniprot_id, ensembl:r.ensembl_id, omim:r.omim_id, mgi:r.mgi_id };
        out.synonyms = asArr(r.synonyms);
        return { value: out, note: 'attributes of '+(symOf(L,a.gene)) }; } },
    // set operations over saved gene lists
    intersect: { desc: "genes common to all input sets. args:{sets:[$A,$B,...]}",
      run: function(L,a,WS){ var lists = resolveSets(a.sets, WS); if (!lists.length) return {genes:[]};
        var keyed = lists.map(function(l){ return new Set(l.map(norm)); });
        var out = lists[0].filter(function(g){ var n = norm(g); return keyed.every(function(s){ return s.has(n); }); });
        return { genes: uniq(out), note: 'intersection of '+lists.length+' sets' }; } },
    union: { desc: "genes in any input set. args:{sets:[$A,$B,...]}",
      run: function(L,a,WS){ var lists = resolveSets(a.sets, WS); return { genes: uniq([].concat.apply([], lists)), note: 'union' }; } },
    difference: { desc: "genes in the first set but NOT the second. args:{sets:[$A,$B]}",
      run: function(L,a,WS){ var lists = resolveSets(a.sets, WS); if (lists.length < 2) return {genes: lists[0]||[]};
        var rm = new Set(lists[1].map(norm)); return { genes: lists[0].filter(function(g){ return !rm.has(norm(g)); }), note: 'A minus B' }; } },
    count: { desc: "number of genes in a set. args:{set:$A}",
      run: function(L,a,WS){ var l = resolveSets([a.set], WS)[0] || []; return { value: l.length, genes: l, note: 'count' }; } }
  };

  function resolveSets(refs, WS){
    return asArr(refs).map(function(ref){
      if (Array.isArray(ref)) return ref;
      var name = String(ref).replace(/^\$/, '');
      var slot = WS[name];
      return slot && slot.genes ? slot.genes : (Array.isArray(slot) ? slot : []);
    });
  }

  // ── planner prompt ───────────────────────────────────────────────────────────
  function toolSpec(){
    return Object.keys(TOOLS).map(function(k){ return '- ' + k + ': ' + TOOLS[k].desc; }).join('\n');
  }
  function plannerPrompt(query, transcript){
    return [
      "You are the PLANNER for CiliAI, a curated ciliary-gene database assistant.",
      "Answer the user ONLY by calling the tools below and composing their results. You must",
      "NOT use any biological knowledge of your own — every gene, number, and fact must come",
      "from a tool result. Reference saved results by $NAME in later args.",
      "",
      "TOOLS:",
      toolSpec(),
      "",
      "Respond with EXACTLY ONE JSON object per turn, no prose:",
      '  to call a tool:  {"call":{"tool":"<name>","args":{...}},"as":"<VAR>"}',
      '  to finish:       {"final":{"summary":"<one sentence>","result":"$VAR or value","cite":true|false}}',
      "Use cite:true when the answer is a gene list worth literature support.",
      "Plan the minimum steps. For 'X with Y but not Z' use intersect then difference.",
      "",
      "USER QUESTION: " + query,
      "",
      "CONVERSATION SO FAR (tool results):",
      transcript || "(none yet)"
    ].join('\n');
  }

  // ── the loop ──────────────────────────────────────────────────────────────────
  function getLookups(){ return (root.CiliAI && root.CiliAI.lookups) || {}; }

  async function reason(query, llmCall, opts){
    opts = opts || {};
    var L = opts.lookups || getLookups();
    var maxSteps = opts.maxSteps || 6;
    var WS = {};                 // workspace: VAR -> tool result
    var transcript = '';
    var lastFinal = null;

    for (var step = 0; step < maxSteps; step++){
      var raw = await llmCall(plannerPrompt(query, transcript));
      var msg;
      try { msg = JSON.parse(stripFences(raw)); }
      catch (e){ return { ok:false, error:'planner returned non-JSON', raw:raw }; }

      if (msg.final){
        lastFinal = msg.final; break;
      }
      if (!msg.call || !TOOLS[msg.call.tool]){
        transcript += "\n[error] unknown or missing tool: " + JSON.stringify(msg).slice(0,160);
        continue;
      }
      var t = TOOLS[msg.call.tool];
      var res;
      try { res = t.run(L, msg.call.args || {}, WS); }
      catch (e){ res = { error: String(e) }; }
      var varName = msg.as || ('R' + step);
      WS[varName] = res;
      var summary = res.genes ? (res.genes.length + ' genes' + (res.genes.length <= 12 ? ': ' + res.genes.join(', ') : ' (e.g. ' + res.genes.slice(0,12).join(', ') + ' …)'))
                  : ('value=' + JSON.stringify(res.value));
      transcript += "\n$" + varName + " = " + msg.call.tool + "(" + JSON.stringify(msg.call.args||{}) + ") -> " + summary + (res.note ? "  // " + res.note : "");
    }

    if (!lastFinal) return { ok:false, error:'no final answer within step budget', workspace:WS };
    return composeAnswer(L, lastFinal, WS, opts);
  }

  function composeAnswer(L, final, WS, opts){
    var out = { ok:true, summary: final.summary || '', genes: [], value: undefined, citations: [] };
    var ref = final.result;
    if (typeof ref === 'string' && ref.charAt(0) === '$'){
      var slot = WS[ref.replace(/^\$/, '')];
      if (slot && slot.genes) out.genes = slot.genes;
      else if (slot && slot.value !== undefined) out.value = slot.value;
    } else if (typeof ref === 'number'){ out.value = ref; }

    if (final.cite && out.genes.length && (opts.literature || (root.CiliAI && root.CiliAI.literature))){
      var lit = opts.literature || root.CiliAI.literature;   // {genes:{SYM:{evidence:[{pmid,year,...}]}}}
      out.genes.slice(0, 25).forEach(function(g){
        var e = lit.genes && (lit.genes[g] || lit.genes[g && g.toUpperCase()]);
        if (e && e.evidence && e.evidence.length){
          var top = e.evidence.slice().sort(function(a,b){ return (b.year||0)-(a.year||0); })[0];
          out.citations.push({ gene:g, pmid: top.pmid, year: top.year, sentence: top.sentence });
        }
      });
    }
    return out;
  }

  function stripFences(s){ return String(s||'').replace(/```json|```/g, '').trim(); }

  root.CiliAIReason = { reason: reason, TOOLS: TOOLS, _internals: {
    resolveDiseaseKey: resolveDiseaseKey, resolveClassKey: resolveClassKey, composeAnswer: composeAnswer } };

})(typeof window !== 'undefined' ? window : globalThis);
