/* ciliai-reason-bridge.js — wire the reasoning engine (ciliai-reason.js) into the live
 * CiliAI dispatcher as a smart last-resort (STEP 4.5), sitting between the data-first path
 * (STEP 4) and the bare-LLM router (STEP 5).
 *
 * REGRESSION-SAFE BY DESIGN: if no LLM planner is reachable, or the reasoner cannot produce
 * a data-grounded answer, tryAnswer() returns null and the dispatcher falls through to the
 * existing STEP 5 / STEP 6 exactly as before. Nothing it adds can break current behaviour.
 *
 * Load order (in ciliai.html): AFTER assistant-runtime.js, ciliai.js, AND ciliai-reason.js.
 *
 * The planner LLM call is auto-detected from the site's existing assistant/provider path.
 * If auto-detect misses, run  window.CiliAIReason.llmProbe()  in the page console and wire
 * the exact method in one line:  window.CiliAIReason.setLlm(p => YOUR_RAW_CALL(p));
 */
(function (root) {
  'use strict';
  var R = root.CiliAIReason;
  if (!R || typeof R.reason !== 'function') {
    console.warn('[reason-bridge] window.CiliAIReason not found — load ciliai-reason.js first. Skipping.');
    return;
  }

  // ── provider reply → plain text (string | {content|text|response|markdown} | OpenAI/DeepSeek shape) ──
  function coerceText(x){
    if (x == null) return '';
    if (typeof x === 'string') return x;
    if (typeof x === 'object'){
      if (typeof x.text === 'string') return x.text;
      if (typeof x.content === 'string') return x.content;
      if (typeof x.response === 'string') return x.response;
      if (typeof x.markdown === 'string') return x.markdown;
      if (x.message && typeof x.message.content === 'string') return x.message.content;
      if (x.choices && x.choices[0]){ var c = x.choices[0]; return (c.message && c.message.content) || c.text || ''; }
      if (typeof x.data === 'string') return x.data;
    }
    return String(x);
  }

  // unwrap the assistant [MARKDOWN]/[ACTIONS_JSON] contract back to raw text (last-resort path)
  function unwrapContract(s){
    s = String(s || '');
    var m = s.match(/\[MARKDOWN\]([\s\S]*?)(\[ACTIONS_JSON\]|$)/);
    return m ? m[1].trim() : s;
  }

  // ── raw planner call: explicit override → assistant methods → provider objects → ask() unwrap ──
  var _override = null;
  R.setLlm = function (fn){ _override = (typeof fn === 'function') ? fn : null; return R; };

  async function rawLlm(prompt){
    if (_override) return coerceText(await _override(prompt));
    var A = root.CiliAIAssistant;
    var METHODS = ['complete','rawComplete','completeRaw','generate','generateText',
                   'rawAsk','askRaw','llm','raw','_complete','chat','completion'];
    if (A){
      for (var i = 0; i < METHODS.length; i++){
        if (typeof A[METHODS[i]] === 'function'){
          try { var r = await A[METHODS[i]](prompt); if (r != null) return coerceText(r); } catch (e) {}
        }
      }
      var provs = [A.provider, A._provider, A.activeProvider, A.llmProvider];
      for (var p = 0; p < provs.length; p++){
        var P = provs[p]; if (!P) continue;
        var pm = ['complete','generate','chat','ask','raw'];
        for (var k = 0; k < pm.length; k++){
          if (typeof P[pm[k]] === 'function'){
            try { var rp = await P[pm[k]](prompt); if (rp != null) return coerceText(rp); } catch (e) {}
          }
        }
      }
    }
    var GLOBALS = [root.CiliAIProvider, root.CiliAIProviders, root.CiliAIOllama,
                   root.CiliAIDeepSeek, root.OllamaProvider, root.DeepSeekProvider];
    for (var g = 0; g < GLOBALS.length; g++){
      var G = GLOBALS[g]; if (!G) continue;
      var gm = ['complete','generate','chat','ask','raw'];
      for (var n = 0; n < gm.length; n++){
        if (typeof G[gm[n]] === 'function'){
          try { var rg = await G[gm[n]](prompt); if (rg != null) return coerceText(rg); } catch (e) {}
        }
      }
    }
    if (A && typeof A.ask === 'function'){            // last resort: structured ask(), unwrap contract
      try { return unwrapContract(coerceText(await A.ask(prompt))); } catch (e) {}
    }
    return null;                                       // nothing reachable → reasoner fails gracefully
  }

  // diagnostic: paste  window.CiliAIReason.llmProbe()  in the live console to reveal the LLM path
  R.llmProbe = function (){
    var A = root.CiliAIAssistant || {};
    var out = {
      assistantFns: Object.keys(A).filter(function (k){ return typeof A[k] === 'function'; }),
      hasAsk: typeof A.ask === 'function',
      providerGlobals: ['CiliAIProvider','CiliAIProviders','CiliAIOllama','CiliAIDeepSeek','OllamaProvider','DeepSeekProvider']
        .filter(function (n){ return !!root[n]; }),
      overrideSet: !!_override
    };
    console.log('[reason-bridge probe]\n' + JSON.stringify(out, null, 2));
    return out;
  };

  // throw on empty so reason() short-circuits and tryAnswer() can fall through
  function makeLlmCall(){
    return async function (prompt){
      var t = await rawLlm(prompt);
      if (t == null || !String(t).trim()) throw new Error('reason-bridge: no LLM planner reachable');
      return t;
    };
  }

  // ── rendering (mirrors the .ai-result-card look used elsewhere in CiliAI) ──
  function esc(s){
    return String(s == null ? '' : s)
      .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }
  function geneChip(sym){
    var s = esc(sym);
    return '<a href="#" class="ai-gene-chip" onclick="if(window.searchGene){window.searchGene(\'' + s +
           '\');}return false;">' + s + '</a>';
  }
  function renderAnswer(res){
    var out = ['<div class="ai-result-card ciliai-reasoned">'];
    if (res.summary) out.push('<p>' + esc(res.summary) + '</p>');
    if ((res.value !== undefined && res.value !== null) && (!res.genes || !res.genes.length)){
      out.push('<p><strong>' + esc(String(res.value)) + '</strong></p>');
    }
    if (res.genes && res.genes.length){
      out.push('<p><strong>' + res.genes.length + ' gene' + (res.genes.length === 1 ? '' : 's') + ':</strong></p>');
      out.push('<div class="ai-gene-chips">' + res.genes.map(geneChip).join(' ') + '</div>');
    }
    if (res.citations && res.citations.length){
      out.push('<details class="ai-citations"><summary>Evidence (' + res.citations.length + ' PMID-cited)</summary><ul>');
      res.citations.forEach(function (c){
        var pm = c.pmid
          ? '<a href="https://pubmed.ncbi.nlm.nih.gov/' + esc(c.pmid) + '/" target="_blank" rel="noopener">PMID ' + esc(c.pmid) + '</a>'
          : '';
        out.push('<li><strong>' + esc(c.gene) + '</strong> ' + pm + (c.year ? (' (' + esc(c.year) + ')') : '') +
                 (c.sentence ? (' — ' + esc(c.sentence)) : '') + '</li>');
      });
      out.push('</ul></details>');
    }
    out.push('<p class="ai-provenance" style="font-size:11px;color:#9ca3af;margin-top:8px;">' +
             'Composed from curated CiliaHub data by the reasoning engine — genes, counts, and citations are ' +
             'data-derived; the model only sequenced the lookups.</p>');
    out.push('</div>');
    return out.join('');
  }

  // ── public entry: returns HTML on a grounded answer, else null (dispatcher falls through) ──
  R.tryAnswer = async function (query){
    if (!query || !String(query).trim()) return null;

    // wire literature sidecar for citations: reasoner expects {genes:{SYM:{evidence:[...]}}}
    try {
      if (!(root.CiliAI && root.CiliAI.literature) && typeof root.ensureLitEvidence === 'function'){
        var gmap = await root.ensureLitEvidence();
        root.CiliAI = root.CiliAI || {};
        root.CiliAI.literature = { genes: gmap || {} };
      }
    } catch (e) {}

    var lookups = (root.CiliAI && root.CiliAI.lookups) || null;
    if (!lookups || !lookups.geneMap || !Object.keys(lookups.geneMap).length) return null; // data not ready

    var res;
    try {
      res = await R.reason(query, makeLlmCall(), {
        lookups: lookups,
        literature: (root.CiliAI && root.CiliAI.literature) || null,
        maxSteps: 5
      });
    } catch (e) { return null; }                        // no-llm / planner failure → fall through

    if (!res || !res.ok) return null;
    var hasContent = (res.genes && res.genes.length) || (res.value !== undefined && res.value !== null);
    if (!hasContent) return null;                       // empty grounded result → let STEP 5/6 handle
    return renderAnswer(res);
  };

  console.log('[reason-bridge] ready. tryAnswer(q) wired; if compositional Qs do not answer, run CiliAIReason.llmProbe()');
})(typeof window !== 'undefined' ? window : globalThis);
