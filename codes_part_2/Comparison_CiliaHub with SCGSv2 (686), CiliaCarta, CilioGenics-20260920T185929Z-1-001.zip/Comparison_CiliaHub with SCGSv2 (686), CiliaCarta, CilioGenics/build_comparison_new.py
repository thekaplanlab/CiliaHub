#!/usr/bin/env python3
"""Comprehensive cross-resource gene table:
Gene | Ensembl | CiliaHub tier | CiliaCarta | CilioGenics score/rank | SCGSv2
"""
import json, csv, re, subprocess, collections
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from openpyxl.utils import get_column_letter

MASTER = "/mnt/user-data/uploads/ciliahub_master_merged_v8_9_2026-08-26.json"
CC = "/mnt/user-data/uploads/CiliaCarta.csv"
CG = "/mnt/user-data/uploads/ciliogenics.csv"
PDF = "/mnt/user-data/uploads/Supplemental_Table_S1_SCGSv2_.pdf"
OUT = "/mnt/user-data/outputs/CiliaHub_cross_resource_comparison.xlsx"

m = json.load(open(MASTER))
G = m["genes"]
VERSION = m["meta"]["version"]
GOLD = "Gold Standard Ciliary Genes"

# ---- resolution maps ------------------------------------------------------
sym2canon, ens2canon = {}, {}
for s, r in G.items():
    sym2canon[s.upper()] = s
    for a in (r.get("synonyms") or []):
        a = str(a).strip().upper()
        if a and a not in sym2canon:
            sym2canon[a] = s
    # ensembl_id may hold several comma-separated IDs
    for e in re.split(r"[,;\s]+", str(r.get("ensembl_id") or "")):
        e = e.strip()
        if e.startswith("ENSG"):
            ens2canon.setdefault(e, s)

# ---- SCGSv2: 686 Ensembl IDs, extracted from the supplementary PDF --------
txt = subprocess.run(["pdftotext", "-layout", PDF, "-"], capture_output=True, text=True).stdout
scgsv2_ens = sorted(set(re.findall(r"\bENSG\d{11}\b", txt)))
# symbol for each, taken from the line where the ID is line-anchored
ens2sym = {}
for line in txt.split("\n"):
    mm = re.match(r"^(ENSG\d{11})\s+(.*)$", line)
    if mm:
        tok = re.findall(r"\b([A-Z][A-Z0-9\-]{1,14})\b", line[35:100])
        if tok:
            ens2sym.setdefault(mm.group(1), tok[0])

# ---- CiliaCarta -----------------------------------------------------------
KEY = "Inclusion criterionAllGold StandardPredictedGene Ontology"
cc_by_ens, cc_by_sym, cc_by_ens_sym = {}, {}, {}
for r in csv.DictReader(open(CC)):
    g = (r.get("Associated Gene Name") or "").strip()
    e = (r.get("Ensembl Gene ID") or "").strip()
    rec = {"rank": (r.get("CiliaCarta Rank") or "").strip(),
           "score": (r.get("CiliaCarta Score") or "").strip(),
           "crit": (r.get(KEY) or "").strip()}
    if e:
        cc_by_ens.setdefault(e, rec)
        if g:
            cc_by_ens_sym.setdefault(e, g)
    if g:
        cc_by_sym.setdefault(g.upper(), rec)

# ---- CilioGenics ----------------------------------------------------------
cg_by_sym = {}
for r in csv.DictReader(open(CG)):
    g = (r.get("Gene_name") or "").strip().upper()
    if not g:
        continue
    try:
        sc = float(r.get("Mean_score") or 0)
        od = int(float(r.get("Order") or 0))
    except ValueError:
        continue
    if g not in cg_by_sym or od < cg_by_sym[g]["order"]:
        cg_by_sym[g] = {"score": sc, "order": od}

# ---- assemble the union of all four resources -----------------------------
rows = {}


def touch(key):
    return rows.setdefault(key, {
        "gene": key, "ensembl": "", "hub": "", "hub_pan": "", "hub_dis": "",
        "cc": "", "cc_rank": "", "cc_crit": "",
        "cg_score": "", "cg_rank": "", "scgsv2": "",
    })


for s, r in G.items():
    d = touch(s)
    d["ensembl"] = str(r.get("ensembl_id") or "").strip()
    d["hub"] = "Gold standard" if r.get("evidence_tier") == GOLD else "Cilia-associated"
    d["hub_pan"] = (r.get("pan_idio_class") or "").replace("_", " ")
    cil = r.get("ciliopathies")
    cil = cil if isinstance(cil, list) else ([cil] if cil else [])
    d["hub_dis"] = "; ".join(cil)

for e in scgsv2_ens:
    canon = ens2canon.get(e)
    if not canon:                       # try the symbol CiliaCarta gives for this ID
        alt = cc_by_ens_sym.get(e)
        if alt:
            canon = sym2canon.get(alt.upper())
    key = canon or cc_by_ens_sym.get(e) or ens2sym.get(e) or e
    d = touch(key)
    d["scgsv2"] = "Yes"
    if not d["ensembl"]:
        d["ensembl"] = e

for e, rec in cc_by_ens.items():
    canon = ens2canon.get(e)
    key = canon
    if not key:
        sym = [g for g, v in cc_by_sym.items() if v is rec]
        key = sym2canon.get(sym[0]) if sym and sym[0] in sym2canon else (sym[0] if sym else e)
    d = touch(key)
    d["cc"], d["cc_rank"], d["cc_crit"] = "Yes", rec["rank"], rec["crit"]
    if not d["ensembl"]:
        d["ensembl"] = e

for key, d in rows.items():
    hit = cg_by_sym.get(key.upper())
    if not hit:
        for a in (G.get(key, {}).get("synonyms") or []):
            hit = cg_by_sym.get(str(a).strip().upper())
            if hit:
                break
    if hit:
        d["cg_score"] = round(hit["score"], 4)
        d["cg_rank"] = hit["order"]

data = sorted(rows.values(), key=lambda d: d["gene"])

# ---- workbook -------------------------------------------------------------
HDR_FILL = PatternFill("solid", fgColor="1F3864")
HDR_FONT = Font(name="Arial", size=10, bold=True, color="FFFFFF")
BODY = Font(name="Arial", size=10)
THIN = Side(style="thin", color="BFBFBF")
BOX = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
GOLDF = PatternFill("solid", fgColor="FFF2CC")
ASSOCF = PatternFill("solid", fgColor="E2EFDA")

wb = Workbook()

ws = wb.active
ws.title = "Comparison"
headers = ["Gene", "Ensembl ID", "CiliaHub", "Pan/idio class", "CiliaHub ciliopathies",
           "CiliaCarta", "CiliaCarta rank", "CiliaCarta criterion",
           "CilioGenics score", "CilioGenics rank", "SCGSv2"]
widths = [14, 19, 17, 15, 46, 12, 15, 24, 17, 16, 10]
for i, h in enumerate(headers, 1):
    c = ws.cell(1, i, h)
    c.font, c.fill, c.border = HDR_FONT, HDR_FILL, BOX
    c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
for j, d in enumerate(data, 2):
    vals = [d["gene"], d["ensembl"], d["hub"], d["hub_pan"], d["hub_dis"],
            d["cc"], d["cc_rank"], d["cc_crit"], d["cg_score"], d["cg_rank"], d["scgsv2"]]
    for i, v in enumerate(vals, 1):
        c = ws.cell(j, i, v)
        c.font, c.border = BODY, BOX
        c.alignment = Alignment(vertical="top", wrap_text=(i == 5))
    if d["hub"] == "Gold standard":
        ws.cell(j, 3).fill = GOLDF
    elif d["hub"] == "Cilia-associated":
        ws.cell(j, 3).fill = ASSOCF
for i, w in enumerate(widths, 1):
    ws.column_dimensions[get_column_letter(i)].width = w
ws.freeze_panes = "A2"
ws.auto_filter.ref = "A1:%s%d" % (get_column_letter(len(headers)), len(data) + 1)
ws.row_dimensions[1].height = 32

# ---- summary sheet --------------------------------------------------------
s2 = wb.create_sheet("Summary", 0)
s2.cell(1, 1, "Cross-resource comparison of ciliary gene catalogues").font = Font(
    name="Arial", size=14, bold=True)
inhub = [d for d in data if d["hub"]]
gold = [d for d in inhub if d["hub"] == "Gold standard"]
assoc = [d for d in inhub if d["hub"] == "Cilia-associated"]
sc = [d for d in data if d["scgsv2"] == "Yes"]
cc = [d for d in data if d["cc"] == "Yes"]
lines = [
    ("Source", "CiliaHub %s; CiliaCarta; CilioGenics; SYSCILIA Gold Standard v2" % VERSION),
    ("Rows in table", len(data)),
    ("", ""),
    ("CiliaHub genes", len(inhub)),
    ("  Gold standard", len(gold)),
    ("  Cilia-associated", len(assoc)),
    ("CiliaCarta genes", len(cc)),
    ("SCGSv2 genes", len(sc)),
    ("", ""),
    ("SCGSv2 present in CiliaHub", sum(1 for d in sc if d["hub"])),
    ("SCGSv2 absent from CiliaHub", sum(1 for d in sc if not d["hub"])),
    ("CiliaCarta present in CiliaHub", sum(1 for d in cc if d["hub"])),
    ("CiliaCarta absent from CiliaHub", sum(1 for d in cc if not d["hub"])),
    ("", ""),
    ("In all three (CiliaHub, CiliaCarta, SCGSv2)",
     sum(1 for d in data if d["hub"] and d["cc"] == "Yes" and d["scgsv2"] == "Yes")),
    ("CiliaHub only", sum(1 for d in data if d["hub"] and not d["cc"] and not d["scgsv2"])),
    ("", ""),
    ("Note", "SCGSv2 membership was resolved by Ensembl gene ID extracted from the "
             "published supplementary table, which yields exactly 686 identifiers."),
    ("Note", "CilioGenics ranks the whole genome; a score is present for most genes and "
             "is not a membership call."),
]
for i, (k, v) in enumerate(lines, 3):
    a = s2.cell(i, 1, k); a.font = Font(name="Arial", size=10, bold=not k.startswith(" ") and k != "Note")
    b = s2.cell(i, 2, v); b.font = Font(name="Arial", size=10)
    b.alignment = Alignment(wrap_text=True, vertical="top")
s2.column_dimensions["A"].width = 42
s2.column_dimensions["B"].width = 78

wb.save(OUT)
print("wrote", OUT)
print("rows: %d | CiliaHub %d (gold %d, assoc %d) | CiliaCarta %d | SCGSv2 %d"
      % (len(data), len(inhub), len(gold), len(assoc), len(cc), len(sc)))
print("SCGSv2 in CiliaHub: %d ; absent: %d" % (sum(1 for d in sc if d["hub"]),
                                               sum(1 for d in sc if not d["hub"])))
print("with a CilioGenics score: %d" % sum(1 for d in data if d["cg_score"] != ""))
