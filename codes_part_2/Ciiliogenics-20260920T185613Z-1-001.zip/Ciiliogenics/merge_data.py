#!/usr/bin/env python3
import json
import os

def merge_cilia_files():
    # Detect the current directory where the script is running
    base_path = os.getcwd()
    
    master_path = os.path.join(base_path, "ciliahub_master.json")
    evidence_path = os.path.join(base_path, "ciliogenics_evidence.json")
    phenotype_path = os.path.join(base_path, "cross_species_phenotypes_v2.json")
    pubs_path = os.path.join(base_path, "publications.txt")
    output_path = os.path.join(base_path, "ciliahub_master_merged.json")

    # Check if files exist before proceeding
    required_files = [master_path, evidence_path, phenotype_path, pubs_path]
    for f_path in required_files:
        if not os.path.exists(f_path):
            print(f"Error: Could not find {os.path.basename(f_path)} in {base_path}")
            return

    print("--- Starting Data Merge ---")
    print(f"Working Directory: {base_path}")

    # 1. Load Master JSON
    print("Loading Master Database...")
    with open(master_path, 'r') as f:
        master_data = json.load(f)
    
    # 2. Load Ciliogenics Evidence (Structure: data['genes'][symbol])
    print("Loading Ciliogenics Evidence...")
    with open(evidence_path, 'r') as f:
        evidence_json = json.load(f)
        evidence_genes = evidence_json.get("genes", {})

    # 3. Load Cross Species Phenotypes (Structure: data['genes'][symbol])
    print("Loading Cross-Species Phenotypes...")
    with open(phenotype_path, 'r') as f:
        phenotype_json = json.load(f)
        phenotype_genes = phenotype_json.get("genes", {})

    # 4. Load and parse Publications (Pipe-delimited)
    print("Parsing Publications...")
    publications_map = {}
    with open(pubs_path, 'r') as f:
        header = next(f) # Skip header: Gene_name|Publication|Pub_number
        for line in f:
            parts = line.strip().split('|')
            if len(parts) >= 2:
                gene_name = parts[0].upper() # Normalize to uppercase
                pub_info = {
                    "source": parts[1],
                    "id": parts[2] if len(parts) > 2 else "NA"
                }
                if gene_name not in publications_map:
                    publications_map[gene_name] = []
                publications_map[gene_name].append(pub_info)

    # 5. Perform the Merge
    print("Merging attributes...")
    master_genes = master_data.get("genes", {})
    
    for symbol, gene_obj in master_genes.items():
        symbol_upper = symbol.upper()

        # Merge Ciliogenics Evidence
        if symbol_upper in evidence_genes:
            # We add the score and tiers to the gene object
            evidence = evidence_genes[symbol_upper]
            gene_obj["ciliogenics"] = {
                "rank": evidence.get("ciliogenics_rank"),
                "score": evidence.get("mean_score"),
                "tier": evidence.get("confidence_tier"),
                "scores": evidence.get("scores", {})
            }
        else:
            gene_obj["ciliogenics"] = None

        # Merge Phenotypes
        if symbol_upper in phenotype_genes:
            gene_obj["model_organism_phenotypes"] = phenotype_genes[symbol_upper].get("species_phenotypes", [])
        else:
            gene_obj["model_organism_phenotypes"] = []

        # Merge Publications
        if symbol_upper in publications_map:
            # We combine the existing publications (if any) with the new ones
            existing_pubs = gene_obj.get("publications", [])
            if not isinstance(existing_pubs, list): existing_pubs = []
            gene_obj["publications"] = existing_pubs + publications_map[symbol_upper]
        elif "publications" not in gene_obj:
            gene_obj["publications"] = []

    # 6. Update Metadata
    master_data["meta"]["updated_at"] = "2026-04-25"
    master_data["meta"]["data_sources_merged"] = [
        "CilioGenics Evidence v1",
        "Cross-Species Phenotypes v2",
        "Curated Publication List"
    ]

    # 7. Save the Final Output
    print(f"Saving merged file to {output_path}...")
    with open(output_path, 'w') as f:
        json.dump(master_data, f, indent=4)

    print("--- Merge Successfully Completed! ---")

if __name__ == "__main__":
    merge_cilia_files()
