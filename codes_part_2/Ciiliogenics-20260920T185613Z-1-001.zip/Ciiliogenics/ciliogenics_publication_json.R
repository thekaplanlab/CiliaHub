# ============================================================
# generate_ciliogenics_evidence.R
# Reads ciliogenics.csv + publications.txt + ciliAI_master_database.json
# Fetches ENSEMBL IDs via biomaRt for all genes
# Output: data/ciliogenics_evidence.json
# ============================================================

library(jsonlite)
library(biomaRt)

# ── PATHS ─────────────────────────────────────────────────────
scores_path <- "/Users/sebihacevik/Desktop/Manuscripts/CiliAI_workin/STRING_Clinvar/Ciiliogenics/ciliogenics.csv"
pubs_path   <- "/Users/sebihacevik/Desktop/Manuscripts/CiliAI_workin/STRING_Clinvar/Ciiliogenics/publications.txt"
db_path     <- "/Users/sebihacevik/Desktop/Manuscripts/CiliAI_workin/STRING_Clinvar/ciliAI_master_database.json"
out_path    <- "/Users/sebihacevik/Desktop/Manuscripts/CiliAI_workin/STRING_Clinvar/data/ciliogenics_evidence.json"

cat("\n[1/6] Loading files...\n")

# ── LOAD SCORES ───────────────────────────────────────────────
scores <- read.csv(scores_path, stringsAsFactors = FALSE)
scores$Gene_name <- toupper(trimws(scores$Gene_name))
cat("      CilioGenics scores:", nrow(scores), "genes\n")

# ── LOAD PUBLICATIONS ─────────────────────────────────────────
pubs <- read.table(pubs_path, sep = "|", header = TRUE,
                   stringsAsFactors = FALSE, quote = "")
pubs$Gene_name   <- toupper(trimws(pubs$Gene_name))
pubs$Publication <- trimws(pubs$Publication)
pubs <- pubs[pubs$Gene_name != "NA" & nchar(pubs$Gene_name) > 0, ]
cat("      Publications:", nrow(pubs), "gene-paper pairs\n")
cat("      Unique papers:", length(unique(pubs$Publication)), "\n")
cat("      Unique genes in pubs:", length(unique(pubs$Gene_name)), "\n")

# ── LOAD MASTER DATABASE ──────────────────────────────────────
raw  <- fromJSON(db_path, simplifyVector = FALSE)
master_list <- if (!is.null(raw$masterData)) raw$masterData else raw

# Extract gene symbol + ENSEMBL ID from master DB
master_df <- do.call(rbind, lapply(master_list, function(g) {
  sym <- toupper(trimws(
    if (!is.null(g$Gene))   g$Gene
    else if (!is.null(g$name)) g$name
    else ""
  ))
  ens <- if (!is.null(g[["Ensembl ID"]])) trimws(g[["Ensembl ID"]])
  else if (!is.null(g$ensembl_id)) trimws(g$ensembl_id)
  else NA_character_
  data.frame(gene = sym, ensembl_id = ens, stringsAsFactors = FALSE)
}))
master_df <- master_df[nchar(master_df$gene) > 0, ]
master_df <- master_df[!duplicated(master_df$gene), ]
cat("      Master DB genes:", nrow(master_df), "\n")

# ── ALL UNIQUE GENES ──────────────────────────────────────────
all_genes <- sort(unique(c(
  scores$Gene_name,
  pubs$Gene_name,
  master_df$gene
)))
all_genes <- all_genes[nchar(all_genes) > 0]
cat("      Total unique genes:", length(all_genes), "\n")

# ── 2. FETCH ENSEMBL IDs VIA BIOMART ─────────────────────────
cat("\n[2/6] Fetching ENSEMBL IDs via biomaRt...\n")

# Genes already have ENSEMBL IDs from master DB
known_ens <- master_df[!is.na(master_df$ensembl_id) &
                         nchar(master_df$ensembl_id) > 3, ]
cat("      ENSEMBL IDs from master DB:", nrow(known_ens), "\n")

# Genes still needing lookup
need_lookup <- setdiff(all_genes, known_ens$gene)
cat("      Genes needing biomaRt lookup:", length(need_lookup), "\n")

ensembl_map <- setNames(known_ens$ensembl_id, known_ens$gene)

if (length(need_lookup) > 0) {
  tryCatch({
    mart <- useEnsembl(biomart = "genes", dataset = "hsapiens_gene_ensembl")
    bm <- getBM(
      attributes = c("hgnc_symbol", "ensembl_gene_id"),
      filters    = "hgnc_symbol",
      values     = need_lookup,
      mart       = mart
    )
    bm <- bm[!duplicated(bm$hgnc_symbol) & nchar(bm$ensembl_gene_id) > 0, ]
    new_ids <- setNames(bm$ensembl_gene_id, toupper(bm$hgnc_symbol))
    ensembl_map <- c(ensembl_map, new_ids)
    cat("      biomaRt resolved:", length(new_ids), "additional ENSEMBL IDs\n")
  }, error = function(e) {
    cat("      biomaRt unavailable:", e$message, "\n")
    cat("      Proceeding without additional ENSEMBL IDs\n")
  })
}

cat("      Total genes with ENSEMBL IDs:", length(ensembl_map), "\n")

# ── 3. PUBLICATION CATEGORY LOOKUP ───────────────────────────
cat("\n[3/6] Classifying publications...\n")

# Auto-classify each paper by keywords in its name
classify_pub <- function(pub_name) {
  n <- tolower(pub_name)
  if (grepl("syscilia|gold standard|go cc|bayesian|cilia carta|ciliaCarta", n))
    return("Gold Standard / Integrated")
  if (grepl("screen|sirna|crispr|rnai|functional genom|modulat", n))
    return("Functional Screen")
  if (grepl("transcri|rna-seq|microarray|expression|mrna|sage|xbx|daf-19|rfx|motif|x-box", n))
    return("Transcriptomics / Motif")
  if (grepl("compar|genomic|phylo|flagell|evolut|ancestor|conserv", n))
    return("Comparative Genomics")
  if (grepl("proteom|mass spec|protein|phospho|proximity|bioid|centrosom|cilia.*mem|axoneme|sperm|photoreceptor|olfact", n))
    return("Proteomics")
  return("Other")
}

# Build pub metadata table from the publications file itself
pub_meta <- data.frame(
  publication = unique(pubs$Publication),
  stringsAsFactors = FALSE
)
pub_meta$category   <- sapply(pub_meta$publication, classify_pub)
pub_meta$pub_number <- sapply(pub_meta$publication, function(p) {
  rows <- pubs[pubs$Publication == p, ]
  if (nrow(rows) > 0) as.integer(rows$Pub_number[1]) else NA_integer_
})

cat("      Publications classified:\n")
print(table(pub_meta$category))

# ── 4. CONFIDENCE TIER ────────────────────────────────────────
get_tier <- function(s) {
  if (is.na(s) || s == 0) return("Not scored")
  if (s >= 4.0)            return("Gold")
  if (s >= 3.0)            return("Silver")
  if (s >= 2.0)            return("Bronze")
  if (s >= 1.0)            return("Candidate")
  return("Low")
}

# ── 5. BUILD PER-GENE RECORDS ─────────────────────────────────
cat("\n[4/6] Building per-gene records...\n")

gene_records <- lapply(all_genes, function(g) {
  
  # Scores
  sc      <- scores[scores$Gene_name == g, ]
  has_sc  <- nrow(sc) > 0
  ms      <- if (has_sc) sc$Mean_score[1]        else NA_real_
  rnk     <- if (has_sc) as.integer(sc$Order[1]) else NA_integer_
  
  score_block <- if (has_sc) list(
    protein_interaction = round(sc$Protein_interaction_score[1], 4),
    phylogenetic        = round(sc$Phylogenetic_tree_score[1],   4),
    motif               = round(sc$Motif_score[1],               4),
    protein_atlas       = round(sc$Protein_atlas_score[1],       4),
    single_cell         = round(sc$Single_cell_score[1],         4),
    publication         = round(sc$Publication_score[1],         4),
    mean                = round(ms,                               4)
  ) else NULL
  
  # Publications for this gene
  g_pubs <- pubs[pubs$Gene_name == g, ]
  n_pubs <- nrow(g_pubs)
  
  pub_list <- if (n_pubs > 0) {
    lapply(seq_len(nrow(g_pubs)), function(i) {
      pn   <- g_pubs$Publication[i]
      meta <- pub_meta[pub_meta$publication == pn, ]
      list(
        publication = pn,
        pub_number  = as.integer(g_pubs$Pub_number[i]),
        category    = if (nrow(meta) > 0) meta$category[1] else "Other"
      )
    })
  } else list()
  
  # Category summary
  cats <- if (n_pubs > 0) {
    as.list(table(sapply(pub_list, function(p) p$category)))
  } else list()
  
  # ENSEMBL ID — safe lookup from named vector
  ens <- ensembl_map[g]
  ens <- if (!is.null(ens) && !is.na(ens) && nchar(ens) > 3) ens else NULL
  
  list(
    gene                = g,
    ensembl_id          = ens,
    in_master_database  = g %in% master_df$gene,
    ciliogenics_rank    = rnk,
    mean_score          = if (!is.na(ms)) round(ms, 4) else NULL,
    confidence_tier     = get_tier(ms),
    scores              = score_block,
    n_publications      = n_pubs,
    evidence_categories = names(cats),
    category_counts     = cats,
    publications        = pub_list
  )
})
names(gene_records) <- all_genes
cat("      Records built:", length(gene_records), "\n")

# ── 6. WRAP AND WRITE ─────────────────────────────────────────
cat("\n[5/6] Building output structure...\n")

tier_counts <- table(sapply(gene_records, function(g) g$confidence_tier))
cat_counts  <- table(unlist(lapply(gene_records,
                                   function(g) g$evidence_categories)))

output <- list(
  meta = list(
    title              = "CilioGenics Evidence Database",
    description        = paste0(
      "Per-gene CilioGenics confidence scores combined with publication evidence ",
      "from ", nrow(pub_meta), " ciliary gene datasets across multiple species. ",
      "ENSEMBL IDs included for all genes. Each publication is auto-classified ",
      "by method type. Use to determine if your gene of interest has been ",
      "identified as ciliary and by which experimental approaches."
    ),
    generated          = format(Sys.time(), "%Y-%m-%d %H:%M:%S"),
    n_genes_total      = length(gene_records),
    n_genes_scored     = sum(sapply(gene_records, function(g) !is.null(g$mean_score))),
    n_genes_with_ensembl = length(ensembl_map),
    n_genes_in_master  = sum(sapply(gene_records, function(g) g$in_master_database)),
    n_genes_in_pubs    = sum(sapply(gene_records, function(g) g$n_publications > 0)),
    n_publications     = nrow(pub_meta),
    confidence_tiers   = as.list(tier_counts),
    evidence_categories = as.list(cat_counts),
    score_components   = list(
      protein_interaction = "PPI network proximity to known ciliary genes",
      phylogenetic        = "Conservation across 72 ciliary and non-ciliary organisms",
      motif               = "TF binding targets: FOXJ1, RFX2, RFX3, MYB, GLIS3, JAZF1",
      protein_atlas       = "Text mining from Human Protein Atlas",
      single_cell         = "scRNA-seq co-expression in ciliated cell types",
      publication         = "Appearance in curated ciliary gene publications",
      mean                = "Sum of all six component scores (max ~6.0)"
    ),
    confidence_tier_thresholds = list(
      Gold      = "Mean score >= 4.0",
      Silver    = "Mean score 3.0 to 3.99",
      Bronze    = "Mean score 2.0 to 2.99",
      Candidate = "Mean score 1.0 to 1.99",
      Low       = "Mean score < 1.0"
    )
  ),
  publications = lapply(seq_len(nrow(pub_meta)), function(i) {
    list(
      name       = pub_meta$publication[i],
      pub_number = pub_meta$pub_number[i],
      category   = pub_meta$category[i]
    )
  }),
  genes = gene_records
)

cat("\n[6/6] Writing JSON to:\n     ", out_path, "\n")
dir.create(dirname(out_path), showWarnings = FALSE, recursive = TRUE)
write_json(output, path = out_path, pretty = TRUE,
           auto_unbox = TRUE, null = "null")

# ── SUMMARY ───────────────────────────────────────────────────
cat("\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n")
cat("  Done\n\n")
cat(sprintf("  Total genes:              %d\n", length(gene_records)))
cat(sprintf("  Genes with score:         %d\n",
            sum(sapply(gene_records, function(g) !is.null(g$mean_score)))))
cat(sprintf("  Genes with ENSEMBL ID:    %d\n", length(ensembl_map)))
cat(sprintf("  Genes in master DB:       %d\n",
            sum(sapply(gene_records, function(g) g$in_master_database))))
cat(sprintf("  Publications classified:  %d\n", nrow(pub_meta)))
cat("\n  Confidence tiers:\n")
for (t in names(tier_counts))
  cat(sprintf("    %-15s  %d\n", t, tier_counts[[t]]))
cat("\n  Evidence categories:\n")
for (c in names(sort(cat_counts, decreasing = TRUE)))
  cat(sprintf("    %-30s  %d genes\n", c, cat_counts[[c]]))
cat(sprintf("\n  Output: %s\n", out_path))
cat("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n")

