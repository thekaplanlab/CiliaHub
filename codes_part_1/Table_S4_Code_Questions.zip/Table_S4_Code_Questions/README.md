# CiliAI benchmark (Reviewer 2, Comment 6)

Tests the live CiliAI against ground truth read directly from the CiliaHub release file (v9.2).
No expected answer is hand-written, and CiliAI's own replies are recorded and scored, so the
benchmark cannot pass unless CiliAI returns what the database holds.

## Before running
1. Deploy CiliAI in data-only mode, meaning no language model:
   - in `ciliai/env.js` set `CILIAI_LLM_PROVIDER: ''` and `CILIAI_ASSISTANT_CHAT_MODE: 'data_first'`, and remove the proxy URL;
   - in `ciliai.html` remove the `providers/deepseek.js` and `providers/ollama.js` script tags;
   - disable the Cloudflare Worker.
2. Make sure the live site serves the v9.2 data (the same `ciliahub_master_live_version v9.2_2026-10-03.json` used below).

## Run
```bash
pip install playwright pandas scipy openpyxl
python -m playwright install chromium

python generate_questions.py --ciliahub "ciliahub_master_live_version v9.2_2026-10-03.json" --hgnc CiliaHub_PubMed_Search_Symbols.tsv --out questions.tsv --seed 2026
python run_ciliai_benchmark.py --questions questions.tsv --out responses_run1.tsv
python run_ciliai_benchmark.py --questions questions.tsv --out responses_run2.tsv
python score_ciliai_benchmark.py --ciliahub "ciliahub_master_live_version v9.2_2026-10-03.json" --questions questions.tsv \
        --run1 responses_run1.tsv --run2 responses_run2.tsv --out ciliai_benchmark_scored.xlsx
python build_table_s4.py --scored ciliai_benchmark_scored.xlsx --review manual_review.tsv


## Output (`ciliai_benchmark_scored.xlsx`)
- **Summary**: accuracy with 95% Wilson confidence interval per question type and overall;
  hallucination count; number of answers during which the page contacted a language-model
  endpoint (must be 0); share of answers identical across the two runs (determinism).
- **All answers**: question, expected answer, CiliAI reply, automatic verdict and reason.
- **For manual review**: every answer scored incorrect or flagged as a hallucination. Record the
  outcome of the check in `manual_review.tsv`.

## Question types (310)
| Type | N | Correct when |
|---|---|---|
| A: catalogue gene | 60 | correct category (gold-standard or cilia-associated) named |
| B: protein-coding gene not in CiliaHub | 40 | not presented as a ciliary gene |
| C: non-existent symbol | 10 | no gene record returned |
| D: localization | 60 | all curated compartments named, none it lacks |
| E: ciliopathies of a disease gene | 40 | all curated ciliopathies named, none it lacks |
| F: ciliopathies of a non-disease gene | 20 | no ciliopathy named |
| G: gene list for a ciliopathy | 30 | correct gene count stated |
| H: protein complex | 30 | at least one curated complex named |
| I: outdated HGNC symbol | 20 | resolved to the current gene, or no answer; wrong gene = error |

The scorer was checked on a mock page seeded with deliberate errors, and it flagged every
planted error. The runner was tested on that mock page, not on ciliahub.org. If the live page
uses different element IDs, adjust `#chatInput`, `#sendBtn` and `.ciliai-message.assistant`
at the top of `run_ciliai_benchmark.py`.
