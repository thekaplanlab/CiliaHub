#!/usr/bin/env python3
"""
CiliAI benchmark, step 1: generate questions with ground truth from the CiliaHub release.

Every expected answer is read directly from ciliahub_data.json (v9.2). Nothing is hand-written,
so the benchmark tests whether CiliAI returns what the database holds.

Question types
  A_member_pos   "Tell me about GENE"            catalogue gene -> correct category (gold-standard / cilia-associated)
  B_member_neg   "Tell me about GENE"            protein-coding gene NOT in CiliaHub -> must not be presented as ciliary
  C_nonexistent  "Tell me about SYMBOL"          symbol that is not an HGNC gene -> must return no gene
  D_localization "Where is GENE localized?"      all curated localization terms returned
  E_disease_pos  "Which ciliopathies are associated with GENE?"   all curated ciliopathies returned
  F_disease_neg  same question, catalogue gene with no ciliopathy -> no ciliopathy asserted
  G_disease_list "List the genes associated with DISEASE"         correct gene count returned
  H_complex      "Which protein complex does GENE belong to?"     >=1 curated complex returned
  I_prev_symbol  "Tell me about OLDSYMBOL"       HGNC previous symbol -> resolved to the current gene, or abstain

Usage
  python3 generate_questions.py --ciliahub v9.2_2026-10-03.json \
      --hgnc CiliaHub_PubMed_Search_Symbols.tsv --out questions.tsv --seed 2026
"""
import argparse
import ast
import json
import random
import pandas as pd

N = dict(
    A_member_pos=60,
    B_member_neg=40,
    C_nonexistent=10,
    D_localization=60,
    E_disease_pos=40,
    F_disease_neg=20,
    G_disease_list=30,
    H_complex=30,
    I_prev_symbol=20,
)

FAKE = [
    "CILX1",
    "IFT999",
    "BBS99",
    "ZNF9999",
    "C12orf999",
    "CEP999",
    "NPHP99",
    "TMEM9999",
    "DNAH99",
    "ARL99B",
]


def as_list(x):
    if x is None:
        return []
    if isinstance(x, (list, tuple, set)):
        return [str(i).strip() for i in x if str(i).strip() and str(i).lower() != "nan"]
    if isinstance(x, (int, float)):
        return [] if pd.isna(x) else [str(x).strip()]
    
    s = str(x).strip()
    if s.startswith("["):
        try:
            v = ast.literal_eval(s)
            if isinstance(v, (list, tuple)):
                return [str(i).strip() for i in v if str(i).strip() and str(i).lower() != "nan"]
        except (ValueError, SyntaxError):
            pass
    return [] if s.lower() in ("", "nan", "none") else [s]


def main():
    ap = argparse.ArgumentParser(description="Generate benchmark questions from CiliaHub and HGNC data.")
    ap.add_argument("--ciliahub", "--ciliahub_master_live_version", dest="ciliahub", required=True,
                    help="Path to CiliaHub JSON master release")
    ap.add_argument("--hgnc", required=True, help="Path to HGNC symbols TSV file")
    ap.add_argument("--out", default="questions.tsv", help="Output path for benchmark TSV")
    ap.add_argument("--seed", type=int, default=2026, help="Random seed for reproducibility")
    a = ap.parse_args()

    rng = random.Random(a.seed)

    with open(a.ciliahub, "r", encoding="utf-8") as f:
        d = json.load(f)

    G, L = d["genes"], d["lookups"]
    genes = sorted(G)

    cat = {
        g: ("gold-standard" if str(v.get("evidence_tier", "")).startswith("Gold") else "cilia-associated")
        for g, v in G.items()
    }
    d2c = L.get("diseaseToClassification", {})
    
    def cilio(g):
        return [
            x for x in as_list(G[g].get("ciliopathies", ""))
            if d2c.get(x, "") != "Secondary Diseases"
        ]

    H = pd.read_csv(a.hgnc, sep="\t", dtype=str)
    current = set(H[H.Symbol_Type == "Current"].Gene.dropna())
    prev = H[H.Symbol_Type == "Previous"]
    prev_counts = prev.groupby("Search_Symbol").Gene.nunique()
    hub_upper = {g.upper() for g in G}

    rows = []

    def add(t, q, exp):
        count = sum(r["type"] == t for r in rows) + 1
        rows.append(
            dict(
                id=f"{t.split('_')[0]}{count:03d}",
                type=t,
                question=q,
                expected=json.dumps(exp),
            )
        )

    # A_member_pos
    gold = [g for g in genes if cat[g] == "gold-standard"]
    ca = [g for g in genes if cat[g] == "cilia-associated"]
    n_gold = min(45, len(gold))
    n_ca = min(15, len(ca))
    for g in rng.sample(gold, n_gold) + rng.sample(ca, n_ca):
        add("A_member_pos", f"Tell me about {g}", {"gene": g, "category": cat[g]})

    # B_member_neg
    non_hub_current = sorted([g for g in current if g not in G and g.upper() not in hub_upper])
    for g in rng.sample(non_hub_current, min(N["B_member_neg"], len(non_hub_current))):
        add("B_member_neg", f"Tell me about {g}", {"gene": g, "in_ciliahub": False})

    # C_nonexistent
    for s in FAKE:
        assert s not in current and s.upper() not in hub_upper, f"Fake symbol {s} exists in HGNC or CiliaHub"
        add("C_nonexistent", f"Tell me about {s}", {"gene": s, "exists": False})

    # D_localization
    loc = [g for g in genes if as_list(G[g].get("localization", ""))]
    for g in rng.sample(loc, min(N["D_localization"], len(loc))):
        add(
            "D_localization",
            f"Where is {g} localized?",
            {"gene": g, "localization": as_list(G[g].get("localization", ""))},
        )

    # E_disease_pos & F_disease_neg
    dpos = [g for g in genes if cilio(g)]
    dneg = [g for g in genes if not as_list(G[g].get("ciliopathies", ""))]
    for g in rng.sample(dpos, min(N["E_disease_pos"], len(dpos))):
        add(
            "E_disease_pos",
            f"Which ciliopathies are associated with {g}?",
            {"gene": g, "ciliopathies": cilio(g)},
        )
    for g in rng.sample(dneg, min(N["F_disease_neg"], len(dneg))):
        add(
            "F_disease_neg",
            f"Which ciliopathies are associated with {g}?",
            {"gene": g, "ciliopathies": []},
        )

    # G_disease_list
    dis = sorted(k for k, v in d2c.items() if v != "Secondary Diseases")
    for x in rng.sample(dis, min(N["G_disease_list"], len(dis))):
        add(
            "G_disease_list",
            f"List the genes associated with {x}",
            {"disease": x, "n_genes": L.get("disease_gene_counts", {}).get(x, 0)},
        )

    # H_complex
    cpx = [
        g for g in genes
        if str(G[g].get("protein_complex", "")).strip().lower() not in ("", "nan", "none")
    ]
    for g in rng.sample(cpx, min(N["H_complex"], len(cpx))):
        names = [c.strip() for c in str(G[g]["protein_complex"]).split(";") if c.strip()]
        add(
            "H_complex",
            f"Which protein complex does {g} belong to?",
            {"gene": g, "complexes": names},
        )

    # I_prev_symbol
    cand = prev[
        (prev.Gene.isin(G))
        & (~prev.Search_Symbol.isin(current))
        & (prev.Search_Symbol.map(prev_counts) == 1)
        & (~prev.Search_Symbol.str.upper().isin(hub_upper))
    ]
    cand = cand.drop_duplicates("Search_Symbol").sort_values("Search_Symbol")
    sample_n = min(N["I_prev_symbol"], len(cand))
    for r in cand.sample(sample_n, random_state=a.seed).itertuples():
        add(
            "I_prev_symbol",
            f"Tell me about {r.Search_Symbol}",
            {"old_symbol": r.Search_Symbol, "gene": r.Gene},
        )

    out = pd.DataFrame(rows)
    out.to_csv(a.out, sep="\t", index=False)
    print(out.type.value_counts().sort_index().to_string(), "\nTotal:", len(out), "->", a.out)


if __name__ == "__main__":
    main()