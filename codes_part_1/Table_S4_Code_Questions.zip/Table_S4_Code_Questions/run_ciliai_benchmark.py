#!/usr/bin/env python3
"""
CiliAI benchmark, step 2: send every question to the live CiliAI page and record the answer.

Drives https://ciliahub.org/ciliai.html in a headless Chromium browser (Playwright), types each
question into the chat box, waits for the assistant reply and saves its visible text. It also
records every network request the page makes while answering, so the report can show that no
language-model endpoint was contacted.

Setup (once):   pip install playwright pandas && python -m playwright install chromium

Usage:
    python run_ciliai_benchmark.py --questions questions1.tsv --out responses_run1.tsv
    python run_ciliai_benchmark.py --questions questions2.tsv --out responses_run2.tsv
"""
import argparse, asyncio, os, sys, time
import pandas as pd
from playwright.async_api import async_playwright

LLM_HOSTS = ("deepseek", "openai", "anthropic", "workers.dev", "ollama", "groq", "api/chat")
ASSIST = ".ciliai-message.assistant"

CLEAN_TEXT_JS = """() => {
  const all = document.querySelectorAll('.ciliai-message.assistant .ciliai-message-content');
  if (!all.length) return '';
  const node = all[all.length - 1].cloneNode(true);
  node.querySelectorAll('button, [role=button], [class*=chip], [class*=suggest]')
      .forEach(e => e.remove());
  node.style.cssText = 'position:absolute;left:-99999px;top:0;width:800px';
  document.body.appendChild(node);
  const txt = node.innerText;
  node.remove();
  return txt;
}"""


async def ask(page, q, settle_ms):
    n = await page.locator(ASSIST).count()
    await page.fill("#chatInput", "")  # Girdiyi önce temizle
    await page.fill("#chatInput", q)
    await page.click("#sendBtn")
    await page.wait_for_function(f"document.querySelectorAll('{ASSIST}').length > {n}", timeout=60000)
    
    last, stable = None, 0
    while stable < 3:
        await page.wait_for_timeout(settle_ms)
        txt = await page.evaluate(CLEAN_TEXT_JS)
        stable = stable + 1 if txt == last else 0
        last = txt
        
    panel = await page.evaluate("""() => Array.from(document.querySelectorAll('table'))
        .map(t => t.innerText).join('\\n').slice(0, 20000)""")
    return last, panel


async def main(a):
    if not os.path.exists(a.questions):
        print(f"HATA: '{a.questions}' dosyası bulunamadı! Lütfen dosya adını ve uzantısını kontrol edin.")
        sys.exit(1)

    qs = pd.read_csv(a.questions, sep="\t", dtype=str)
    out = []
    
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        page = await browser.new_page()
        reqs = []
        page.on("request", lambda r: reqs.append(r.url))
        
        print(f"Siteye bağlanılıyor: {a.url}")
        await page.goto(a.url, wait_until="domcontentloaded", timeout=120000)
        await page.wait_for_function("window.CiliAI && window.CiliAI.ready", timeout=180000)
        
        env = await page.evaluate("JSON.stringify(window.CILIAI_ENV || {})")
        print("CILIAI_ENV:", env)
        print(f"Toplam {len(qs)} soru işlenecek...\n")
        
        for i, r in enumerate(qs.itertuples(), 1):
            reqs.clear()
            t0 = time.time()
            try:
                ans, panel = await ask(page, r.question, a.settle_ms)
                err = ""
            except Exception as e:
                ans, panel, err = "", "", f"{type(e).__name__}: {e}"[:300]
                
            llm = sorted({u for u in reqs if any(h in u.lower() for h in LLM_HOSTS)})
            out.append(dict(
                id=r.id, type=r.type, question=r.question, response=ans, table_text=panel,
                seconds=round(time.time() - t0, 2), llm_requests=";".join(llm), error=err
            ))
            
            print(f"[{i}/{len(qs)}] {r.id} {'[LLM Çağrısı Saptandı!]' if llm else ''} {err[:60]}")
            
            if a.clear_between and i % 25 == 0:
                await page.reload(wait_until="domcontentloaded")
                await page.wait_for_function("window.CiliAI && window.CiliAI.ready", timeout=180000)
                
        await browser.close()
        
    df = pd.DataFrame(out)
    df.to_csv(a.out, sep="\t", index=False)
    with open(a.out + ".env.json", "w", encoding="utf-8") as f:
        f.write(env)
    print("\nSonuçlar başarıyla kaydedildi ->", a.out)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--questions", required=True, help="Soru TSV dosya yolu")
    ap.add_argument("--out", required=True, help="Çıktı TSV dosya yolu")
    ap.add_argument("--url", default="https://ciliahub.org/ciliai.html")
    ap.add_argument("--settle-ms", dest="settle_ms", type=int, default=700)
    ap.add_argument("--no-reload", dest="clear_between", action="store_false")
    
    # Windows SelectorEventLoop çökme düzeltmesi
    if sys.platform == 'win32':
        asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())
        
    asyncio.run(main(ap.parse_args()))