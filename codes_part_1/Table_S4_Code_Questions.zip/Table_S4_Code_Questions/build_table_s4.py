#!/usr/bin/env python3
"""
CiliAI benchmark, step 4: apply the manual review and write Supplementary Table S4.

Inputs
  --scored   ciliai_benchmark_scored.xlsx (output of score_ciliai_benchmark.py)
  --review   manual_review.tsv: one row per answer whose automatic verdict was checked by hand
             (columns: id, verdict [correct/incorrect], unsupported [yes/no], note).
             Every other answer scored incorrect automatically is kept as incorrect.
Output
  Supplementary_Table_S4_CiliAI_Benchmark.xlsx (Legend, Summary, Answers)

Usage
  python3 build_table_s4.py --scored ciliai_benchmark_scored.xlsx --review manual_review.tsv
"""
import argparse, json, math
import pandas as pd, openpyxl
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter as L

TYPES = {'A_member_pos': 'Catalogue gene', 'B_member_neg': 'Protein-coding gene not in CiliaHub',
         'C_nonexistent': 'Non-existent symbol', 'D_localization': 'Localization of a gene',
         'E_disease_pos': 'Ciliopathies of a disease gene', 'F_disease_neg': 'Ciliopathies of a gene without disease',
         'G_disease_list': 'Genes of a ciliopathy', 'H_complex': 'Protein complex of a gene',
         'I_prev_symbol': 'Outdated HGNC symbol'}


def expected_text(t, e):
    e = json.loads(e)
    return {'A_member_pos': lambda: f"In CiliaHub; category: {e['category']}",
            'B_member_neg': lambda: "Not in CiliaHub", 'C_nonexistent': lambda: "Symbol does not exist",
            'D_localization': lambda: "Localization: " + "; ".join(e['localization']),
            'E_disease_pos': lambda: "Ciliopathies: " + "; ".join(e['ciliopathies']),
            'F_disease_neg': lambda: "No ciliopathy association",
            'G_disease_list': lambda: f"{e['n_genes']} genes",
            'H_complex': lambda: "Complexes: " + "; ".join(e['complexes']),
            'I_prev_symbol': lambda: f"Previous symbol of {e['gene']}"}[t]()


def wilson(k, n, z=1.96):
    p = k / n
    c = (p + z * z / (2 * n)) / (1 + z * z / n)
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / (1 + z * z / n)
    return f"{max(0, 100 * (c - h)):.1f}–{min(100, 100 * (c + h)):.1f}"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--scored", required=True)
    ap.add_argument("--review", required=True)
    ap.add_argument("--out", default="Supplementary_Table_S4_CiliAI_Benchmark.xlsx")
    ap.add_argument("--date", default="6 October 2026")
    a = ap.parse_args()

    d = pd.read_excel(a.scored, sheet_name="All answers").fillna("")
    rv = pd.read_csv(a.review, sep="\t", dtype=str).set_index("id")
    two_runs = "identical_across_runs" in d.columns
    rows = []
    for r in d.itertuples():
        correct, unsupported, note = bool(r.auto_correct), False, ("" if r.auto_correct else r.detail)
        if r.id in rv.index:
            x = rv.loc[r.id]
            correct, unsupported, note = x.verdict.startswith("correct"), x.unsupported == "yes", x.note
        rows.append([r.id, TYPES[r.type], r.question, expected_text(r.type, r.expected), str(r.response)[:32000],
                     ("Yes" if str(r.identical_across_runs) in ("True", "1") else "No") if two_runs else "Not run",
                     "Correct" if correct else "Incorrect", "Yes" if unsupported else "No",
                     "Yes" if r.llm_requests else "No", note])

    wb = openpyxl.Workbook()
    leg = wb.active; leg.title = "Legend"
    sm = wb.create_sheet("Summary"); ws = wb.create_sheet("Answers")
    HF, HFILL = Font(bold=True, color="FFFFFF"), PatternFill("solid", fgColor="1F3A5F")

    def header(sh, cols, widths):
        for i, (c, w) in enumerate(zip(cols, widths), 1):
            k = sh.cell(1, i, c); k.font = HF; k.fill = HFILL
            k.alignment = Alignment(wrap_text=True, vertical="center")
            sh.column_dimensions[L(i)].width = w
        sh.freeze_panes = "A2"

    header(ws, ['Question ID', 'Question type', 'Question', 'Expected answer (CiliaHub v9.2)', 'CiliAI answer (run 1)',
                'Identical in run 2', 'Verdict', 'Unsupported statement', 'Language-model request', 'Note'],
           [11, 30, 48, 45, 70, 11, 11, 13, 13, 60])
    for i, row in enumerate(rows, 2):
        for j, v in enumerate(row, 1):
            ws.cell(i, j, v).alignment = Alignment(wrap_text=j in (3, 4, 5, 10), vertical="top")
    n = len(rows) + 1
    ws.auto_filter.ref = f"A1:J{n}"
    R = lambda c: f"Answers!${c}$2:${c}${n}"

    header(sm, ['Question type', 'Questions', 'Correct', 'Accuracy %', '95% CI (Wilson)', 'Unsupported statements',
                'Language-model requests', 'Identical across runs %'], [38, 11, 10, 11, 16, 14, 14, 14])
    for i, t in enumerate(list(TYPES.values()) + ["All questions"], 2):
        crit = '"*"' if t == "All questions" else f"A{i}"
        sub = [x for x in rows if t == "All questions" or x[1] == t]
        sm.cell(i, 1, t)
        sm.cell(i, 2, f'=COUNTIFS({R("B")},{crit})')
        sm.cell(i, 3, f'=COUNTIFS({R("B")},{crit},{R("G")},"Correct")')
        sm.cell(i, 4, f"=C{i}/B{i}").number_format = "0.0%"
        sm.cell(i, 5, wilson(sum(x[6] == "Correct" for x in sub), len(sub)))
        sm.cell(i, 6, f'=COUNTIFS({R("B")},{crit},{R("H")},"Yes")')
        sm.cell(i, 7, f'=COUNTIFS({R("B")},{crit},{R("I")},"Yes")')
        if two_runs:
            sm.cell(i, 8, f'=COUNTIFS({R("B")},{crit},{R("F")},"Yes")/B{i}').number_format = "0.0%"
        else:
            sm.cell(i, 8, "n/a (single run)")
        if t == "All questions":
            for c in range(1, 9): sm.cell(i, c).font = Font(bold=True)

    text = [
        "Supplementary Table S4. Benchmark of CiliAI against the CiliaHub v9.2 release", "",
        "Questions: 310, generated automatically from the CiliaHub v9.2 release file (ciliahub_data.json; random seed 2026). Each expected answer is the value stored in the database; none was written by hand.",
        f"Procedure: each question was typed into the public CiliAI interface (https://ciliahub.org/ciliai.html) by an automated browser (Playwright, headless Chromium) on {a.date}, and the reply text was recorded. The full set was run twice to test whether answers are reproducible.",
        f"Scoring: replies were scored automatically against the expected answer; every reply scored incorrect or flagged as unsupported was then checked by hand. {len(rv)} answers were annotated on review (see Note); verdicts changed on review: {', '.join(i for i in rv.index if (rv.loc[i].verdict.startswith('correct')) != bool(d.set_index('id').loc[i].auto_correct)) or 'none'}.",
        "Verdict rules: catalogue gene, correct category named; gene not in CiliaHub or non-existent symbol, not presented as a ciliary gene; localization and ciliopathies, all stored values named and none the gene lacks; genes of a ciliopathy, correct gene count stated; protein complex, at least one stored complex named; outdated symbol, the record of the correct current gene returned or no record returned.",
        "Unsupported statement: a reply that presents information the database does not hold for that gene. Language-model request: the page contacted an external language-model endpoint while answering.",
        "95% confidence intervals: Wilson score interval. Counts and percentages in Summary are live formulas over the Answers sheet.", "",
        "Sheets: Summary (accuracy by question type); Answers (one row per question with expected answer, CiliAI reply, verdict and notes).",
        "Scripts: generate_questions.py, run_ciliai_benchmark.py, score_ciliai_benchmark.py and build_table_s4.py, with manual_review.tsv (GitHub)."]
    for i, t in enumerate(text, 1):
        leg.cell(i, 1, t)
    leg["A1"].font = Font(bold=True, size=12); leg.column_dimensions["A"].width = 150
    wb.save(a.out)
    print("Saved", a.out)


if __name__ == "__main__":
    main()
