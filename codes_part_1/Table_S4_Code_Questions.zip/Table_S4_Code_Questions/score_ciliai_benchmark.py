#!/usr/bin/env python3
"""
CiliAI benchmark, step 3: score the recorded answers against the ground truth.

Each answer is scored automatically as correct / incorrect by the rules below, and every
incorrect answer is written to a review sheet so the authors can confirm it by eye. Report the
automatic accuracy and state how many automatic calls were overturned on manual review.

Rules (case-insensitive, on the reply text plus any gene table the reply opened)
  A  gene symbol present AND correct category named AND the other category not named
  B  answer does not name a CiliaHub category (gold-standard / cilia-associated) for the gene
  C  same as B (no gene record returned for a symbol that does not exist)
  D  every curated localization term present, and no ciliary compartment the gene lacks
  E  every curated ciliopathy present, and no ciliopathy the gene lacks
  F  no ciliopathy name from the CiliaHub disease list present
  G  the curated gene count appears in the answer as a number
  H  at least one curated complex name present
  I  current symbol present (resolved) -> correct; no gene named -> abstained (counted correct,
     reported separately); another CiliaHub gene named instead -> incorrect
Hallucination = an answer that asserts something absent from the database (B, C, F, I failures,
and D/E answers naming a compartment/disease the gene does not carry).
Determinism = identical reply text across two runs.

Usage
python score_ciliai_benchmark.py --ciliahub "ciliahub_master_live_version v9.2_2026-10-03.json" --questions questions.tsv 
--run1 responses_run1.tsv --run2 responses_run2.tsv --out ciliai_benchmark_scored.xlsx

"""
import argparse, json, math, re
import pandas as pd

CATS = {"gold-standard": [r"gold[\s-]*standard"], "cilia-associated": [r"cilia[\s-]*associated"]}
COMPARTMENTS = ["axoneme", "basal body", "transition zone", "ciliary membrane", "cilia",
                "centrosome", "centriole", "flagella", "flagellum", "ciliary tip", "ciliary pocket"]

CHIP_LINES = {"show gold standard ciliary genes", "joubert syndrome genes", "ift88 localization",
              "overview", "expression", "screens", "evolution"}

NOT_LOCALIZATION = {"cilia associated gene", "ciliary associated gene", "cilia associated"}


def strip_chips(text):
    return "\n".join(l for l in text.splitlines() if l.strip().lower() not in CHIP_LINES)


def has(text, term):
    return re.search(r"(?<![A-Za-z0-9])" + re.escape(term.lower()) + r"(?![A-Za-z0-9])", text) is not None


def wilson(k, n, z=1.96):
    if n == 0:
        return (float("nan"), float("nan"))
    p = k / n
    c = (p + z * z / (2 * n)) / (1 + z * z / n)
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / (1 + z * z / n)
    return (round(100 * (c - h), 1), round(100 * (c + h), 1))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ciliahub", required=True)
    ap.add_argument("--questions", required=True)
    ap.add_argument("--run1", required=True)
    ap.add_argument("--run2")
    ap.add_argument("--out", default="ciliai_benchmark_scored.xlsx")
    a = ap.parse_args()

    with open(a.ciliahub, "r", encoding="utf-8") as f:
        d = json.load(f)

    hub = set(d["genes"])
    diseases = list(d["lookups"]["diseaseToClassification"])
    dpat = [(x, x) for x in diseases] + list(d["lookups"].get("diseaseAliases", {}).items())

    def diseases_named(raw):
        low = raw.lower()
        hits = set()
        for pat, canon in dpat:
            if pat.isupper() and len(pat) <= 5:
                if re.search(r"(?<![A-Za-z0-9])" + re.escape(pat) + r"(?![A-Za-z0-9])", raw):
                    hits.add(canon)
            elif has(low, pat):
                hits.add(canon)
        return hits

    def gene_diseases(g):
        v = d["genes"].get(g, {}).get("ciliopathies", [])
        return set(v if isinstance(v, list) else [])

    q = pd.read_csv(a.questions, sep="\t", dtype=str, encoding="utf-8")
    r1 = pd.read_csv(a.run1, sep="\t", dtype=str, encoding="utf-8").fillna("")
    df = q.merge(r1[["id", "response", "table_text", "llm_requests", "error", "seconds"]], on="id", how="left").fillna("")
    
    if a.run2:
        r2 = pd.read_csv(a.run2, sep="\t", dtype=str, encoding="utf-8").fillna("")
        df = df.merge(r2[["id", "response"]].rename(columns={"response": "response_run2"}), on="id", how="left").fillna("")
        df["identical_across_runs"] = df.response == df.response_run2

    res = []
    for r in df.itertuples():
        e = json.loads(r.expected)
        raw = strip_chips(r.response) + "\n" + strip_chips(r.table_text)
        t = raw.lower()
        ok, detail, halluc = False, "", False
        if r.error or not r.response.strip():
            ok, detail = False, "no answer / timeout"
        elif r.type == "A_member_pos":
            right = any(re.search(p, t) for p in CATS[e["category"]])
            other = [c for c in CATS if c != e["category"]]
            wrong = any(re.search(p, t) for c in other for p in CATS[c])
            ok = has(t, e["gene"]) and right and not wrong
            detail = f"category named: {right}; other category named: {wrong}"
        elif r.type in ("B_member_neg", "C_nonexistent"):
            named = any(re.search(p, t) for ps in CATS.values() for p in ps)
            ok = not named
            halluc = named
            detail = "presented with a CiliaHub category" if named else "not presented as ciliary"
        elif r.type == "D_localization":
            exp = [x for x in e["localization"] if x.lower() not in NOT_LOCALIZATION] or e["localization"]
            found = [x for x in exp if has(t, x)]
            allowed = e["localization"]
            extra = [x for x in COMPARTMENTS if has(t, x) and not any(x in y.lower() or y.lower() in x for y in allowed)]
            halluc = bool(extra)
            ok = len(found) == len(exp) and not extra
            detail = f"recall {len(found)}/{len(exp)}; missing: {[x for x in exp if x not in found]}; extra: {extra}"
        elif r.type == "E_disease_pos":
            exp = e["ciliopathies"]
            named = diseases_named(raw)
            found = [x for x in exp if x in named]
            own = gene_diseases(e["gene"])
            extra = sorted(x for x in named - own if not any(x.lower() in y.lower() for y in own))
            halluc = bool(extra)
            ok = len(found) == len(exp) and not extra
            detail = f"recall {len(found)}/{len(exp)}; missing: {[x for x in exp if x not in found]}; extra: {extra}"
        elif r.type == "F_disease_neg":
            named = sorted(diseases_named(raw))
            ok, halluc = not named, bool(named)
            detail = f"diseases named: {named}"
        elif r.type == "G_disease_list":
            ans = strip_chips(r.response).lower()
            nums = re.findall(r"\b\d+\b", ans)
            ok = str(e["n_genes"]) in nums
            detail = f"expected {e['n_genes']}; numbers in reply: {nums[:10]}"
        elif r.type == "H_complex":
            found = [c for c in e["complexes"] if has(t, c)]
            ok = bool(found)
            detail = f"complexes found: {found}"
        elif r.type == "I_prev_symbol":
            desc = d["genes"][e["gene"]].get("description", "").split("[Source")[0].strip().lower()
            other = [g for g in hub if g != e["gene"] and len(g) > 2 and has(t, g)]
            card = any(re.search(p, t) for ps in CATS.values() for p in ps)
            if has(t, e["gene"]) or (desc and desc in t):
                ok, detail = True, "resolved to the correct current gene"
            elif re.search(r"no data found|not found|didn.t understand|no results?", t):
                ok, detail = True, "abstained (no record returned)"
            elif other:
                ok, halluc, detail = False, True, f"named other gene(s): {other[:5]}"
            elif card:
                ok, detail = False, "record shown but could not be matched to the current gene; check by hand"
            else:
                ok, detail = False, "unclear reply; check by hand"
        res.append((ok, halluc, detail))

    df["auto_correct"], df["hallucination"], df["detail"] = zip(*res)
    df["manual_verdict"] = ""

    rows = []
    for t, s in list(df.groupby("type")) + [("ALL", df)]:
        k, n = int(s.auto_correct.sum()), len(s)
        lo, hi = wilson(k, n)
        row = {"Question type": t, "N": n, "Correct": k, "Accuracy %": round(100 * k / n, 1),
               "95% CI": f"{lo}-{hi}", "Hallucinations": int(s.hallucination.sum()),
               "LLM requests": int((s.llm_requests != "").sum()),
               "Median seconds": pd.to_numeric(s.seconds, errors="coerce").median()}
        if "identical_across_runs" in s:
            row["Identical across runs %"] = round(100 * s.identical_across_runs.mean(), 1)
        rows.append(row)

    summ = pd.DataFrame(rows)
    print(summ.to_string(index=False))

    with pd.ExcelWriter(a.out) as w:
        summ.to_excel(w, sheet_name="Summary", index=False)
        df.drop(columns=["table_text"]).to_excel(w, sheet_name="All answers", index=False)
        df[~df.auto_correct | df.hallucination].drop(columns=["table_text"]).to_excel(w, sheet_name="For manual review", index=False)
    print("Saved", a.out)


if __name__ == "__main__":
    main()